##
## README.MD - Main README File
##
##
## Version 1.0 02-Nov-2024
##
##
## Authors:  Ian Hewitt & Dr. Patrick Treuthardt,
##           NC Museum of Natural Sciences,
##           Astronomy & Astrophysics Lab,
##           Raleigh, NC USA.
##           http://github.com/treuthardt/P2DFFT
##
##
## LICENSE
##
## P2DFFT Spiral Galaxy Arm Pitch Angle Analysis Suite
## Copyright (c) 2016-2024  Ian B. Hewitt & Dr. Patrick Treuthardt
##
## The program is free software:  you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by the Free
## Software Foundation, version 3.
##
## This program is distributed in the hope that it will be useful, but WITHOUT
## ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS
## FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
## details.
##
## You should have received a copy of the GNU General Public License along with
## this program.  If not, see < https://www.gnu.org/licenses >.
##
## The authors can be contacted at:
##
##      North Carolina Museum of Natural Sciences
##      Astronomy & Astrophysics Laboratory
##      11 West Jones Street
##      Raleigh, NC, 27601  USA
##      +1.919.707.9800
##
##      -- or --
##
##      patrick.treuthardt@naturalsciences.org
##

This is the archive for the P2DFFT spiral galaxy pitch angle analysis suite of programs. 

Please see the Manual.pdf in the docs folder for installation and use instructions.

