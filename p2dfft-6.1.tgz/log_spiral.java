//
// LOG_SPIRAL.JAVA - Overlay logarithmic spiral on FITS image
//
//            This program bring up a graphical interaface which allows the
//            user to measure the pitch angle of a galaxy by overlaying a
//            logarithmic spiral.  The parameters of the spiral can be
//            adjusted via the controls until the closest fit is obtained.
//
//
// Version 2.7: 29-Nov-2023
//
//
// Authors:  Jenna Repep, Ian Hewitt & Dr. Patrick Treuthardt,
//           NC Museum of Natural Sciences,
//           Astronomy & Astrophysics Lab,
//           Raleigh, NC USA.
//           http://github.com/treuthardt/P2DFFT
//
//
// LICENSE
//
// P2DFFT Spiral Galaxy Arm Pitch Angle Analysis Suite
// Copyright (c) 2016-2024  Ian B. Hewitt & Dr. Patrick Treuthardt
//
// The program is free software:  you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation, version 3.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
// details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see < https://www.gnu.org/licenses >.
//
// The authors can be contacted at:
//
//     North Carolina Museum of Natural Sciences
//     Astronomy & Astrophysics Laboratory
//     11 West Jones Street
//     Raleigh, NC, 27601  USA
//     +1.919.707.9800
//
//     -- or --
//
//     patrick.treuthardt@naturalsciences.org
//
//
// Usage: java log2spiral <x> <y>
//
//   <x> - Use this x coordinate for the center instead of the calculated
//         center from the image
//   <y> - Use this y coordinate for the center instead of the calculated
//         center from the image
//
//
// Revision History:
//      2.7  29-Nov-2023 - Fix bug where image not centered properly when using
//                         the next image option
//      2.6  18-Nov-2023 - Add arm count button group to record number of arms
//                         visible and write that information to the data file
//                       - Change the "next image" function to work with up to
//                         10,000 images instead of 100
//      2.5  15-Oct-2021 - Add ability to change center with command line args
//      2.4  28-Jun-2021 - Add feature where selecting new image will reset the
//                         arm number
//                       - Add next image feature that moves to the next
//                         sequential image in the set
//                       - Switch main block to use event dispatch thread
//                         interface to prevent erroneous warnings
//                       - Add return from fileDialog calls if user presses
//                         cancel (instead of causing Thread exception)
//      2.3  19-May-2021 - Change scale/fize of fonts and spacing to properly
//                         render on Retina displays
//                       - Fix bug where zoom level is not reset when opening
//                         a new image
//                       - Fix font on chirality buttons
//      2.2  10-May-2021 - Increase the columns in the user id entry field
//                       - Fix bug where data would be written even if user
//                         id was not set
//                       - Changed from JFileChooser to generic FileDialog
//                         because this uses the system's native file dialog
//                         to allow things like permission setting on the
//                         Mac to work
//                       - Removed color on chirality buttons
//                       - Changed the color scheme on the arm buttons and
//                         the best/high/low radio buttons.  All of these start
//                         red, and when a measurement is saved, that radio
//                         button turns black.  When all radio buttons are
//                         black for a particular arm, the arm button will then
//                         be black.  Switching arms will reset the radio
//                         button colors to match the status of the measurements
//                         for the currently selected arm.
//                       - Added checks for a duplicate (arm/type of fit)
//                         measurement save attempt.  This will trigger a
//                         confirmation dialog to insure user wants to write
//                         a duplicate measurement.  No will stop the write.
//      2.1  30-Apr-2021 - Change file dialogs to default to the directory
//                         where the application was started
//                       - Fix bug where data file was always saved in the
//                         directory where the application was started, despite
//                         where it was opened originally
//      2.0  28-Apr-2021 - Change layout of control panel
//                       - Add menu to load image
//                       - Add ability to save data file with measurements
//                       - Add user id fields
//                       - Remove direct entry for most parameters
//                       - Add version ID for app deployment
//      1.1  17-Dec-2020 - Small change to add a file dialog to open image
//                         file instead of a fixed filename.
//      1.0  18-Sep-2020 - Initial version imported into P2DFFT Package
//
//

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.*;
import java.util.Arrays;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.filechooser.*;

//
// Main Class - log_spiral
//

public class log_spiral extends Canvas implements ImageObserver, ActionListener, ChangeListener
	{
	private static final long serialVersionUID = 7526472295622776147L;

//
// Initial default values for logarithmic spiral
//
//   chir   - The winding chirality (1.0 for S-wise and -1.0 for Z-wise)
//   arm    - current arm number being analyzed
//   r0     - initial starting radius for logarithmic mapping
//   rot    - rotation of spiral starting point about the core (in degrees)
//   pa     - initial pitch angle og logarithmic spiral
//   sweep  - azimithal extent of log spiral
//

	static double 	chir = 1.0;
	static int 		arm = 1;
	static double 	r0 = 25.0;
	static double 	rot = 0.0;
	static double 	pa = 35.0;
	static double 	sweep = 180.0;

	static int width = 1000;
	static int height = 800;

	static double pi = Math.PI;

	static double zoom_level=1.0;

	static ArrayList<Point2D> center = new ArrayList<Point2D>();

	static String Image_File = "<None>";
	static String data_file = "<None>";
	static File	  data_file_dir;
	static String uid = "<None>";
	static String prev_dir = "<None>";
	static int	prev_file = 0;
	static int 	current_count = 0;
	static boolean uid_entered = false;
	final int BEST=0;
	final int HIGH=1;
	final int LOW=2;
	final boolean SG_TRACING = true;
	static boolean[][] arm_map = new boolean[3][7];

	private FileWriter out_data;

	private JPanel contentPane;
	private JPanel galPanel;
	private JScrollPane galSPanel;
	static int center_x = -1;
	static int center_y = -1;
//
// Menu items
//

	private JMenuItem open_image;
	private JMenuItem next_image;
	private JMenuItem quit_app;
	private JMenuItem data_csv;

	private JLabel lblImgFile;

	private JLabel lblDatFile;
	private JLabel lblUid;
	private JTextField enter_uid;
	private Color spiral_color = Color.magenta.darker();

//
// Chirality block components
//

	private JLabel lblChirality;
	private JButton chir_btn_s;
	private JButton chir_btn_z;

//
// Arm number block components
//

	private JLabel lblArms;
	private JButton btn_arms_1;
	private JButton btn_arms_2;
	private JButton btn_arms_3;
	private JButton btn_arms_4;
	private JButton btn_arms_5;
	private JButton btn_arms_6;

//
// Starting radius block components
//

	private JLabel lblR0;
	private JSlider r0slider;
	private JButton btn_r0_n1;
	private JButton btn_r0_p1;
	private JButton btn_r0_n10;
	private JButton btn_r0_p10;
	private GridLayout R0layout;

//
// Starting rotation block components
//

	private JLabel lblRot;
	private JSlider rotSlider;
	private JButton btn_rot_n1;
	private JButton btn_rot_p1;
	private JButton btn_rot_n5;
	private JButton btn_rot_p5;

//
// Pitch angle block components
//

	private JLabel lblPA;
	private JSlider sliderpa;
	private JButton btn_pa_n1;
	private JButton btn_pa_p1;
	private JButton btn_pa_n5;
	private JButton btn_pa_p5;

//
// Sweep block components
//

	private JLabel lblsweep;
	private JButton S90;
	private JButton S180;
	private JButton S270;
	private JButton S360;

//
// Arm count block components
//

	private JLabel lblcnt;
	private JButton ac1;
	private JButton ac2;
	private JButton ac3;
	private JButton ac4;
	private JButton ac5;
	private JButton ac6;

//
// Image display block components
//

	private JLabel lblImg;
	private JButton img_inv_btn;
	private JButton zoom_in_btn;
	private JButton zoom_out_btn;
	private JLabel col_lbl;
	private JComboBox<String> cols;

//
// Data logging block components
//

	private JLabel lblData;
	private	String fit_type = "best";
	private JRadioButton btn_best;
	private JRadioButton btn_low;
	private JRadioButton btn_high;
	private ButtonGroup save_grp;
	private JButton btn_save;

//
// Arm count block components
//

	private JLabel lblCount;
	private JRadioButton btn_cnt1;
	private JRadioButton btn_cnt2;
	private JRadioButton btn_cnt3;
	private JRadioButton btn_cnt4;
	private JRadioButton btn_cnt5;
	private JRadioButton btn_cnt6;


	static BufferedImage img;
	static log_spiral mySpiral;
	static JFrame frame;
	static JFrame image_display;

	static int maxHeight = 1080;
	static int maxWidth = 1920;


//
// MAIN Routine - Launch Application from the Event Dispatch Thread to avoid
//   any thread errors.
//

	public static void main(String[] args)
		{
		SwingUtilities.invokeLater(new Runnable()
			{
			public void run()
				{
				if (args.length > 1)
					{
					center_x = Integer.parseInt(args[0]);
					center_y = Integer.parseInt(args[1]);
					}
				mySpiral = new log_spiral();
				frame=new JFrame();
				mySpiral.buildGui(frame);
				}
			});
		}

	public void paint(Graphics g)
		{
		if (img != null)
			{
			scaffolding();
			Path2D.Double path = new Path2D.Double();
			Ellipse2D circle0 = new Ellipse2D.Double(center_x/2-r0, center_y/2-r0, 2*r0, 2*r0);
			g.drawImage(img, 0, 0, this); //draws the background
			g.setColor(spiral_color);
			for(int j = 0; j < center.size()-2; j++)
				{
				path = new Path2D.Double();
				double x1 = center.get(j).getX();
				double x2 = center.get(j+1).getX();
				double x3 = center.get(j+2).getX();
				double y1 = center.get(j).getY();
				double y2 = center.get(j+1).getY();
				double y3 = center.get(j+2).getY();
				path.moveTo(x1, y1);
				path.curveTo(x1, y1, x2, y2, x3, y3);

				((Graphics2D)g).draw(path); //draws the spiral piece
				path.moveTo(x2, y2);
				}
			}
		mySpiral.setVisible(true);
		}

//
// SCAFFOLDING() - This routine does the calculation of the logarithmic spiral
//                 based on the current setting and puts the points in the
//                 center points array
//

	public static void scaffolding()
		{
		if ((center_x < 0)&&(center_y <0))
			{
			center_x=width;
			center_y=height;
			}
			
		for(double theta = 1; theta < sweep; theta++)
			{
			double radius = r0*Math.exp(Math.tan((Math.abs(pa))*(pi/180.0))*theta*(pi/180.0));
			int x=(int)((center_x/2)+(chir*(int)(radius * Math.cos((theta+rot)*(pi/180.0)))));
			double x1 = ((center_x/2)+(chir*(radius * Math.cos((theta+rot)*(pi/180.0)))));
			int y=((center_y/2)+(int)(radius * Math.sin((theta+rot)*(pi/180.0))));
			double y1=((center_y/2)+(radius * Math.sin((theta+rot)*(pi/180.0))));

			if((x1>-1) && (x1<width) && (y1>-1) && (y1<height))
				{
			    center.add(new Point2D.Double(x1, y1));
			    }
			}
		}

//
// BUILDGUI() - This routine will assemble the components for the graphical
//              layout of the application
//

	public void buildGui(JFrame frame)
		{
		Arrays.fill(arm_map[BEST], Boolean.FALSE);
		Arrays.fill(arm_map[HIGH], Boolean.FALSE);
		Arrays.fill(arm_map[LOW], Boolean.FALSE);
		frame.setVisible(true);
		frame.setTitle("Log Spiral Overlay Tool");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(0, 0, width, height);
		contentPane = new JPanel();
		contentPane.setBorder(null);
		contentPane.setLayout(new BorderLayout(0, 0));
		frame.setContentPane(contentPane);
		contentPane.add(mySpiral);


//
// Add menu items
//

    	JMenuBar menubar = new JMenuBar();
		JMenu file_menu = new JMenu("File");
		menubar.add(file_menu);
	  	open_image = new JMenuItem("Open Image");
    	file_menu.add(open_image);
		open_image.addActionListener(this);
		file_menu.addSeparator();
		next_image = new JMenuItem("Next Image");
    	file_menu.add(next_image);
		next_image.addActionListener(this);
		file_menu.addSeparator();
		quit_app = new JMenuItem("Quit");
		file_menu.add(quit_app);
		quit_app.addActionListener(this);
		JMenu data_menu = new JMenu("Data");
		menubar.add(data_menu);
		data_csv = new JMenuItem("Use Data File");
		data_menu.add(data_csv);
		data_csv.addActionListener(this);
    	frame.setJMenuBar(menubar);

//
// Add graphics panel on the right
//

		galPanel = new JPanel();
		galSPanel = new JScrollPane(galPanel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		galSPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		galSPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		galSPanel.setEnabled(true);
		galSPanel.setVisible(true);
		contentPane.add(galPanel, BorderLayout.WEST);

//
// Add tool panel on the left
//

		JPanel buttonPanel = new JPanel();
		buttonPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		contentPane.add(buttonPanel, BorderLayout.EAST);
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));

//
// Add section to panel where the status updated are shown (image file name,
//   data file name, and user id)
//

		JPanel panelFile = new JPanel();
		panelFile.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelFile.setLayout(new GridLayout(3, 1, 0, 0));
		buttonPanel.add(panelFile);

		lblImgFile = new JLabel("Image: "+Image_File);
		panelFile.add(lblImgFile);
		lblImgFile.setHorizontalAlignment(SwingConstants.CENTER);
		lblImgFile.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblImgFile.setForeground(Color.red);

		lblDatFile = new JLabel("Data File: "+data_file);
		panelFile.add(lblDatFile);
		lblDatFile.setHorizontalAlignment(SwingConstants.CENTER);
		lblDatFile.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblDatFile.setForeground(Color.red);

		JPanel panelUid = new JPanel();
		panelUid.setLayout(new FlowLayout(FlowLayout.CENTER, 6,2));
		panelFile.add(panelUid);
		lblUid = new JLabel("User Description:");
		panelUid.add(lblUid);
		lblUid.setHorizontalAlignment(SwingConstants.CENTER);
		lblUid.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblUid.setForeground(Color.red);

		enter_uid = new JTextField();
		enter_uid.setText(uid);
		enter_uid.setFont(new Font("Tahoma", Font.BOLD, 12));
		enter_uid.setColumns(16);
		enter_uid.addActionListener(this);
		panelUid.add(enter_uid);

//
// Add a panel for the image control buttons (invert, zomm in/out, and spiral
//   line color)
//

		JPanel panelImgBtns = new JPanel();
		panelImgBtns.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelImgBtns.setLayout(new FlowLayout(FlowLayout.CENTER, 6, 2));
		buttonPanel.add(panelImgBtns);

		img_inv_btn = new JButton("Invert");
		img_inv_btn.addActionListener(this);
		panelImgBtns.add(img_inv_btn);

		zoom_in_btn = new JButton("Zoom In");
		zoom_in_btn.addActionListener(this);
		panelImgBtns.add(zoom_in_btn);

		zoom_out_btn = new JButton("Zoom Out");
		zoom_out_btn.addActionListener(this);
		panelImgBtns.add(zoom_out_btn);

		JPanel panelImgColor = new JPanel();
		panelImgBtns.add(panelImgColor);
		String choices[] = {"Magenta", "Green", "Red", "Blue", "Yellow", "Black"};
		col_lbl=new JLabel("Spiral Color");
		panelImgColor.add(col_lbl);
		cols=new JComboBox<>(choices);
		panelImgColor.add(cols);
		cols.addActionListener(this);

//
// Panel to hold buttons for the arm number
//

		JPanel panelArms = new JPanel();
		panelArms.setBorder(new LineBorder(new Color(0, 0, 0)));
		buttonPanel.add(panelArms);
		panelArms.setLayout(new GridLayout(2, 1, 0, 0));

		lblArms = new JLabel("Measuring Arm 1");
		panelArms.add(lblArms);
		lblArms.setHorizontalAlignment(SwingConstants.CENTER);
		lblArms.setFont(new Font("Tahoma", Font.BOLD, 12));

		JPanel panelArmNumber = new JPanel();
		panelArms.add(panelArmNumber);
		panelArmNumber.setLayout(new FlowLayout(FlowLayout.CENTER, 6, 2));

		btn_arms_1 = new JButton("1");
		panelArmNumber.add(btn_arms_1);
		btn_arms_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btn_arms_1.setForeground(Color.red);

		btn_arms_2 = new JButton("2");
		panelArmNumber.add(btn_arms_2);
		btn_arms_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		btn_arms_2.setForeground(Color.red);

		btn_arms_3 = new JButton("3");
		panelArmNumber.add(btn_arms_3);
		btn_arms_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		btn_arms_3.setForeground(Color.red);

		btn_arms_4 = new JButton("4");
		panelArmNumber.add(btn_arms_4);
		btn_arms_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		btn_arms_4.setForeground(Color.red);

		btn_arms_5 = new JButton("5");
		panelArmNumber.add(btn_arms_5);
		btn_arms_5.setFont(new Font("Tahoma", Font.BOLD, 12));
		btn_arms_5.setForeground(Color.red);

		btn_arms_6 = new JButton("6");
		panelArmNumber.add(btn_arms_6);
		btn_arms_6.setFont(new Font("Tahoma", Font.BOLD, 12));
		btn_arms_6.setForeground(Color.red);

		btn_arms_6.addActionListener(this);
		btn_arms_5.addActionListener(this);
		btn_arms_4.addActionListener(this);
		btn_arms_3.addActionListener(this);
		btn_arms_2.addActionListener(this);
		btn_arms_1.addActionListener(this);

//
// Panel to hold the chirality buttons
//

		JPanel panelChirality = new JPanel();
		panelChirality.setBorder(new LineBorder(new Color(0, 0, 0)));
		buttonPanel.add(panelChirality);
		panelChirality.setLayout(new GridLayout(2, 1, 0, 0));

		lblChirality = new JLabel("Chirality");
		lblChirality.setBackground(SystemColor.text);
		panelChirality.add(lblChirality, BorderLayout.CENTER);
		lblChirality.setHorizontalAlignment(SwingConstants.CENTER);
		lblChirality.setFont(new Font("Tahoma", Font.BOLD, 12));

		JPanel panelChirBtns = new JPanel();
		panelChirBtns.setLayout(new FlowLayout());
		panelChirality.add(panelChirBtns);

		chir_btn_s = new JButton("S-Wise");
		chir_btn_s.addActionListener(this);
		panelChirBtns.add(chir_btn_s);

		chir_btn_z = new JButton("Z-Wise");
		chir_btn_z.addActionListener(this);
		panelChirBtns.add(chir_btn_z);

		chir_btn_s.setFont(new Font("Tahoma", Font.BOLD, 12));
		chir_btn_z.setFont(new Font("Tahoma", Font.BOLD, 12));
		resetChirBtns();

//
// Panel to hold the core radius controls
//

		JPanel panelR0 = new JPanel();
		panelR0.setBorder(new LineBorder(new Color(0, 0, 0)));
		buttonPanel.add(panelR0);
		panelR0.setLayout(new GridLayout(3, 1, 0, 0));

		lblR0 = new JLabel("Radius (pixels) = 25.0");
		panelR0.add(lblR0);
		lblR0.setHorizontalAlignment(SwingConstants.CENTER);
		lblR0.setFont(new Font("Tahoma", Font.BOLD, 12));

		r0slider = new JSlider();
		r0slider.setAlignmentY(Component.TOP_ALIGNMENT);
		panelR0.add(r0slider);
		r0slider.setFont(new Font("Tahoma", Font.BOLD, 7));
		r0slider.setPaintLabels(true);
		r0slider.setSnapToTicks(false);
		r0slider.setBorder(null);
		r0slider.setValue((int) r0);
		r0slider.setPaintTicks(true);
		r0slider.setMinorTickSpacing(5);
		r0slider.setMaximum(120);
		r0slider.setMajorTickSpacing(10);
		r0slider.addChangeListener(this);

		JPanel r0PnBtns = new JPanel();
		panelR0.add(r0PnBtns);
		r0PnBtns.setLayout(new FlowLayout(FlowLayout.CENTER, 6, 2));
		btn_r0_n1 = new JButton("-1");
		btn_r0_n1.setFont(new Font("Tahoma", Font.BOLD, 12));
		r0PnBtns.add(btn_r0_n1);
		btn_r0_n1.addActionListener(this);

		btn_r0_p1 = new JButton("+1");
		btn_r0_p1.setFont(new Font("Tahoma", Font.BOLD, 12));
		r0PnBtns.add(btn_r0_p1);
		btn_r0_p1.addActionListener(this);

		btn_r0_n10 = new JButton("-10");
		btn_r0_n10.setFont(new Font("Tahoma", Font.BOLD, 12));
		r0PnBtns.add(btn_r0_n10);
		btn_r0_n10.addActionListener(this);

		btn_r0_p10 = new JButton("+10");
		btn_r0_p10.setFont(new Font("Tahoma", Font.BOLD, 12));
		r0PnBtns.add(btn_r0_p10);
		btn_r0_p10.addActionListener(this);

//
// Panel to hold the rotation controls
//

		JPanel panelRot = new JPanel();
		buttonPanel.add(panelRot);
		panelRot.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelRot.setLayout(new GridLayout(3, 1, 0, 0));

		lblRot = new JLabel("Rotation (Degrees) = 0.0");
		panelRot.add(lblRot);
		lblRot.setHorizontalAlignment(SwingConstants.CENTER);
		lblRot.setFont(new Font("Tahoma", Font.BOLD, 12));

		rotSlider = new JSlider();
		rotSlider.setAlignmentY(Component.TOP_ALIGNMENT);
		panelRot.add(rotSlider);
		rotSlider.setSnapToTicks(false);
		rotSlider.setPaintLabels(true);
		rotSlider.setFont(new Font("Tahoma", Font.BOLD, 7));
		rotSlider.setValue((int) rot);
		rotSlider.setMinorTickSpacing(10);
		rotSlider.setMajorTickSpacing(30);
		rotSlider.setMinimum(-180);
		rotSlider.setMaximum(180);
		rotSlider.setPaintTicks(true);
		rotSlider.addChangeListener(this);

		JPanel rotPnBtns = new JPanel();
		panelRot.add(rotPnBtns);
		rotPnBtns.setLayout(new FlowLayout(FlowLayout.CENTER, 6, 2));

		btn_rot_n1 = new JButton("-1");
		rotPnBtns.add(btn_rot_n1);
		btn_rot_n1.setFont(new Font("Tahoma", Font.BOLD, 12));

		btn_rot_p1 = new JButton("+1");
		rotPnBtns.add(btn_rot_p1);
		btn_rot_p1.setFont(new Font("Tahoma", Font.BOLD, 12));

		btn_rot_n5 = new JButton("-5");
		rotPnBtns.add(btn_rot_n5);
		btn_rot_n5.setFont(new Font("Tahoma", Font.BOLD, 12));

		btn_rot_p5 = new JButton("+5");
		rotPnBtns.add(btn_rot_p5);
		btn_rot_p5.setFont(new Font("Tahoma", Font.BOLD, 12));
		btn_rot_p5.addActionListener(this);
		btn_rot_n5.addActionListener(this);
		btn_rot_p1.addActionListener(this);
		btn_rot_n1.addActionListener(this);

//
// Panel to hold the pitch angle controls
//

		JPanel panelPA = new JPanel();
		buttonPanel.add(panelPA);
		panelPA.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelPA.setLayout(new GridLayout(3, 1, 0, 0));

		lblPA = new JLabel("Pitch Angle (Degrees) = 25.0");
		lblPA.setBackground(SystemColor.text);
		panelPA.add(lblPA);
		lblPA.setHorizontalAlignment(SwingConstants.CENTER);
		lblPA.setFont(new Font("Tahoma", Font.BOLD, 12));

		sliderpa = new JSlider();
		panelPA.add(sliderpa);
		sliderpa.setAlignmentY(Component.TOP_ALIGNMENT);
		sliderpa.setFont(new Font("Tahoma", Font.BOLD, 7));
		sliderpa.setBorder(null);
		sliderpa.setSnapToTicks(false);
		sliderpa.setPaintLabels(true);
		sliderpa.setPaintTicks(true);
		sliderpa.setValue((int) pa);
		sliderpa.setMinorTickSpacing(5);
		sliderpa.setMajorTickSpacing(15);
		sliderpa.setMaximum(90);
		sliderpa.addChangeListener(this);

		JPanel paPnBtns = new JPanel();
		panelPA.add(paPnBtns);
		paPnBtns.setLayout(new FlowLayout(FlowLayout.CENTER, 6, 2));

		btn_pa_n1 = new JButton("-1");
		paPnBtns.add(btn_pa_n1);
		btn_pa_n1.setFont(new Font("Tahoma", Font.BOLD, 12));

		btn_pa_p1 = new JButton("+1");
		paPnBtns.add(btn_pa_p1);
		btn_pa_p1.setFont(new Font("Tahoma", Font.BOLD, 12));

		btn_pa_n5 = new JButton("-5");
		paPnBtns.add(btn_pa_n5);
		btn_pa_n5.setFont(new Font("Tahoma", Font.BOLD, 12));

		btn_pa_p5 = new JButton("+5");
		paPnBtns.add(btn_pa_p5);
		btn_pa_p5.setFont(new Font("Tahoma", Font.BOLD, 12));
		btn_pa_p5.addActionListener(this);
		btn_pa_n5.addActionListener(this);
		btn_pa_p1.addActionListener(this);
		btn_pa_n1.addActionListener(this);

//
// Panel to hold the sweep buttons
//

		JPanel SweepPanel = new JPanel();
		SweepPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		buttonPanel.add(SweepPanel);
		SweepPanel.setLayout(new GridLayout(2, 1));

		lblsweep = new JLabel("Sweep (Degrees) = " + sweep);
		lblsweep.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblsweep.setHorizontalAlignment(SwingConstants.CENTER);
		SweepPanel.add(lblsweep);

		JPanel sweeper = new JPanel();
		SweepPanel.add(sweeper);
		sweeper.setLayout(new FlowLayout(FlowLayout.CENTER, 6, 2));

		S90 = new JButton("90");
		S90.addActionListener(this);
		S90.setFont(new Font("Tahoma", Font.BOLD, 12));
		sweeper.add(S90);

		S180 = new JButton("180");
		S180.addActionListener(this);
		S180.setFont(new Font("Tahoma", Font.BOLD, 12));
		sweeper.add(S180);

		S270 = new JButton("270");
		S270.addActionListener(this);
		S270.setFont(new Font("Tahoma", Font.BOLD, 12));
		sweeper.add(S270);

		S360 = new JButton("360");
		S360.addActionListener(this);
		S360.setFont(new Font("Tahoma", Font.BOLD, 12));
		sweeper.add(S360);

//
// Panel to hold the arm counting buttons
//

		JPanel CountPanel = new JPanel();
		CountPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		buttonPanel.add(CountPanel);
		CountPanel.setLayout(new GridLayout(2, 1));

		lblcnt = new JLabel("Arm Count = " + current_count);
		lblcnt.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblcnt.setHorizontalAlignment(SwingConstants.CENTER);
		lblcnt.setForeground(Color.red);
		CountPanel.add(lblcnt);

		JPanel counter = new JPanel();
		CountPanel.add(counter);
		counter.setLayout(new FlowLayout(FlowLayout.CENTER, 6, 2));

		ac1 = new JButton("1");
		ac1.addActionListener(this);
		ac1.setFont(new Font("Tahoma", Font.BOLD, 12));
		counter.add(ac1);

		ac2 = new JButton("2");
		ac2.addActionListener(this);
		ac2.setFont(new Font("Tahoma", Font.BOLD, 12));
		counter.add(ac2);

		ac3 = new JButton("3");
		ac3.addActionListener(this);
		ac3.setFont(new Font("Tahoma", Font.BOLD, 12));
		counter.add(ac3);

		ac4 = new JButton("4");
		ac4.addActionListener(this);
		ac4.setFont(new Font("Tahoma", Font.BOLD, 12));
		counter.add(ac4);

		ac5 = new JButton("5");
		ac5.addActionListener(this);
		ac5.setFont(new Font("Tahoma", Font.BOLD, 12));
		counter.add(ac5);

		ac6 = new JButton("6");
		ac6.addActionListener(this);
		ac6.setFont(new Font("Tahoma", Font.BOLD, 12));
		counter.add(ac6);

//
// Panel for data write buttons
//

		JPanel panelData = new JPanel();
		panelData.setBorder(new LineBorder(new Color(0, 0, 0)));
		buttonPanel.add(panelData);
		panelData.setLayout(new GridLayout(2, 1, 0, 0));

		lblData = new JLabel("Save Measurements to Data File");
		panelData.add(lblData);
		lblData.setHorizontalAlignment(SwingConstants.CENTER);
		lblData.setFont(new Font("Tahoma", Font.BOLD, 12));

		JPanel panelDataBtns = new JPanel();
		panelData.add(panelDataBtns);
		panelDataBtns.setLayout(new FlowLayout(FlowLayout.CENTER, 6, 2));

		save_grp = new ButtonGroup();
		btn_best = new JRadioButton("Best Fit");
		save_grp.add(btn_best);
		btn_best.setFont(new Font("Tahoma", Font.BOLD, 12));
		panelDataBtns.add(btn_best);
		btn_best.setForeground(Color.red);

		btn_high = new JRadioButton("High Fit");
		save_grp.add(btn_high);
		btn_high.setFont(new Font("Tahoma", Font.BOLD, 12));
		panelDataBtns.add(btn_high);
		btn_high.setForeground(Color.red);

		btn_low = new JRadioButton("Low Fit");
		save_grp.add(btn_low);
		btn_low.setFont(new Font("Tahoma", Font.BOLD, 12));
		panelDataBtns.add(btn_low);
		btn_low.setForeground(Color.red);

		btn_save = new JButton("Save");
		panelDataBtns.add(btn_save);
		btn_save.setFont(new Font("Tahoma", Font.BOLD, 12));

		btn_save.addActionListener(this);
		update(this.getGraphics());
		mySpiral.setVisible(true);
		}

//
// Main event handling code
//

	public void actionPerformed(ActionEvent e)
		{
		Object src = e.getSource();

		if(src == btn_r0_n1) r0--;
		if(src == btn_r0_p1) r0++;
		if(src == btn_r0_n10) r0-=10;
		if(src == btn_r0_p10) r0+=10;

		if(src == btn_rot_n1) rot--;
		if(src == btn_rot_p1) rot++;
		if(src == btn_rot_n5) rot-=5;
		if(src == btn_rot_p5) rot+=5;

		if(src == btn_pa_n1) pa-=1;
		if(src == btn_pa_p1) pa+=1;
		if(src == btn_pa_n5) pa-=5;
		if(src == btn_pa_p5) pa+=5;

		if(src == btn_arms_1) arm = 1;
		if(src == btn_arms_2) arm = 2;
		if(src == btn_arms_3) arm = 3;
		if(src == btn_arms_4) arm = 4;
		if(src == btn_arms_5) arm = 5;
		if(src == btn_arms_6) arm = 6;

		if(src == chir_btn_s) chir = 1.0;
		if(src == chir_btn_z) chir = -1.0;

		if(src == S90) sweep = 90.0;
		if(src == S180) sweep = 180.0;
		if(src == S270) sweep = 270.0;
		if(src == S360) sweep = 360.0;

		if(src == ac1) current_count = 1;
		if(src == ac2) current_count = 2;
		if(src == ac3) current_count = 3;
		if(src == ac4) current_count = 4;
		if(src == ac5) current_count = 5;
		if(src == ac6) current_count = 6;

		if (current_count > 0) lblcnt.setForeground(Color.black);

		if (src == enter_uid)
			{
			uid_entered = true;
			uid = enter_uid.getText();
			lblUid.setForeground(Color.black);
			}
		if(src == next_image)
			{
			if ((prev_dir == "<None>") || (prev_file==0))
				{
				infoBox("Must select an image filename before next can be used","ERROR");
				return;
				}
			if (prev_file==10000)
				{
				infoBox("No more files (at 10000)","ERROR");
				return;
				}
			prev_file++;
			String nstr=String.format("%04d",prev_file);

			File f = new File(prev_dir);

			FilenameFilter text_f = new FilenameFilter()
				{
				public boolean accept(File dir, String name)
					{
					String lcn = name.toLowerCase();
					if (lcn.startsWith(nstr))
						{
						return true;
						}
					else
						{
						return false;
						}
					}
				};

			File[] resf = f.listFiles(text_f);
			try
				{
				img = ImageIO.read(resf[0]);
				}
			catch (IOException ioe)
				{
				infoBox("I/O Exception Reading Image File"+ioe.getMessage(),"ERROR");
				return;
				}

			width = img.getWidth();
			height = img.getHeight();
			center_x = width;
			center_y = height;
			Image_File = resf[0].getName();
			zoom_level=1.0;
			arm = 1;
			current_count=0;
			lblImgFile.setText("Image: "+Image_File);
			lblImgFile.setForeground(Color.black);
			lblcnt.setForeground(Color.red);
			Arrays.fill(arm_map[BEST], Boolean.FALSE);
			Arrays.fill(arm_map[HIGH], Boolean.FALSE);
			Arrays.fill(arm_map[LOW], Boolean.FALSE);
			update(getGraphics());
			}

		if(src == open_image)
			{
			FileDialog dialog = new FileDialog(frame,"Select File to Measure", FileDialog.LOAD);
			dialog.setDirectory(".");
			dialog.setVisible(true);
			String fd_name = dialog.getFile();
			String fd_dir = dialog.getDirectory();
			if ((fd_name == null) || (fd_dir == null)) return;
			File file = new File(fd_dir,fd_name);

			try
				{
				img = ImageIO.read(file);
				}
			catch (IOException ioe)
				{
				infoBox("I/O Exception Reading Image File"+ioe.getMessage(),"ERROR");
				return;
				}
			if (SG_TRACING == true)
				{
				String pstr=dialog.getFile().substring(0,4);
				prev_file=Integer.valueOf(pstr);
				prev_dir=dialog.getDirectory();
				}

			width = img.getWidth();
			height = img.getHeight();
			center_x = width;
			center_y = height;
			Image_File = file.getName();
			zoom_level=1.0;
			current_count=0;
			arm = 1;
			lblImgFile.setText("Image: "+Image_File);
			lblImgFile.setForeground(Color.black);
			lblcnt.setForeground(Color.red);
			Arrays.fill(arm_map[BEST], Boolean.FALSE);
			Arrays.fill(arm_map[HIGH], Boolean.FALSE);
			Arrays.fill(arm_map[LOW], Boolean.FALSE);
			update(getGraphics());
			}
		if(src == quit_app)
			{
			try
				{
				if (data_file != "<None>") out_data.close();
				}
			catch (IOException ioe)
				{
				System.out.println("Error saving data file "+data_file);
				}
			frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
			}
		if(src == data_csv)
			{
			FileDialog dialog = new FileDialog(frame,"Select File to Record Measurements", FileDialog.SAVE);
			dialog.setDirectory(".");
			dialog.setVisible(true);
			String fd_name = dialog.getFile();
			String fd_dir = dialog.getDirectory();
			if ((fd_name == null) || (fd_dir == null)) return;
			File file = new File(fd_dir,fd_name);

			boolean newfile = false;

			try
				{
				if (!file.exists()) newfile=true;
				if (out_data != null) out_data.close();
				out_data = new FileWriter(file,true);
				if (newfile)
					{
					String line = "name,uid,arm,fit,chir,r0,rot,pa,sweep,arm_count,zoom\n";
					out_data.write(line);
					out_data.flush();
					}
				}
			catch (IOException ioe)
				{
				infoBox("Error Opening Output Data File"+ioe.getMessage(),"ERROR");
				return;
				}
			data_file = file.getName();
			lblDatFile.setText("Data File: "+data_file);
			lblDatFile.setForeground(Color.black);
			update(getGraphics());
			}

		if(src == img_inv_btn)
			{
			for (int xx = 0; xx < img.getWidth(); xx++)
				{
				for (int yy = 0; yy < img.getHeight(); yy++)
					{
					int rgba = img.getRGB(xx,yy);
					Color col = new Color(rgba,true);
					col = new Color(255-col.getRed(), 255-col.getGreen(),255-col.getBlue());
					img.setRGB(xx,yy,col.getRGB());
					}
				}
			}
		if(src == zoom_in_btn)
			{
			width*=2;
			height*=2;
			center_x*=2;
			center_y*=2;
			zoom_level*=2;

//
// Create a copy of the original image
//

			BufferedImage tmp = new BufferedImage(img.getWidth(), img.getHeight(), img.getType());
			Graphics g = tmp.getGraphics();
			g.drawImage(img, 0, 0, null);

//
// Rescale image
//

			img = new BufferedImage(width,height,tmp.getType());
			Graphics g2 = img.createGraphics();
			g2.drawImage(tmp, 0,0,width, height, 0, 0, tmp.getWidth(), tmp.getHeight(), null);
			g.dispose();
			g2.dispose();
			update(getGraphics());
			}
		if (src == zoom_out_btn)
			{
			width/=2;
			height/=2;
			center_x/=2;
			center_y/=2;
			zoom_level/=2.0;

//
// Create a copy of the original image
//

			BufferedImage tmp = new BufferedImage(img.getWidth(), img.getHeight(), img.getType());
			Graphics g = tmp.getGraphics();
			g.drawImage(img, 0, 0, null);

//
// Rescale image
//

			img = new BufferedImage(width,height,tmp.getType());
			Graphics g2 = img.createGraphics();

			g2.drawImage(tmp, 0,0,width, height, 0, 0, tmp.getWidth(), tmp.getHeight(), null);
			g.dispose();
			g2.dispose();
			update(getGraphics());
			}
		if (src == cols)
			{
			String col_choice = (String) cols.getSelectedItem();
			switch(col_choice)
				{
				case "Magenta":
					{
					spiral_color = Color.magenta.darker();
					break;
					}
				case "Green":
					{
					spiral_color = Color.green.darker();
					break;
					}
				case "Red":
					{
					spiral_color = Color.red.darker();
					break;
					}
				case "Blue":
					{
					spiral_color = Color.blue.darker();
					break;
					}
				case "Yellow":
					{
					spiral_color = Color.yellow.darker();
					break;
					}
				case "Black":
					{
					spiral_color = Color.black.darker();
					break;
					}
				}
			}

//
// The next few conditionals are for the data output.  The format for the
//   output is a CSV file with the following fields:
//       Name    - The name of the current image file
//       User Id - The id code entered
//       Arm     - The number of the arm being measured
//       Fit     - Either Best, Low, or High
//       Chir    - The Chirality, -1.0 for Z-wise and 1.0 for S-wise
//       R0      - The radius of the core (in pixels)
//       Rot     - The rotation value (in degrees)
//       PA      - The pitch angle (in degrees)
//       Sweep   - Azimuthal value used
//       Zoom    - The level to which the image was zoomed for the measurement
//
// This data cannot be written if the image_file, data_file and uid are not
//   defined.
//

		if(src == btn_save)
			{
			if ((!uid_entered) || (Image_File == "<None>") || (data_file == "<None>") || (current_count < 1) || (save_grp.getSelection() == null))
				{
				infoBox("Image filename, data filename, user id, arm count, and at least one of the fit (Best, Low, or High) buttons must be selected before any measurements be saved","NOTE");
				return;
				}

			if (btn_best.isSelected())
				{
				if (arm_map[BEST][arm])
					{
					int retval = JOptionPane.showConfirmDialog(null,"Are you sure you want to write this?", "Duplicate Measurement",JOptionPane.YES_NO_OPTION);
					if (retval == 1) return;
					}
				fit_type="best";
				}
			if (btn_low.isSelected())
				{
				if (arm_map[LOW][arm])
					{
					int retval = JOptionPane.showConfirmDialog(null,"Are you sure you want to write this?", "Duplicate Measurement",JOptionPane.YES_NO_OPTION);
					if (retval == 1) return;
					}
				fit_type="low";
				}
			if (btn_high.isSelected())
				{
				if (arm_map[HIGH][arm])
					{
					int retval = JOptionPane.showConfirmDialog(null,"Are you sure you want to write this?", "Duplicate Measurement",JOptionPane.YES_NO_OPTION);
					if (retval == 1) return;
					}
				fit_type="high";
				}

			String line = String.format("%s,%s,%d,%s,%f,%f,%f,%f,%f,%d,%f\n",Image_File,uid,arm,fit_type,chir,r0,rot,pa,sweep,current_count,zoom_level);
			try
				{
				out_data.write(line);
				out_data.flush();
				}
			catch (IOException ioe)
				{
				infoBox("Error Writing to Data File"+ioe.getMessage(),"ERROR");
				return;
				}

			if (btn_best.isSelected()) arm_map[BEST][arm]=true;
			if (btn_low.isSelected()) arm_map[LOW][arm]=true;
			if (btn_high.isSelected()) arm_map[HIGH][arm]=true;
			}

//
// Value checking to make sure they are in range
//

		if(r0 < 0) r0 = 0;
		if(rot < -180.0) rot = -180.0;
		if(rot > 180) rot = 180.0;
		if(pa < 0) pa = 0.0;
		if(pa > 90) pa = 90.0;
		reset();
		}

	@Override
	public void stateChanged(ChangeEvent e)
		{
		JSlider src = (JSlider)e.getSource();
		if (src == sliderpa && pa!=sliderpa.getValue())
			{
			pa = src.getValue();
			reset();
			}
		if(src == r0slider && r0!=r0slider.getValue())
			{
			r0 = src.getValue();
			reset();
			}
		if(src == rotSlider && rot!=rotSlider.getValue())
			{
			rot = src.getValue();
			reset();
			}

//
// You might be asking why i don't put reset() outside the loop.
//   the answer is that when non-slider things happen, this also gets called
//   so reset() was not letting me change values because it always reset twice
//
		}

	public void resetLabels()
		{
		lblR0.setText("Radius (pixels) = " + r0);
		lblRot.setText("Rotation (Degrees) = " + rot);
		lblPA.setText("Pitch Angle (Degrees) = " + pa);
		lblsweep.setText("Sweep (Degrees) = "+sweep);
		lblcnt.setText("Arm Count = " + current_count);
		if(arm != 1) {lblArms.setText("Measuring Arm "+ arm);}
		else {lblArms.setText("Measuring Arm 1");}
		}

	public void resetSliders()
		{
		sliderpa.setValue((int)pa);
		r0slider.setValue((int)r0);
		rotSlider.setValue((int)rot);
		}

	public void reset()
		{
		resetRadio();
		resetChirBtns();
		resetArmBtns();
		resetLabels();
		resetSliders();
		update(getGraphics());
		}

	public void update(Graphics g)
		{
		center.clear();
		super.update(g);
		mySpiral.setVisible(true);
		}

	public void resetChirColor()
		{
		chir_btn_s.setForeground(Color.black);
		chir_btn_z.setForeground(Color.black);
		}

	public void resetChirBtns()
		{
		resetChirColor();
		if(chir == 1.0) chir_btn_s.setForeground(Color.black);
		if(chir == -1.0) chir_btn_z.setForeground(Color.black);
		}

	public void resetArmColor()
		{
		btn_arms_1.setForeground(Color.red);
		btn_arms_2.setForeground(Color.red);
		btn_arms_3.setForeground(Color.red);
		btn_arms_4.setForeground(Color.red);
		btn_arms_5.setForeground(Color.red);
		btn_arms_6.setForeground(Color.red);
		}

	public void resetRadio()
		{
		if (arm_map[BEST][arm]==true) btn_best.setForeground(Color.black);
		else btn_best.setForeground(Color.red);
		if (arm_map[HIGH][arm]==true) btn_high.setForeground(Color.black);
		else btn_high.setForeground(Color.red);
		if (arm_map[LOW][arm]==true) btn_low.setForeground(Color.black);
		else btn_low.setForeground(Color.red);
		}

	public void resetArmBtns()
		{
		if(arm_map[BEST][1] && arm_map[HIGH][1] && arm_map[LOW][1]) btn_arms_1.setForeground(Color.black);
		else btn_arms_1.setForeground(Color.red);
		if(arm_map[BEST][2] && arm_map[HIGH][2] && arm_map[LOW][2]) btn_arms_2.setForeground(Color.black);
		else btn_arms_2.setForeground(Color.red);
		if(arm_map[BEST][3] && arm_map[HIGH][3] && arm_map[LOW][3]) btn_arms_3.setForeground(Color.black);
		else btn_arms_3.setForeground(Color.red);
		if(arm_map[BEST][4] && arm_map[HIGH][4] && arm_map[LOW][4]) btn_arms_4.setForeground(Color.black);
		else btn_arms_4.setForeground(Color.red);
		if(arm_map[BEST][5] && arm_map[HIGH][5] && arm_map[LOW][5]) btn_arms_5.setForeground(Color.black);
		else btn_arms_5.setForeground(Color.red);
		if(arm_map[BEST][6] && arm_map[HIGH][6] && arm_map[LOW][6]) btn_arms_6.setForeground(Color.black);
		else btn_arms_6.setForeground(Color.red);
		}

	public static void infoBox(String InfoMessage, String TitleBar)
		{
		JOptionPane.showMessageDialog(null,InfoMessage,"InfoBox: "+TitleBar, JOptionPane.INFORMATION_MESSAGE);
		}
	}
