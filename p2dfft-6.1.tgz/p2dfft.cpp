//
// P2DFFT.CPP - This program will calculate the 2D FFT for determining pitch
//              angles.
//
//  Version 6.8: 02-Nov-2024
//
//           The program was derived from the original 2DFFT program by the
//           NC Museum of Natural Sciences Astronomy & Astrophysics lab.  It
//           calculates the pitch angles of spiral galaxy arms using the
//           log-polar mapped Fourier transform over a series of annuli.  The
//           annuli have an increasing inner starting radius with a fixed outer
//           radius (by default).  It runs the calculations for each annulus
//           in parallel, which makes for much faster execution on
//           multi-threaded machines.  In addition, there have been some
//           changes to the input to the programs to increase usability.
//           Finally, the program has changed the FFT algorithm to the
//           Harvard "Fastest Fourier Transform in the West" (FFTW3) library.
//
//  2DFFT (Original) Author: Dr. Ivanio Puerari
//                Instituto Nacional de Astrofisca, Optica y Electronica
//                Santa Maria Tonantzintla, Puebla, Mexico
//
//  2DFFT (Revised) Lead Author: Dr. Marc Seigar
//                University of Minnesota, Duluth
//                Duluth, MN USA
//
//  2DFFT (Progenitor of P2DFFT) Lead Author: Dr. Benjamin Davis
//                Swinburne University of Technology,
//                Centre for Astrophysics and Supercomputing,
//                Melbourne, Victoria, Australia
//                http://www.d.umn.edu/~msseigar/2DFFT/2DFFT.tar.gz
//
//  P2DFFT By: Ian Hewitt & Dr. Patrick Treuthardt
//                NC Museum of Natural Sciences
//                Astronomy & Astrophysics Lab,
//                Raleigh, NC USA
//                https://github.com/treuthardt/P2DFFT
//
//  LICENSE
//
//  P2DFFT Spiral Galaxy Arm Pitch Angle Analysis Suite
//  Copyright (c) 2016-2024  Ian B. Hewitt & Dr. Patrick Treuthardt
//
//  The program is free software:  you can redistribute it and/or modify it
//  under the terms of the GNU General Public License as published by the Free
//  Software Foundation, version 3.
//
//  This program is distributed in the hope that it will be useful, but WITHOUT
//  ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or
//  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
//  more details.
//
//  You should have received a copy of the GNU General Public License along with
//  this program.  If not, see < https://www.gnu.org/licenses >.
//
//  The authors can be contacted at:
//
//      North Carolina Museum of Natural Sciences
//      Astronomy & Astrophysics Laboratory
//      11 West Jones Street
//      Raleigh, NC, 27601  USA
//      +1.919.707.9800
//
//      -- or --
//
//      patrick.treuthardt@naturalsciences.org
//
//
//  Usage: p2dfft [-i|--input <file>] [-v|--verbose] [-w|--warn]  [-r|--reverse]
//                [-f|--fixed <size>] [-p|--polar] [-m|--mask 0,1] [-s|--snr]
//                [-h|--highpass] [-d|--data] [<FITS files>]
//
//         p2dfft will process a list of files.  These files can come from
//         standard input, the command line, or an input file.  The files can
//         be binary FITS files or ASCII text FITS files. By default, no
//         radius or output file prefix needs to be provided as these will
//         determined by the program.
//
//         There are several options:
//              -i|--input  : Will read file names, results file, and radius
//                            from the parameter file specified
//              -v|--verbose: Prints status messages during the
//                            processing (good for those who like to see
//                            things during a run).
//              -q|--quiet:   Suppresses all status messages (useful in scripts)
//              -w|--warn:    Causes warnings to be printed when individual
//                            values are not rational or minor processing
//                            problems are discovered.  This will slow
//                            performance and is mainly useful if unexpected
//                            results are seen.
//              -r|--reverse: By default the pitch angle is calculated using
//                            different annuli with increasing inner radius,
//                            this option performs the calculations with
//                            annuli with decreasing outer radius.
//              -f|--fixed  : Use annuli with a fixed radius (specified by
//                            the argument to fixed.  The inner radius of
//                            the annuli will start from 1 and increase but
//                            the end will always be the start value plus the
//                            argument to fixed.
//              -p|--polar  : Generate a FITS file with the logarithmic polar
//                            mapping used by P2DFFT.
//              -m|--mask   : Option to mask bright values (core and bulge).
//                            A value of 0 will mask out any values >= to the
//                            value at the center.  A mask value of 1 will
//                            calculate the highest radius of continuous
//                            values that have a value >= the center value
//                            and will eliminate (zero) all values in the polar
//                            plot below that radius.  This eliminates
//                            structural artifacts that could affect the
//                            data when a mask value of 0 is used.
//              -s|--snr    : Calculate the signal-to-noise ratio and the
//                            full width half maximum of the FFT data peak
//              -h|--highpass: Apply a high pass filter to the results after
//                             the low pass filter is applied (experimental)
//              -d|--data   : Write a binary file the base name and the suffix
//                            of .fft containing the FFT output matrix
//
//
//  Input formats:
//
//         Command Line Arguments - The file names of binary FITS and ASCII
//         text files are specified on the command line.  The result file for
//         each file will be all characters of the file name before the first
//         occurrence of a "."  The radius will be the maximum radius based on
//         the size of the image.
//
//         Parameter File - The format of the parameter file is:
//
//           image_file_1,result_file_1,outer_radius_1
//           image_file_2,result_file_2,outer_radius_2
//           image_file_3,result_file_3,outer_radius_3
//           image_file_etc,result_file_etc,outer_radius_etc
//
//        The result file name and radius are optional and so are the commas
//        for those fields (e.g. you can just have a line like "image_file_1"
//        or "image_file_1,result_file_1".  If they are not specified, the
//        program will calculate them.  Previous scripter input files can be
//        used as inputs to this version of p2dfft.  Blank lines are allowed
//        in the file, but are no longer needed and will be ignored.
//
//        Standard Input - The standard input format is for compatibility
//        with older scripts generated by scripter.  The expected format is
//        (one per line):
//
//           image_file_name
//           result_file
//           keyword
//           radius
//
//        Only one file can be read from standard input.  The keyword is kept
//        for compatibility reasons, but not used in P2DFFT v5.0+
//
//  Version History:
//      6.8  02-Nov-2024 - Remove special compilation includes which are no
//                         needed after to switching to a CMAKE build system
//                       - Removed parallel multi-threading code since there is
//                         a problem on some systems. The change will be done
//                         in version 7.0 of p2dfft.cpp
//      6.7  21-Sep-2023 - Change default background value to be 0.1
//      6.6  03-Sep-2022 - Remove deprecated code and spell check comments
//                       - Fix memory leak where running large (> 10,000)
//                         numbers of files would consume > 20 GB of memory
//      6.5  23-Nov-2021 - Correct bug in fixed annuli code that caused code
//                         crashes by not calculating the annuli bounds
//                         correctly
//      6.4  18-Oct-2021 - Add -q option for use in batch scripts
//                       - Remove the code to process ASCII FITS and the
//                         compatability to take 2dfft scripts via stdin
//                       - Improve code by explicitly checking for return
//                         values instead of relying on implicit value
//                       - Rewrite the code to wrote all the intermediate data
//                         and the raw data (if the -d option is selected) to
//                         an HDF5 data file.  Also change the intermediate
//                         data to only store the FFT output data and no longer
//                         store the amplitude and frequency.
//                       - Change the first column of the per mode radius/PA
//                         files to remove outi_ prefix and just make it
//                         equal to the radius
//                       - Change the parameter file so the radius file
//                         precedes the output file prefix
//                       - Fix bug in fixed width annuli code where no results
//                         could be produced for valid input
//                       - Fix bug where 0.0 values could show up as -0.0
//      6.3  17-Dec-2020 - Update error messages for enumerated types in
//                         pitch_class.h and astro_class.h
//                       - Change flags from integer to boolean
//                       - Updated to new style include syntax
//                       - Switch to C++ filesystem library
//                       - Switch to streams for all I/O
//                       - Change char* and functions to strings
//                       - Change deprecated functions to pointer safe ones
//                       - Remove macros
//                       - Make exit codes consistent
//                       - Update printed error messages
//                       - Fix bug in deprojecting rectangular images
//                       - Fix incorrect/outdated comments
//                       - Add additional debug code
//                       - Fix small bug in debug output code
//                       - Change to explicit null ptr values/checks
//                       - Change some ambiguous variable names
//                       - Change code to not exit for certain errors, but to
//                         just skip to the next file
//                       - Remove file/path processing and switch to astro_class
//                         function remove_path_extension() to correct path/file
//                         processing
//                       - Fix bug in parameter file parsing
//                       - Improve .rip/.dat file error handling
//                       - Fix bug in radius value output in .rip file
//      6.2  25-Jun-2020 - Remove code for summed FFT output files (since this
//                         is not used)
//                       - Fix bug in the fftw input matrix where the real
//                         component was sign reversed instead of the imaginary
//                         component.  This created an inverse image, but still
//                         returned accurate pitch angles.
//                       - Removed the experimental -z option since it did not
//                         improve the algorithm
//                       - Made some changes in type casting that prevented
//                         compilation on later Mac systems
//                       - Changed some deprecated functions to more modern
//                         versions
//      6.1  04-May-2020 - Add check for parameter (input) file to insure it is
//                         a text file
//                       - Change references for input file to parameter file
//                       - Fix implicit returns from astro class to specific
//                         astro_class.h return codes
//                       - Change mapping of input FITS files to match that
//                         used in 2DFFT.  This has a very small effect on
//                         pitch angles, but a significant one on phase angles
//                       - Fix incorrect version numbers in comments and code
//                       - Improve error message text and add some additional
//                         printed error messages
//                       - Small changes to correct for difference in negative
//                         transform used by FFTW and positive used in older
//                         numerical recipes FFT routine
//                       - Added -s option to make SNR and FWHM calculations
//                         optional
//                       - Fixed deprecated and missing command line options in
//                         the code and command help text
//                       - Added additional compile time debug option, DEBUG_MAP
//      6.0  19-Dec-2019 - Fix bug in fixed which caused no PA's to be found
//                       - Minor comment cleanup
//                       - Fix missing library call needed to build on Mac
//      5.9  20-Jun-2019 - Remove incorrect FFT row sense fix
//      5.8  02-Jun-2019 - Change 2D FFT row sense to correct bug left over
//                         from FFTW migrations and to improve accuracy
//                       - Remove deprecated leftover -s argument code
//      5.7  21-May-2019 - Fix incorrect original author attribution with
//                         apologies to those previously left out of the list
//      5.6  08-May-2019 - Eliminate the -s option so the program will always
//                         create the FFT data files
//                       - Add additional debugging to show .rip file mapping
//      5.5  18-Dec-2018 - Fix bug where save files are not created in the
//                         current working directory if fits file is not
//                         located in the current working directory
//                       - Fix bug where failure to write the the .dat or
//                         .rip files would cause a crash
//      5.4  20-Oct-2018 - Change the version printing to only happen when -v
//                         is specified
//                       - Add -m|--mask option to mask bright core values
//                       - Add -z|--zero option to add artificial FFT window
//                       - add -p|--polar option to generate polar FITS image
//                       - Change the mapping from the fits file to account
//                         for the FITS/C++ row ordering difference.
//                       - Change version printing to only occur with -v
//                       - Bug fix for failure when using non local arguments
//                       - Update comments and remove unused code blocks
//      5.3  19-Jun-2018 - Fix two bugs with sum output to address potential
//                         race conditions which caused indeterminate output
//                       - Fix bug in summation when multiple files specified
//                       - Fix bug in reverse mode where annuli changing in
//                         wrong direction
//      5.2  27-May-2018 - Add -r|--reverse and -f|--fixed options
//                       - Simplify center location logic
//                       - Remove unused variables
//                       - Fix bug that resulted in center being off by 1
//                         for certain sizes
//                       - Update comments/usage info
//                       - Remove unused variables
//                       - Move fftw plan creation so it's only done once
//                       - instead of for every file
//                       - Add summed FFT data files to output
//                       - Remove code to limit threads because it was too
//                         complex for marginal usefulness
//                       - Remove fftw3 multithreaded code and replace with
//                         OpenMP code for better utilization of threads
//                       - Replace fixed frequency values with FREQ constants
//      5.1  15-Mar-2018 - Add support for sn() and fwhm() functions and adding
//                         their results to the output
//                       - Clean up error handling for pitch_class to return
//                         less extraneous output
//                       - Add -w|--warning option to allow/suppress warning
//                         messages being printed
//                       - Fix small bug in getopt_long() call
//                       - Preface each printed message with aa class (warning,
//                         debug, or error)
//                       - Fix bug where an error would not cause an orderly
//                         exit
//                       - Print the total items and how many were successfully
//                         processed at the end of the program
//                       - Significant comment updates
//      5.0  05-Feb-2018 - Change name and comments from 2dfft to p2dfft
//                       - Significant changes to file I/O scheme.  Will no
//                         longer write/use temporary files (.rip & .data)
//                         if saverip is not enabled.
//                       - saverip data files are no longer created in the
//                         current working directory, but are created in the
//                         <result_file> subdirectory.
//                       - Remove external give_maximum_pitch_phase executable
//                         and replace it with a pitch_class function.  This
//                         eliminates the need for FORTRAN and a multitude
//                         of interim working files.
//                       - Remove the code to automatically remove working
//                         files in the current directory and change the code
//                         which creates the <result_file> output files
//                       - Add comments for variables and change some variable
//                         names to de-obfuscate the code :-)
//                       - Clean up version print code and add class versions
//                       - Move global constants to a separate include file
//                       - Remove requirement that images files are square
//                       - Add capability to override default number of threads
//                       - Change DEBUG to be a variable, not a comp. cond.
//                       - Add comments for array mapping information
//                       - Add error handling for output files, including
//                         deselecting saverip if data files can't be opened
//      4.0  28-Aug-2017 - Rewrite program to use FFTW3 libraries
//                       - Make some changes to mapping algorithm to improve
//                         performance
//                       - Eliminate creates of the gal.* file
//                       - Updated header comments
//                       - Add code for more detailed debugging output
//                       - Updated/fixed comments
//                       - Fixed bug in reading from input file where no files
//                         would be found, even in a valid input file
//                       - Minor changes to eliminate compiler warnings on
//                         some Linux distributions
//      3.4  27-Jul-2017 - Print limited status information even when -v is
//                         not specified
//      3.3  09-Jun-2017 - Correct an error in the mapping of ASCII fits files
//                       - Update comments
//                       - Fix some error messages
//                       - Remove deprecated -f/--force_read logic
//                       - Add code to print out version when run
//                       - Correct help printout error
//      3.2  07-Jun-2017 - Print version number to stdout
//      3.1  21-Feb-2017 - Remove unused variable opt_err
//      3.0  20-Feb-2017 - Significant rewrite to add the following changes:
//                          * Move setup blocks of code and rearrange for
//                            readability.
//                          * Move from C to C++ (to get classes)
//                          * Program always builds for for multiple threads
//                            (will still work on single threaded machine)
//                          * Make other compile time options into command line
//                            options (STATUS and SAVE_RIP)
//                          * Add astro class functions for working with
//                            FITS files (see astro_class.cpp)
//                          * Eliminate the need for scripter.  2dfft can
//                            now read the input files originally meant for
//                            scripter.  This is done with the -i option.
//                          * If the input file does not have the result
//                            file (used to be keyword) or radius, it will
//                            be calculated automatically.
//                          * 2dfft can now take image file names via the
//                            command line.
//                          * 2dfft now reads both ASCI FITS image and binary
//                            FITS images (of any sort).
//      2.5  03-Jan-2017 - Add check during reading of input file.  If the file
//                         has a FITS header, it will loop forever.  Now it
//                         will abort with an error message and move on to the
//                         next file.
//      2.4  30-Dec-2016 - Add check for EOF when looking for input file.  This
//                         prevents 2DFFT from getting in an infinite loop when
//                         the input file does not exist.
//      2.3  27-Nov-2016 - Change the program to now look for the
//                         give_maximum_pitch_phase program based on the
//                         BIN_DIR entry in the makefile.  The program will:
//                          * Look in the current directory and use that one
//                          * Look in the BIN_DIR and use that one
//                          * If not found, search some common locations
//                         The first executable version found will be used.
//      2.2  27-Sep-2016 - Some changes to address:
//                          * In parallel mode, add reading of the final output
//                            filename so we can make the *_m[0-6] files
//                            correctly (so it works with scripter.cpp v2.2)
//                          * Reduced loop to calculate one less iteration in
//                            parallel mode to give exact match for old results.
//			    * Fixed bug in non-parallel mode output by setting
//                            radius = r_min.  This allowed a number of
//                            conditional compile statements to be removed,
//                            which simplified the code.
//			    * Fix path name for give_maximum_pitch_phase which
//                            was hard-coded. Now it just relies on it being in
//                            the command path. <This change is deprecated>
//      2.1  26-Sep-2016 - Fixed two subtle race conditions in the parallel
//                         loop.  Also cleaned up STATUS messages to be
//                         cleaner and print less (for better performance)
//      2.0  12-Sep-2016 - Update for openMP parallel threads and to add
//                         compile time options (See Makefile and Readme.txt)
//

#include    <iostream>
#include    <fstream>
#include    <sstream>
#include    <iterator>
#include    <iomanip>
#include    <cmath>
#include    <cstdio>
#include    <cstdlib>
#include    <cstring>
#include    <cerrno>

#include    <filesystem>

#include    <sys/types.h>
#include    <sys/stat.h>

#include    <getopt.h>
#include    <omp.h>

//
// Include fftw3 headers
//

#include    <fftw3.h>

//
// GLOBAL CONSTANTS
//

#include    "globals.h"

//
// Include the Astro Functions class
//

#include    "astro_class.h"
#include    "pitch_class.h"

//
// <TODO> Fix the using directives to be more specific in the next release
//

using namespace std;

//
// Include HDF5 Libraries
//

#include    "H5Cpp.h"

using namespace H5;

//
// Version number definition
//

const string VERSION="6.8/20241102";

//
// These flags will be deprecated in the next release and turned into const_expr
// <TODO>
//

//
// Set this flag to #define to get a data matrix debugging information.  This
//   is independent of the DEBUG flag in globals.h because it produces a lot
//   of output.  Highly recommend redirecting stdout to a file when using this
//   option.
//

#undef      DEBUG_DAT

//
// Set this flag to #define to get a input matrix debugging information.  This
//   is independent of the DEBUG flag in globals.h because it produces a lot
//   of output.  Highly recommend redirecting stdout to a file when using this
//   option.
//

#undef      DEBUG_MAT

//
// Set this flag to #define to get the cartesian 2D to polar mapping numbers
//

#undef      DEBUG_MAP

//
// Set this flag to print out the various sizes and indexes. This is uesful
//   when getting segmentation faults on different machines because there
//   are several parts ot the code that use a rolling counter.
//

#define	    DEBUG_INDEX    false 

//
//   GLOBAL (NON-THREAD) VARIABLES
//

int     c;                 /* Return value for command line options parser   */
int     num;               /* Number of threads on the host machine          */
int     msize;             /* Binary FITS file data size                     */
int     mask=0;            /* Flag for masking only high values              */
int     dindex;            /* Counter for debug statement counting           */
int     fix_w=0;           /* Flag for fixed annuli for calculations         */
int     i, j;              /* Index variables                                */
int     rstart;            /* Starting radius value for the annuli           */
int     counter;           /* Index variable for the polar data array        */
int     x_0, y_0;          /* Cartesian coordinates for the image center     */
int     offset=0;          /* Index for start of image data in input array   */
int     proc_error;        /* Input file error count                         */
int     mask_line=0;       /* Flag for masking on an even line               */
int     input_file=0;      /* Flag to indicate if input file is used         */
int     x_dim, y_dim;      /* The cartesian dimensions of the input file     */

bool    raw=false;         /* Flag for writing raw FFT output data           */
bool    rev=false;         /* Flag to control if inner or outer radius varies*/
bool    warn=false;        /* Flag to indicate if warnings are printed       */
bool    polar=false;       /* Flag to control if polar proj image created    */
bool    quiet=false;       /* Flag for normal status message printing        */
bool    verbose=false;     /* Flag for printing of status messages           */
bool    snr_fwhm=false;    /* Flag for calculating/printing SNR & FWHM data  */
bool    high_pass=false;   /* Flag for applying high pass filter             */

unsigned    int     it;    /* Files vector index variable                    */

char    *tmp;              /* Pointer to string for integer conversion       */
char    *tmps;             /* Temporary string for summary output file name  */
char    *fname;            /* FITS filename                                  */
char    cmd[128];          /* Buffer for system(2) commands                  */


float   **mat;             /* 2D cartesian image data                        */
float   *proj;             /* Polar mapped image data matrix                 */
float   *idata;            /* Input image data matrix                        */
float   ctr_val;           /* Core brightness for masking                    */
float   log_rad;           /* The natural log of the current radius value    */
float   log_bar;           /* The natural log of the bar radius value        */
float   log_itrad;         /* The natural log of the maximum radius value    */
float   freq_counter;      /* Frequency counter value                        */

double  fp_fill=0.0;       /* Fill value for HDF5 data sets                  */
double  norma[MAX_DIM+1];  /* FFT normalization value for each radius        */

string  infile;            /* Input filename for -i                          */
string  keyword;           /* String for intermediate data file prefix       */
string  resultfile;        /* Summary file (*_m[0-6]) file name              */

const   float   radstep=2.0*PI/STEP_P/DIM_RAD;    /* ln-r mapping increment  */
const   float   theta_step=2.0*PI/GR_RAD/DIM_THT; /* Mapping theta increment */

astro   ast;               /* Instantiation of astro_class functions object  */
pitch   pit;               /* Instantiation of pitch_class functions object  */

H5File  out_file;          /* HDF5 Data output file name                     */

hsize_t raw_dim[1] = { DIM_THT * DIM_RAD *2 }; /* Size of raw data space     */
hsize_t data_dim[2] = { 401, 2 }; /* Size of data space for one annuli       */

fftw_plan   plan;          /* FFTW execution plan                            */

DSetCreatPropList   prop_list; /* Property list for HDF5 data set            */

vector  <file_rec>  items; /* Vector of input files                          */

struct  result_pa   mode_data[M_FIN+1][(MAX_DIM/2)+1];   /* FFT analysis data*/

//
// FUNCTIONS
//


//
// FIND_BAR() - This routine is used with the mask option.  It will start by
//              in the center of the image and search for the LARGEST radius
//              which has a pixel value greater than the limit provided.  That
//              will be assumed to be the bar radius.
//
// Arguments:
//      rad -     Outer radius of image
//      x_org -   X coordinate of center point
//      y_org -   Y coordinate of center point
//      lim_val - Limit value for masking
//
// Return Value:
//      Radius of estimated bar
//

float   find_bar(int rad, int x_org, int y_org, float lim_val)
    {
    int     skip;          /* Loop variable set to 1 after low value found   */
    int     aa, bb;        /* Cartesian coordinates of ln(r)/theta in image  */
    int     cnt_rad;       /* Counter for theta steps in radians             */
    int     cnt_tht=1;     /* Counter for theta steps in degrees             */

    float   r;             /* Natural log of radius for a certain point      */
    float   lb;            /* Largest bar radius value                       */
    float   curr;          /* Pixel value at current radius (for slope)      */
    float   prev1;         /* Pixel value at current radius -1 (for slope)   */
    float   prev2;         /* Pixel value at current radius -1 (for slope)   */
    float   prev3;         /* Pixel value at current radius -1 (for slope)   */
    float   xx, yy;        /* Relative cartesian coordinates of ln(r)/theta  */
    float   log_edge;      /* Natural log of current value of radius         */
    float   tht_deg;       /* Current theta (polar angle) in degrees         */
    float   tht_rad;       /* Current theta (polar angle) in radians         */

    if (DEBUG) cout << "Rad=" << rad << ", X_org=" << x_org << ", Y_org=" << y_org << ", Lim_val=" << lim_val << endl;

//
// log() functions are computationally expensive, so calculate the logs
//   outside of the loop.
//

    log_edge=log((double) rad);
    if (DEBUG) cout << "Log_edge=" << log_edge << endl;
    lb=0.0;

//
// Step around theta angles (360 degrees in 0.35 steps)
//

    for(tht_deg=0.0;cnt_tht<=DIM_THT;tht_deg+=theta_step)
        {
        cnt_tht++;
        tht_rad=tht_deg*GR_RAD;
        cnt_rad=1;
        skip=0;
        curr=-65535.0;
        prev1=-65535.0;
        prev2=-65535.0;
        prev3=-65535.0;

//
// Step out along radius steps
//

        for(r=0.0;cnt_rad<=DIM_RAD;r+=radstep)
            {
            cnt_rad++;

            if (skip) continue;
            if (r > log_edge) continue;

            xx=expf(r)*cosf(tht_rad);
            yy=expf(r)*sinf(tht_rad);

            aa=(int)xx+x_org;
            bb=(int)yy+y_org;

//
// Set the slope values for calculation
//

            prev3=prev2;
            prev2=prev1;
            prev1=curr;
            curr=mat[aa][bb];


            if (DEBUG) cout << "R=" << r << ", Mat[" << aa << "][" << bb << "]=" << mat[aa][bb] << endl;
            if (mat[aa][bb] >= lim_val)
                {
                if (r > lb) lb=r;
                }
            else
                {
                skip=1;
                }
            }
        }

    if (verbose==true) cout << "--- bar length: " << (int) expf(lb) << " (" << lb << ")" << endl;
    return(lb);
    }


//
// MAIN() CODE
//

int main(int argc, char **argv)
    {
//
// Parse the command line options, if any, and set the flags associated
//   with the options
//

    static struct option long_options[] =
        {
        {"snr",      no_argument,    0, 's'},
        {"data",     no_argument,    0, 'd'},
        {"polar",    no_argument,    0, 'p'},
        {"quiet",    no_argument,    0, 'q'},
        {"warning",  no_argument,    0, 'w'},
        {"verbose",  no_argument,    0, 'v'},
        {"reverse",  no_argument,    0, 'r'},
        {"highpass", no_argument,    0, 'h'},
        /* These options require an argument. */
        {"mask",  optional_argument, 0, 'm'},
        {"fixed", optional_argument, 0, 'f'},
        {"input", optional_argument, 0, 'i'},
        {0, 0, 0, 0}
        };

    int option_index = 0;

    while ((c = getopt_long (argc, argv, "szdpqwvrhm:f:i:", long_options, &option_index)
) != -1)
        {
        switch (c)
            {
            case 's':
                {
                snr_fwhm = true;
                break;
                }
            case 'p':
                {
                polar = true;
                break;
                }
            case 'd':
                {
                raw = true;
                break;
                }
            case 'q':
                {
                quiet = true;
                break;
                }
            case 'v':
                {
                verbose = true;
                break;
                }
            case 'r':
                {
                rev = true;
                break;
                }
            case 'h':
                {
                high_pass = true;
                break;
                }
            case 'w':
                {
                warn = true;
                pit.set_warn(true);
                ast.set_warn(true);
                break;
                }
            case 'm':
                {
                if (strtol(optarg, nullptr, 10) != 0)
                    {
                    mask_line=1;
                    }
                else
                    {
                    mask=1;
                    }
                break;
                }
            case 'f':
                {
                fix_w=strtol(optarg, nullptr, 10);
                if ((fix_w > MAX_WINDOW) || (fix_w < MIN_WINDOW))
                    {
                    cerr << "ERROR: Window Size Must Be Between " << MIN_WINDOW << " and " << MAX_WINDOW << "...Exiting" << endl;
                    exit(EXIT_FAILURE);
                    }
                break;
                }
            case 'i':
                {
                input_file = 1;
                if (ast.file_exists(string(optarg))==false)
                    {
                    cerr << "ERROR: Parameter File " << optarg << " Not Found...Exiting" << endl;
                    exit(EXIT_FAILURE);
                    }
                if (ast.file_type(optarg) != ASTRO_TXT_FILE)
                    {
                    cerr << "ERROR: Parameter File " << optarg << " is Not a Text File...Exiting" << endl;
                    exit(EXIT_FAILURE);
                    }
                infile=string(optarg);
                break;
                }
            default:
                {
                cerr << "Usage: p2dfft [-i|--input <file>] [-v|--verbose] [-w|--warn]  [-r|--reverse] [-f|--fixed <size>] [-p|--polar] [-m|--mask 0|1] [-s|--snr] [-h|--highpass] [-q|--quiet] [<FITS files>]" << endl;
                exit(EXIT_FAILURE);
                break;
                }
            }
        }

//
// Output version numbers
//

    if (verbose==true)
        {
        cout << "p2dfft version: " << VERSION << endl;
        ast.version();
        pit.version();
        }

//
// Check for conflicting arguments
//

    if (fix_w && (rev==true))
        {
        cerr << "ERROR: Cannot specify -r|-reverse and -f|--fixed...Exiting" << endl;
        exit(EXIT_FAILURE);
        }

//
// Allocate the Cartesian data array.  Also, zero out the first cell of mat
//   because FITS image indices start at 1.  Please Note:  ArrayAlloc()
//   allocates a C-style array, not a FFTW3 style array.
//

    if (verbose==true) cout << "Allocating Cartesian mat[] Array..." << endl;

    if ((mat=ast.ArrayAlloc(MAX_DIM, MAX_DIM))==nullptr)
        {
        cerr << "ERROR: Memory allocation failed while allocating for mat[]" << endl;
        exit(EXIT_FAILURE);
        }

    mat[0][0]=0.1; //Used to be 0.0

//
// Get number of threads for this machine.  By default this should return
//   a value = #cores * threads per core. IMPORTANT: Due to the HDF5 libraries
//   not being fully thread safe, the multithreading code is disabled. The fix
//   will be to move the HDF5 code to the non-threaded code and using a shared
//   data structure to store the results from each thread. This is under
//   development -I
//

    num=1;
//    num=omp_get_max_threads();

    if (DEBUG_INDEX)
        {
        cout << "Thread Count (num)=" << num << endl;
        cout << "rawdim[0/1]=" << raw_dim[0] << endl;
        cout << "data_dim[0/2]=" << data_dim[0] << ", data_dim[1/2]=" << data_dim[1] << endl;
        cout << "FFT in/out array size=" << DIM_RAD*DIM_THT << endl;
        }

//
// Allocate the FFT arrays.  These need to be allocated with fftw_ functions
//   since they are not C-style 2D arrays and the fact they need to be aligned
//   on 16 byte boundaries if the target machine has SIMD support.
//
// Note we need to allocate one set per thread, since this program is managing
//   the threads and not the FFTW library.
// Addl Note: These are VLA's (variable-length arrays) which are deprecated in
//   some modern compilers. Work is underway to modernize this section.
// <TODO> 
//

    if (polar == true) proj = (float *) malloc((DIM_RAD*DIM_THT) * sizeof(float));

    struct  fft_out     fft_data[num][401];  /* FFT output data array */

    fftw_complex    *in_data[num];
    fftw_complex    *out_data[num];

    for ( i=0; i < num; i++ )
        {
        in_data[i] = (fftw_complex *) fftw_malloc((DIM_RAD*DIM_THT) * sizeof(fftw_complex));

    if(nullptr == in_data[i])
            {
            cerr << "ERROR: FFTW Memory allocation failed for in_data[" << i << "]" << endl;
            exit(EXIT_FAILURE);
            }

        out_data[i] = (fftw_complex *) fftw_malloc((DIM_RAD*DIM_THT) * sizeof(fftw_complex));
        if(nullptr == out_data[i])
            {
            cerr << "ERROR: FFTW Memory allocation failed for out_data[" << i << "]" << endl;
            exit(EXIT_FAILURE);
            }
        }

//
// Read the parameters for the analysis.  The parameters include:
//
//     * Filenames to be processed
//     * Keywords associated with those files (optional)
//     * Radius values for the files (optional)
//
// Parameters can come from one of the following sources (in
//  priority order):
//
//     * Parameter file specified with -i
//     * Command line arguments
//

    if (input_file)
        {
        if (ast.read_lines(infile, &items)==false)
            {
            cerr << "ERROR: Can't Read Parameter File: " << infile << endl;
            exit(EXIT_FAILURE);
            }
        if ((items.size()==0))
            {
            cerr << "ERROR: No Valid Filenames in Parameter File: " << infile << endl;
            exit(EXIT_FAILURE);
            }
        }
    else
        {
//
// Check if there are command line arguments
//

        if (DEBUG) cout << "optind=" << optind << ", argc=" << argc << endl;

        if (optind >= argc)
            {
//
// No command line arguments for files, so generate an error
//

            cerr << "ERROR: No Input File or File Argumements...Exiting" << endl;
            exit(EXIT_FAILURE);
            }
        else
            {

//
// Get the command line arguments and put them in vector of items
//

            for (i=optind; i < argc; i++)
                {
                if (DEBUG) cout << "argv[" << i << "]=" << argv[i] << endl;

                if (ast.file_exists(string(argv[i]))==true)
                    {
                    file_rec    f;

                    f.name=string(argv[i]);
                    f.result=ast.remove_path_extension(f.name, true, true);
                    f.radius=-1;
                    f.valid=0;

//
// Up to this point, don't assume it's a rational file, just populate the
//   defaults.  This next bit tests if it's a binary file and if that is
//   true, we can put it on the list.
//

                    if (ast.file_type(f.name)== ASTRO_BIN_FILE)
                        {
                        items.push_back(f);
                        }
                    else
                        {
                        if (quiet==false) cerr << "ERROR: Unkown file type for " << argv[i] << "...Skipping" << endl;
                        }
                    }
                }
            }
        }

//
// Final check to make sure we have items.   No reason to fail  here, but......
//

    if (items.size() == 0)
        {
        cerr << "ERROR: No Valid Files to Process (Empty work list)" << endl;
        exit(EXIT_FAILURE);
        }
    else
        {
        if (quiet==false) cout << "Total files to Process:    " << (unsigned int)items.size() << endl;
        }

    proc_error=0;

//
// Build the plan for the FFT transform
//

    if (verbose==true) cout << "Building plan for FFTW..." << endl;
    plan=fftw_plan_dft_2d( (int) DIM_THT, (int) DIM_RAD, in_data[0], out_data[0], FFTW_FORWARD, FFTW_MEASURE);
    if ( plan == nullptr )
        {
        cerr << "ERROR: FFTW Plan (" << i << ") Build Failed" << endl;
        exit(EXIT_FAILURE);
        }
    if (verbose==true) cout << "Done" << endl;

//
// Now we have the list of files.  Loop through all of them and process.
//

    for ( it = 0; it < items.size();  it++)
        {

//
// Zero out x_dim and y_dim.  This is important for the logic to
//   determine the radius
//

        x_dim=0;
        y_dim=0;

        if (quiet==false) cout << "Processing Entry - Name: " << items[it].name << endl;
        if (DEBUG) cout << " Result: " << items[it].result << " Radius: " << items[it].radius << " Valid: " << items[it].valid << endl;

//
// Read the data from the image anddetermine the radius, if needed.
//

        offset=-1;
        fname=(char *) items[it].name.c_str();
        if ((idata=ast.fits_read(fname, &msize))==nullptr)
            {

//
// Read Failure
//

            cerr << "WARNING: Can't Read Binary File: " << items[it].name << " Skipping..." << endl;
            proc_error++;
            delete[] idata;
            continue;
            }

//
// Get the radius
//

        if (ast.fits_dims(items[it].name.c_str(),&x_dim, &y_dim)==false)
            {

//
// Failure to get size from Header
//

            cerr << "ERROR: Can't Read Binary File Size: " << items[it].name << " Skipping..." << endl;
            proc_error++;
            delete[] idata;
            continue;
            }

        if (DEBUG_INDEX) cout << "x_dim=" << x_dim << ", y_dim=" << y_dim << endl;

//
// Find radius.  Images are no longer required to be square so find the
//   shortest dimension for the radius.
//

        if (!items[it].valid)
            {
            if ( x_dim < y_dim )
                {
                items[it].radius=(x_dim-1)/2;
                items[it].valid=1;
                }
            else
                {
                items[it].radius=(y_dim-1)/2;
                items[it].valid=1;
                }
            }

        if (DEBUG_INDEX) cout << "radius(items)=" << items[it].radius << endl;

//
// Copy the FITS data into the mat 2D Cartesian array
//

        if (DEBUG_INDEX) cout << "msize=" << msize << endl;

#ifdef DEBUG_DAT
        for(i=0;i<msize; i++)
            {
            if (idata[i] != 0.0) cout << "DEBUG: data[" << i << "]=" << idata[i] << endl;
            }
#endif

//
// The data linear array contains the FITS data.  Translate it into a 2D
//   matrix so it can be polar mapped from the center outward.  Note that
//   FITS arrays are column major order, not row major order, so a swap is
//   done.  The image could be processed without swapping, but to maintain
//   synergy with previous versions of 2DFFT (that performed the swap), it
//   is also done here.
// <TODO> Check this code for 2048 sized files
//

        for(i=1;i<=x_dim;i++)
            {
            for(j=1;j<=y_dim;j++)
                {
                mat[i][j]=idata[(i-1)*y_dim+j+offset];
                }
            }
    
        delete[] idata;

#ifdef DEBUG_MAT

        for(i=1;i<=x_dim;i++)
            {
            for(j=1;j<=y_dim;j++)
                {
                cout << "DEBUG: mat[" << i << "][" << j << "]=" << mat[i][j] << endl;
                }
            }
#endif

        if (verbose==true) cout << "Processing Entry - Name: " << items[it].name << " Result: " << items[it].result << " Radius: " << items[it].radius << " Valid: " << items[it].valid << endl;

        if (verbose==true) cout << "--- transforming X x Y -> Theta x ln r" << endl;

//
// Use (dim-1)/2 for each dimension.  This makes it work for both odd and even
//   sized images.
//

        x_0=((x_dim-1)/2)+1;
        y_0=((y_dim-1)/2)+1;

//
// Determine the masking value by determining the core brightness
//

        ctr_val=mat[x_0][y_0];
        if (mask_line)
            {
            if (verbose==true) cout << "Center Value " << ctr_val << endl;
            log_bar=find_bar(items[it].radius,x_0,y_0,ctr_val);
            if (DEBUG) cout << "Bar is " << expf(log_bar) << endl;
            }
        else
            {
            log_bar=0.1;  //Used to be 0.0
            }

//
// log() functions are computationally expensive, so calculate the log
//   outside of the loop.
//

        log_itrad=log((double)items[it].radius);

//
// Create the output data file (what used to be the .rip and .dat files) along
//   with initializing the data property list structure
//

        try
            {
            H5std_string filename(string(items[it].result.c_str())+".h5");
            out_file = H5File(filename, H5F_ACC_TRUNC);
            DataSpace rad_space(H5S_SCALAR);
            Attribute attr_rad = out_file.createAttribute("radius", PredType::NATIVE_INT, rad_space);
            attr_rad.write(PredType::NATIVE_INT, &items[it].radius);
            prop_list.setFillValue(PredType::NATIVE_DOUBLE, &fp_fill);
            }
        catch (...)
            {
            cerr << "WARNING: Cannot Create Output File: " << items[it].result << ".h5 Skipping..." << endl;
            proc_error++;
            continue;
            }

//
// Initialize the normalization array
//

        for (i=0; i <= MAX_DIM; i++) norma[i]=0.0;

//
// Determine the starting radius.  For most cases, this will be 1, but if
//   using a fixed window, it has to move out to half the window size.
//

        if (fix_w)
            {
            rstart = (fix_w/2)+1;
            if (rstart > fix_w + items[it].radius)
                {
                cout << "Error processing " << items[it].name << " Annulus Size" << fix_w << " End " << items[it].radius << " Skipping..." << endl;
                continue;
                }
            }
        else
            {
            rstart = 1;
            if (rstart >= items[it].radius)
                {
                cout << "Error processing " << items[it].name << " End " << items[it].radius << " Skipping..." << endl;
                continue;
                }
            }

//
//  This is the parallel portion of the code.  All the inner radius values for
//    each annuli will be calculated in groups of parallel threads starting here.
//    Even if there is is only one thread, this code will still work.
//

//#pragma omp parallel for

        for (int radius = rstart; radius < items[it].radius; radius++)
            {

//
// VERY IMPORTANT - current is unique to each thread, so it must be defined
//   inside this block of code.  Since these threads run in parallel, any
//   variable must be unique per thread.  We do this by making them arrays
//   and using the thread number as the index.  This is current and it will
//   appear often below, except for any variable defined here (which by virtue
//   of it's location will be unique per thread.
//

//int     current=omp_get_thread_num(); /* Current index for arrays for thread */
int current = 0;

//
// Other definitions that are unique instances per thread.
//

int     a, b;              /* Cartesian coordinates of ln(r)/theta in image  */
int    	mode;              /* Mode index value                               */
int     jm, im;            /* Local index variables                          */
int     cont_p;            /* Index for remapping output data in fft_data    */
int     counter=0;         /* FFT array index value                          */
int     count_theta=1;     /* Counter for theta steps in degrees             */
int     count_radians;     /* Counter for theta steps in radians             */

char    outfile1[80];      /* Intermediate .rip file name string             */
char    outfile2[80];      /* Intermediate .dat file name string             */

float   lnr;               /* Natural log of radius for a certain point      */
float   x, y;              /* Relative cartesian coordinates of ln(r)/theta  */
float   log_lo;            /* Natural log of the inside of the fixed annuli  */
float   log_hi;            /* Natural log of the outside of the fixed annuli */
float   log_rad;           /* Natural log of current value of radius         */
float   freq_save;         /* Current frequency calculation value            */
float   theta_degrees;     /* Current theta (polar angle) in degrees         */
float   theta_radians;     /* Current theta (polar angle) in radians         */

//
// Calculate the end value for ln(radius)
//

            if (rev==true)
                {
                log_rad=log((double)(items[it].radius-radius+1));
                }
            else
                {
                log_rad=log((double)radius);
                }

//
// If using a fixed annulus, need to drop before getting to the last radius
//

            if (fix_w && (radius >= items[it].radius-(fix_w/2))) continue;

//
// Calculate the values used for fixed width annuli, if needed
//

            if (fix_w)
                {
                log_lo=log((double)(radius-(fix_w/2)+1));
                log_hi=log((double)(radius+(fix_w/2)));
                }

//
// Zero out the arrays.  This is REALLY important to getting the correct
//   results.
//

            for (im=0; im < DIM_RAD*DIM_THT; im++)
                {
                in_data[current][im][0]=0.1; // Used to be 0.0
                in_data[current][im][1]=0.0;
                out_data[current][im][0]=0.0;
                out_data[current][im][1]=0.0;
                }

            if (DEBUG_INDEX) cout << "Clearing " << DIM_RAD*DIM_THT << " entries is in/out data" << endl;

//
// Step around theta angles (360 degrees in 0.35 degree steps)
//

            if (DEBUG_INDEX) cout << "Start counter at " << counter << endl;

            for(theta_degrees=0.0;count_theta<=DIM_THT;theta_degrees+=theta_step)
                {
                count_theta++;

//
// Convert the degrees to radians
//

                theta_radians=theta_degrees*GR_RAD;
                count_radians=1;

                for(lnr=0.0;count_radians<=DIM_RAD;lnr+=radstep)
                    {
                    count_radians++;

                    if ((mask_line) && (lnr <= log_bar))
                        {
                        in_data[current][counter][0]=0.1; // Used to be 0.0
                        in_data[current][counter++][1]=0.0;
                        continue;
                        }

//
// Here's the bit that controls what get mapped and what is set to zero.
//   These tests depend on the value of reverse and fixed.
//

                    if ((rev==true) && (lnr>log_rad || lnr>log_itrad))
                        {
                        in_data[current][counter][0]=0.1; //Used to be 0.0
                        in_data[current][counter++][1]=0.0;
                        continue;
                        }

                    if (fix_w && (lnr>log_hi || lnr<log_lo))
                        {
                        in_data[current][counter][0]=0.1; //Used to be 0.0
                        in_data[current][counter++][1]=0.0;
                        continue;
                        }

                    if ((rev==false) && !fix_w && (lnr>log_itrad || lnr<log_rad))
                        {
                        in_data[current][counter][0]=0.1; //Used to be 0.1
                        in_data[current][counter++][1]=0.0;
                        continue;
                        }

                    x=expf(lnr)*cosf(theta_radians);
                    y=expf(lnr)*sinf(theta_radians);

                    a=(int)x+x_0;
                    b=(int)y+y_0;

                    if ((mask) && (mat[a][b] >= ctr_val))
                        {
                        in_data[current][counter][0]=0.1; // Used to be 0.0
                        }
                    else
                        {
#ifdef DEBUG_MAP
                        if (radius==1) cout << "Map " << a << ", " << b << ", to " << counter << endl;
#endif
                        in_data[current][counter][0]=(double) mat[a][b];
                        norma[radius]+=in_data[current][counter][0];
                        }
                    in_data[current][counter++][1]=0.0;
                    }
                }

            if (DEBUG_INDEX) cout << "Out with counter=" << counter << endl;

            if (verbose==true) cout << "--- calculating 2DFFT: " << radius << "/" <<  items[it].radius << endl;

#ifdef DEBUG_DAT
            if (radius<2)
                {
                cout << "RADIUS: " << radius << endl;
                for(im=0;im<=counter;im++)
                    {
                    if (in_data[current][im][0] != 0.0) cout << "In[" << im << "][0]" << in_data[current][im][0] << endl;
                    }
                }
#endif

//
// Save the polar mapped image if the -p option was specified
//

            if ((polar == true) && (radius==1))
                {
                counter=0;
                for (jm=0; jm < DIM_RAD; jm++)
                    {
                    for (im=0; im < DIM_THT; im++)
                        {
                        proj[counter++]=(float) in_data[current][(im*2048)+jm+1][0];
                        }
                    }
                fname=(char *) items[it].name.c_str();
                if (verbose==true) cout << "  --- Write P_" << fname << " File" << fname << endl;

using namespace H5;
                const string pfile = "!P_" + items[it].name;
                fname=(char *) pfile.c_str();
                if (ast.fits_write(fname, proj, DIM_THT, DIM_RAD, 1, "p2dfft/",VERSION)==false)
                    {
                    cerr << "WARNING: fits_write(" << fname << ") Failed (" << ast.get_err() << ")" << endl;
                    }
                }

//
// Perform the FFT using the plan
//

            fftw_execute_dft(plan,in_data[current],out_data[current]);

//
// Normalize the output data
//

            if (DEBUG_INDEX) cout << "Normalize with counter=" << counter << endl;

            for(im=0;im<counter;im++)
                {
#ifdef DEBUG_DAT
                if (out_data[current][im][0] != 0.0) cout << "DEBUG: Out Data[" << im << "][0]=" << out_data[current][im][0] << endl;
                if (out_data[current][im][1] != 0.0) cout << "DEBUG: Out Data[" << im << "][1]=" << out_data[current][im][1] << endl;
#endif
                out_data[current][im][0]=out_data[current][im][0]/(double)norma[radius];
                out_data[current][im][1]=out_data[current][im][1]/(double)norma[radius];
                }

//
// Write the raw FFT output data
//

            if ((raw==true)&&(radius==1))
                {
                try
                    {
                    if (quiet==false) cout << "Write Raw FFT Data File" << endl;
//                    #pragma omp critical
//                        {
                        DataSpace raw_space(1,raw_dim);
                        string raw_set = "/raw";
                        raw_set= raw_set + to_string(radius);
                        DataSet raw_block = out_file.createDataSet(raw_set,PredType::NATIVE_DOUBLE, raw_space,prop_list); 
                        raw_block.write(out_data[current], PredType::NATIVE_DOUBLE);
//                        }
                    }
                catch (...)
                    {
                    cerr << "WARNING: Could Not Write To:" << items[it].result << ".h5" << endl;
                    }
                }

//
// Loop to get the data for each mode
//

            for(mode=M_INI;mode<=M_FIN;mode++)
                {
                counter=mode*DIM_RAD;

                if (DEBUG_INDEX) cout << "Counter for Mode=" << mode << " is " << counter << endl;

//
// Open data files and write the initial data
//

//                #pragma omp critical
//                    {
                    DataSpace rip_space(2,data_dim);
                    if (DEBUG_INDEX) cout << "Mode " << mode << ", data_dim=" << data_dim[0] << ", " << data_dim[1] << endl;
                    string rip_set = "/rip_r";
                    rip_set= rip_set + to_string(radius) + "_m" + to_string(mode);
                    DataSet rip_block = out_file.createDataSet(rip_set,PredType::NATIVE_DOUBLE, rip_space,prop_list);
//                    }
                if (DEBUG_INDEX) cout << "Complete rip write for Mode " << mode << endl;

//
// Extract the FFT output components for -50 to +50 Hz and populate them in
//   the fft_data structure.  P2DFFT uses a different order than FFTW uses
//   for it's output.   The mapping is:
//
//      out_data    Description                      fft_data Index  HDF5 Index
//      --------    ---------------------            --------------  ----------
//        0,0       Real DC/0 Hz Component                200           400
//        0,1       Imaginary DC/0 Hz Component           200           401
//        1,0       Real 0.25 Hz (Min) Component          201           402
//        1,1       Imaginary 0.25 Hz (Min) Component     201           403
//       200,0      Real 50 Hz Component                  400           800
//       200,1      Imaginary 50 Hz Component             400           801
//       201,0      Real 50.25 Hz Component               N/S           N/S
//       201,1      Imaginary 50.25 Hz Component          N/S           N/S
//      1024,0      Real 256 Hz Component (Max)           N/S           N/S
//      1024,1      Imaginary 256 Hz Component (Max)      N/S           N/S
//      1025,0      Real -256 Hz Component (Max)          N/S           N/S
//      1025,1      Imaginary -256 Hz Component (Max)     N/S           N/S
//      1847,0      Real -50.25 Hz Component              N/S           N/S
//      1847,1      Imaginary -50.25 Hz Component         N/S           N/S
//      1848,0      Real -50 Hz Component                   0             0
//      1848,1      Imaginary -50 Hz Component              0             1
//      2047,0      Real -0.25 Hz Component (Min)         199           398
//      2047,1      Imaginary -0.25 Hz Component (Min)    199           399
//
//   This mapping is also for m0 only, other modes would have the same fft_data
//   and rip values, but the data indices would have mode*2048 added to them.
//
//   Finally, this table also assumes a frequency mapping of -50 to +50, if
//   thats different, then the start and end will be different.
//
//   Also note that we multiply the imaginary component by -1.0 because FFTW3
//   returns a sign reversed value compared to the previous algorithm.
//

                for(cont_p= 0 ;cont_p < 200; cont_p++)
                    {
                    fft_data[current][cont_p+201].real=
                        out_data[current][counter+cont_p+1][0];
                    if (out_data[current][counter+cont_p+1][1] != 0.0)
                        {
                        fft_data[current][cont_p+201].imag=
                        -1.0*out_data[current][counter+cont_p+1][1];
                        }
                    else
                        {
                        fft_data[current][cont_p+201].imag= out_data[current][counter+cont_p+1][1];
                        }

                    fft_data[current][cont_p].real=
                        out_data[current][counter+cont_p+1848][0];
                    if (out_data[current][counter+cont_p+1848][1] != 0.0)
                        {
                        fft_data[current][cont_p].imag=
                        -1.0*out_data[current][counter+cont_p+1848][1];
                        }
                    else
                        {
                        fft_data[current][cont_p].imag=
                        out_data[current][counter+cont_p+1848][1];
                        }
                    }

//
//
// Since there are 401 entries, add the zero frequency data here
//

                fft_data[current][200].real=
                    out_data[current][counter][0];
                fft_data[current][200].imag=
                    -1.0*out_data[current][counter][1];

//                #pragma omp critical
                    rip_block.write(fft_data[current], PredType::NATIVE_DOUBLE);

//
// The pitch_phase routine should have populated the mode_data structure with
//   all the data for this radius.  However, if the FFT returned NaN's, this
//   must be handled before calling additional analysis functions.   NOTE:
//   NaN's do not necessarily represent an error (can happen if the image is
//   small in the frame or signal is low), but it does prevent any further
//   meaningful analysis.
//

                if (!(pit.pitch_phase(fft_data[current], mode, &mode_data[mode][radius])))
                    {
                    if (warn==true) cerr << "WARNING: pitch_phase() failed (" << pit.get_err() << ") for radius " << radius << " and mode " << cont_p << endl;
                    mode_data[mode][radius].index=0;
                    mode_data[mode][radius].freq=NAN;
                    mode_data[mode][radius].amp=NAN;
                    mode_data[mode][radius].avg_amp=NAN;
                    mode_data[mode][radius].pa=NAN;
                    mode_data[mode][radius].phase=NAN;
                    mode_data[mode][radius].snr=NAN;
                    mode_data[mode][radius].fwhm=NAN;
                    }
                else
                    {
                    if (snr_fwhm)
                        {
                        if (!(pit.snr(fft_data[current], &mode_data[mode][radius])))
                            {
                            if (warn==true) cerr << "WARNING: snr() failed (" << pit.get_err() << ") for radius " << radius << " and mode " << cont_p << endl;
                            mode_data[mode][radius].avg_amp=NAN;
                            mode_data[mode][radius].snr=NAN;
                            mode_data[mode][radius].fwhm=NAN;
                            }
                        else
                            {
                            if (!(pit.fwhm(fft_data[current], &mode_data[mode][radius])))
                                {
                                if (warn==true) cerr << "WARNING: fwhm() failed (" << pit.get_err() << ") for radius " << radius << " and mode " << cont_p << endl;
                                mode_data[mode][radius].fwhm=NAN;
                                }
                            }
                        }
                    }
                if (DEBUG) cout << "DEBUG: Pitch Phase Angle=" << mode_data[mode][radius].pa << ", SNR=" << mode_data[mode][radius].snr << ", FWHM=" << mode_data[mode][radius].fwhm << endl;
                }
            }

//
// **** END OF PARALLEL THREAD LOOP
//

//
// Write the normalization data set
//

        hsize_t sdim[1];
        sdim[0]=items[it].radius;
        DataSpace norm_space(1,sdim);
        H5std_string norm_set = "/normalization";
        DataSet norm_block = out_file.createDataSet(norm_set,PredType::NATIVE_DOUBLE, norm_space,prop_list);
        norm_block.write(&norma[1], PredType::NATIVE_DOUBLE);

//
// Now that all radii are complete, write the per mode and summed output files
//

        for (i = M_INI; i <= M_FIN; i++)
            {
            ostringstream outfile;
            outfile << items[it].result << "_m" << i;
            ofstream mode_out (outfile.str(), ios::out | ios::trunc);

            if (!mode_out)
                {
                cerr << "ERROR: Could Not Write " << outfile.str() << " Skipping..." << endl;
                continue;
                }

            for (j = 1; j <= items[it].radius; j++)
                {
                if (snr_fwhm)
                    {
                    mode_out << setw(6) << i << setw(11) << j << setw(8) << setprecision(2) << fixed << mode_data[i][j].freq << setw(12) << setprecision(3) << mode_data[i][j].amp << setw(9) << setprecision(2) << fixed << mode_data[i][j].pa << setw(11) << setprecision(3) << mode_data[i][j].phase << setw(11) << setprecision(3) << mode_data[i][j].snr << setw(11) << setprecision(3) << mode_data[i][j].fwhm << "\n";
                    }
                else
                    {
                    mode_out << setw(6) << i << setw(11) << j << setw(8) << setprecision(2) << fixed << mode_data[i][j].freq << setw(12) << setprecision(3) << mode_data[i][j].amp << setw(9) << setprecision(2) << fixed << mode_data[i][j].pa << setw(11) << setprecision(3) << mode_data[i][j].phase << "\n";
                    }
                }
            mode_out.close();
            }
        }
    if (quiet==false)
        {
        cout << "-------------------------------" << endl;
        it=(unsigned int)items.size()-(unsigned int)proc_error;
        cout << "Successfuly Processed        " << it << endl;
        cout << "Errors                       " << proc_error << endl;
        cout << "-------------------------------" << endl;
        }
    }
