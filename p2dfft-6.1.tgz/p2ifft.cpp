//
// P2IFFT.CPP - This program will take the FFT output data from P2DFFT and
//              generate a FITS image based on that data.  By default, the
//              sum of all data is used, but there are options to use only
//              some .rip files for a subset of the data.
//
//
// Version 4.0: 18-Oct-2021
//
//
// 2DFFT (original) Author: Dr. Ivanio Puerari
//                          Instituto Nacional de Astrofisica,
//                          Optica y Electronica,
//                          Santa Maria Tonantzintla,
//                          Puebla, Mexico
//
// 2DFFT (revised) Lead Author: Dr. Marc Seigar
//                              University of Minnesota Duluth,
//                              Duluth, MN USA
//
// 2DFFT (progenitor of P2DFFT) Lead Author: Dr. Benjamin Davis
//                                           Swinburne University of Technology.
//                                           Centre for Astrophysics and
//                                           Supercomputing
//                                           Melbourne, Victoria, Australia
//                                       http://d.umn.edu/~msseigar/2DFFT.html
//
// P2DFFT By: Ian Hewitt & Dr. Patrick Treuthardt,
//            NC Museum of Natural Sciences,
//            Astronomy & Astrophysics Lab,
//            Raleigh, NC USA.
//            http://github.com/treuthardt/P2DFFT
//
//
// LICENSE
//
// P2DFFT Spiral Galaxy Arm Pitch Angle Analysis Suite
// Copyright (c) 2016-2024  Ian B. Hewitt & Dr. Patrick Treuthardt
//
// The program is free software:  you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation, version 3.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
// details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see < https://www.gnu.org/licenses >.
//
// The authors can be contacted at:
//
//     North Carolina Museum of Natural Sciences
//     Astronomy & Astrophysics Laboratory
//     11 West Jones Street
//     Raleigh, NC, 27601  USA
//     +1.919.707.9800
//
//     -- or --
//
//     patrick.treuthardt@naturalsciences.org
//
//
// Usage: p2ifft [-i|--input <file>] [-v|--verbose] [-m|--mode <n>[<n>...]]
//               [-s|--start <arg>] [-e|--end <arg>] [<file>[ <file>...]]
//
//        If there is an input file specified with -i, that will be used for
//            the list of file names to be processed (one per line).  If no
//            -i option is specified and the command line arguements will
//            be used.
//
//        The file names can be the prefix of the files or can have the .fits
//        extension.  Either will work (e.g. <galaxy> and <galaxy>.fits
//        will both work.  The output files will have the form of
//        I_<keyword>.fits or I<mode>_<keyword>.fits (if the -m option is used)
//
//        There are several command line options:
//
//              -i|--input : Will read file names and keywords from the file
//                           specified instead of the command line
//              -v|--verbose: Prints status messages during the processing.
//              -m|--mode  : Specifies the modes to be used in the output IFFT.
//                           By default, all modes (0-6) are used.  The -m
//                           option specifies comma separated list of modes
//                           to be used in the plot, e.g. -m 1,3,5,6
//              -s|--start : Specify a starting inner radius (default is 1)
//              -e|--end   : Specify an ending inner radius (default is file
//                           size - 10%)
//
// Algorithm Notes:
//
//      The inverse image is created by reading the complex FFT frequency space
//      data for each annuli starting with an inner radius of 1 (or the start
//      value) to the ending inner radius annuli specified by end (or 10% less
//      than the maximum radius, per Davis et. al. 2012).  The FFT data is then
//      summed and a reverse two dimensional transform is done.   The resultant
//      data is then mapped from polar to cartesian space and a FITS image is
//      created.
//
// Revision History:
//      4.0  18-Oct-2021: - Fix DEBUG message printing
//                        - Fix bug in the way the normalization from p2ddft
//                          was done to generate clearer images
//                        - Changes to support HDF5 data files
//                        - Fix cases where values could be set to -0.0
//                        - Fix bug in the way the FFT was called which could
//                          cause empty output
//                        - Fix bug in normalizing transformation output for a
//                          more accurate image
//                        - Remove dependency on experimental filesystem code
//      3.9  21-Dec-2020: - Correct compile error caused by deprecated code
//      3.8  17-Dec-2020: - Update header comments
//                        - Change format of -m arguments
//                        - Change input and output to use streams
//                        - Change file I/O to use streams
//                        - Change string parsing to use specific ranges
//                        - Change to C++ include style
//                        - Change flags from integer to boolean
//                        - Remove macros
//                        - Use explicit null pointer values
//      3.7  25-Jun-2020: - Update header comments and remove arcane/technically
//                          inaccurate terminology
//                        - Fix bug in version string
//                        - Replace deprecated functions with more modern
//                          typ-safe ones
//                        - Fix bug where builds on the latest Mac software
//                          would fail by including libgen.h
//                        - Add error check for opening file to determine the
//                          radius value
//                        - Remove debug print statement
//                        - Remove unused variables
//                        - Remove code for command line option processing that
//                          was no longer used
//      3.6  20-May-2020: - Fix bug where FIT's file arguments that were not
//                          in the current directory caused output not be
//                          written to the current working directory
//                        - Added error check for opening file for determining
//                          the radius
//                        - Removed some debugging print statements that were
//                          accidentally left in the release code
//                        - Completely replaced (again) the code for finding
//                          the max radius from the summary file.  This code is
//                          simpler and more robust and should work better
//                          across different platforms.
//                        - Remove unused variables
//                        - Remove unnecessary code used in processing command
//                          line arguments.  Was not needed, but did not cause
//                          errors.
//      3.5  04-May-2020: - The code for finding the max radius from the data
//                          files relied on a specific number of bytes in the
//                          last line.  Rewrote the code to be more robust.
//      3.4  20-Jun-2019: - Fix small bug in ifft image generation
//                        - Correct/rework some DEBUG information printing
//                        - Fix bounds checking as isnan() did not detect -nan
//                        - Fix error in usage information
//                        - Clarify author/licensing information
//      3.3  03-Jun-2019: - Remove debug information printing
//                        - Change row/column sense for inverse FFT to match
//                          change in p2dfft.cpp
//                        - Fix bug in centering alogrithm for output image
//                        - Remove leftover -a option code
//      3.2  31-Jan-2019: - Fix bug introduced by compiler change in 18.04
//      3.1  18-Dec-2018: - Update comments and formatting
//                        - Fix version display bug
//                        - Update FITS mapping code to account for different
//                          ordering of CFITSIO vs C/C++
//                        - Remove ASCII FITS file output option
//                        - Fix one instance where error counter was not updated
//                        - Remove averaging for summed data
//                        - Exclude mode 0 data by default
//                        - Add checks for nan in FFT data and exclude them
//                        - Fix bug where default mode values not correct
//                        - Remove normalization as not needed because FFTW3
//                          scales the array which is fine for IFFT
//                        - Fix bug in input file handling that could cause
//                          a infinite loop
//                        - Fix small bug in verbose print statements
//                        - Fix bug in file naming for specfied modes
//                        - Fix bug where using an input file could result in
//                          no modes being selected
//      3.0  15-Sep-2018: - Remove multi-threaded code
//                        - Move directory check earlier to avoid potential
//                          crash
//                        - Standardize output message format
//                        - Move file processing message to require verbose
//                        - Add -s and -e options and update input file to
//                          support starting and ending radii for each file
//                        - Change algorithm to use sum file or create sum
//                          of FFT data to create the inverse image
//                        - Remove entering files from stdin
//      2.1  05-Feb-2018: - Remove unused variables and add global constants
//                        - Update comments/data table and check spelling
//                        - Remove unused variables
//      2.0  28-Aug-2017: - Update header comments/usage information
//                        - Change from C to C++
//                        - Major rewrite to switch from numerical recipes FFT
//                          algorithm to the libfftw3 routines.  This required
//                          major program flow changes around how parallelism
//                          was implemented as well as changing the input/output
//                          data type to be complex.
//                        - Made text file creation optional vi the -t option
//                        - Removed some old/deprecated/unused variables
//                        - Removed the -f (frequency) and (-p) phase mappings,
//                          as they were not really useful the way they were
//                          implemented and avg.py produces a more useful
//                          mapping.
//                        - Minor changes to eliminate compiler warnings on
//                          some distributions
//      1.6  29-Jul-2017: - Fix bug where mode 1 was not set as a default
//                        - Correct bug where results matrix not initialized
//                        - Add filter to prevent NAN values from IFFT from
//                          being mapped as they display improperly
//                        - Add some status messages to non-verbose mode
//                        - Add feature where -m creates mode specific filenames
//                        - Add feature to allow user to specify .fits
//                          filenames, instead of directories for ease of use.
//      1.5  23-Jan-2017: - Fix default mode to not include mode 0
//      1.4  17-Jan-2017: - Fix bug in mode selection option and made the mode
//                          bounds checking reference a constant.
//      1.3  05-Jan-2017: - Complete frequency mapping file output
//                        - Add phase angle mapping file output (-p)
//      1.2  03-Jan-2017: - Add capability to make  data file for frequency
//                          mapping (-f) -- PARTIAL
//                        - Update help message to include -v|--verbose
//                        - Add I_ prefix to output file to avoid collisions
//      1.1  06-Dec-2016: - Add averaging for data from all radii
//      1.0  29-Nov-2016: - Initial version from 2DFFT code for the first radius
//                          data.
//

//
// INCLUDE FILES
//

#include    <cmath>
#include    <cstdio>
#include    <cstdlib>
#include    <cstring>
#include    <getopt.h>
#include    <sys/stat.h>
#include    <sys/types.h>
#include    <omp.h>
#include    <fftw3.h>
#include    "fitsio.h"
#include    <fstream>
#include    <sstream>
#include    <iostream>

//
// Include the Astro Functions Class from the NCNMS/NRC
//

#include    "astro_class.h"

#include    "globals.h"

#ifdef OSX
#include    <libgen.h>
#endif

using namespace std;

//
// Include HDF5 Libraries
//

#include    "H5Cpp.h"

using namespace H5;

//
// CONSTANTS
//

const string VERSION="4.0/20211018";

//
// Number of total frequency steps
//

const int FREQ_STEPS=200;


//
// GLOBAL VARIABLES
//

bool    verbose=false;  /* Flag to for whether status messages are output  */
bool    mode_opt=false; /* Flag to indicate if mode option was specified   */
bool    inp_mode=false; /* Flag to indicate if an input file was used      */

int     m;              /* Mode data being processed                       */
int     t;              /* Calculated index value                          */
int     st;             /* User argument for starting radius               */
int     en;             /* User argument for ending radius                 */
int     i,j;            /* Index variables for loops                       */
int     x,y;            /* Index variables for loops and matrices          */
int     ctr;            /* Counter for entries/line in .txt file out.      */
int     val;            /* Mode value                                      */
int     dim;            /* Size of FITS data matrix for the current file   */
int     rmap;           /* Index used in mapping rip[] to out_data[][]     */
int     beg_rad;        /* Beginning inner annuli value                    */
int     dummy;          /* Place holder used in reading rip files          */
int     finish;         /* Ending inner radius vlue                        */
int     status;         /* CFITSIO return status                           */
int     maxrad;         /* Value of outer radius from the data files       */
int     radius;         /* Loop variable for the inner radius              */
int     looper;         /* Loop variable for the processing loop           */
int     sindex;         /* Index for parsing mode string from input file   */
int     err_cnt;        /* Count of number of files where processing fails */
int     counter;        /* Index value for mapping data_out[][] to mat[][] */
int     arg_ptr;        /* Index for command line arguments                */
int     cmd_line;       /* Flag to indicate if cmd line args are used      */
int     maxrad90;       /* Outer radius value - 10%                        */
int     num_files;      /* Number of file to eb processed                  */
int     count_theta;    /* Step counter for radial degrees                 */
int     count_radians;  /* Step counter for radial radians                 */
int     option_index=0; /* Used for argument processing                    */

long    naxis=2;        /* CFITSIO number of axes                          */
long    naxes[2];       /* CFITSIO axes size                               */

char    c;              /* Value from getopt_long(3)                       */
char    cval;           /* Character holder for mode                       */
char    *item;          /* Pointer to string for input file parsing        */
char    str[2];         /* String for stripping extension from input file  */
char    tmp[64];        /* Temporary string for mode specific outfile      */
char    cstr[2];        /* Character string holder for mode                */
char    cmd[128];       /* String for command line to rm file              */
char    outfile[64];    /* Base name for output files (.txt and .fits)     */
char    files[MAX_ARGS]; /* Input file name from command line              */

float   lnr;            /* LN(R) value for polar-->Cartesian mapping       */
float   fx, fy;         /* Floating point x,y Cartesian values             */
float   radstep;        /* Radian step increment                           */
float   **result;       /* Pointer for matrix which has final result       */
float   rip[805];       /* Array holding rip file contents                 */
float   theta_step;     /* Theta angle increment                           */
float   theta_degrees;  /* Value of polar mapping theta angle in degrees   */
float   theta_radians;  /* Value of polar mapping theta angle in radians   */
float   mat[MAX_DIM][MAX_DIM]; /* Individual radius loop result matrix     */
float   vals[MAX_DIM][MAX_DIM]; /* Number of entries in a given x,y        */

string  ret;            /* Return value from get_last_line()               */
string  buff;           /* Line read from input file                       */
string  fname;          /* Input file name argument value                  */
string  modeinp;        /* Mode input from command line                    */
string  mode_str[MAX_FILES]; /* Input mode value strings                   */

double  log_rad;        /* Log(2) of current radius                        */
double  log_maxrad;     /* Log(2) of maximum radius                        */
double  norma[MAX_DIM+1]; /* Normalization value from p2dfft               */

H5File  data_file;      /* File descriptor for HDF5 data file              */

astro   ast;            /* Class object for NCNMS astro_class library      */

struct  stat    sb;     /* Structure for stat command to check files/dir   */

fitsfile *fptr;         /* CFITSIO file pointer                            */

ifstream fs;            /* File stream pointer for reading radius          */

struct
    {
    string  base;       /* Input file name prefixes                        */
    bool    mode[7];    /* Flags for modes to use                          */
    int     end;        /* Array for user specified starting radii         */
    int     start;      /* Array for user specified ending radii           */
  } target[MAX_FILES];

//
// MAIN ROUTINE
//

int main(int argc, char **argv)
    {
//
// Get and process the command line arguments
//

    static struct option long_options[] =
        {
        {"verbose", no_argument,     0, 'v'},
        /* These options require an argument. */
        {"start",  optional_argument, 0, 's'},
        {"end",  optional_argument, 0, 'e'},
        {"mode",  optional_argument, 0, 'm'},
        {"input", optional_argument, 0, 'i'},
        {0, 0, 0, 0}
        };

    while ((c = getopt_long (argc, argv, "vs:e:i:m:", long_options, &option_index)) != -1)
        {
        switch (c)
            {
            case 'v':
                {
                verbose = true;
                break;
                }
            case 's':
                {
                st=strtol(optarg, nullptr, 10);
                break;
                }
            case 'e':
                {
                en=strtol(optarg, nullptr, 10);
                break;
                }
            case 'm':
                {
                mode_opt=true;
                modeinp=optarg;
                break;
                }
            case 'i':
                {
                fname=optarg;
                break;
                }
            default:
                {
                cerr << "Usage: p2ifft [-i|--input <file>] [-v|--verbose] [-s|--start <arg>] [-e|--end <arg>] [-m|--mode <n>[<n>...]]" << endl;
                exit(1);
                break;
                }
            }
        }

    if (verbose) cout << "p2ifft - Version: " << VERSION << endl;

//
// Check the start and end values, if given.  Will adjust the default endpoint
//   later if it is too high.
//

    if ((st != 0) || (en != 0))
        {
        if (en < st)
            {
            cerr << "ERROR: Radius range " << st << " to " << en << " is invalid...Exiting" << endl;
            exit(1);
            }
        if ((st < 1) || (st > MAX_DIM))
            {
            cerr << "ERROR: Start value " << st << " is invalid...Exiting" << endl;
            exit(1);
            }
        if ((en < 1) || (en > MAX_DIM))
            {
            cerr << "ERROR: End value " << en << " is invalid...Exiting" << endl;
            exit(1);
            }
        }

//
// Check the input file name, if given, and read the parameters.  If no input
//   file, check command line arguments.  Either way, get number of files to
//   process fill arrrays with file information/parameters
//

    num_files=0;
    err_cnt=0;

    if (!fname.empty())
        {
        ifstream file_list (fname, ios::in);
        if (!file_list)
            {
            cerr << "ERROR: Cannot open input file - " << fname << endl;
            exit(1);
            }
        while (getline(file_list, buff))
            {
//
// Check for comment or blank line
//

            if ((buff.at(0)=='#') || (buff.size() < 2)) continue;

//
// If we have reached the maximum file number, we need to flag an error.
//

            if (num_files == MAX_FILES)
                {
                cerr << "ERROR: Too many input lines!" << endl;
                exit(1);
                }
//
// Break the line into individual fields.
//

            if ((item=strtok((char *)buff.c_str(),",\t\n "))!=nullptr)
                {
                target[num_files].base=ast.remove_path_extension(item, true, false);
                if ((item=strtok(nullptr,",\t\n "))!=nullptr)
                    {
                    mode_str[num_files]=item;
                    inp_mode=true;
                    if ((item=strtok(nullptr,",\t\n "))!=nullptr)
                        {
                        target[num_files].start=strtol(item, nullptr, 10);
                        if (target[num_files].start < 1)
                            {
                            cerr << "WARNING: Invalid Start on Line " << num_files+1 << endl;
                            err_cnt++;
                            continue;
                            }
                        if ((item=strtok(nullptr,",\t\n "))!=nullptr)
                            {
                            target[num_files].end=strtol(item, nullptr, 10);
                            if (target[num_files].end < 1)
                                {
                                cerr << "WARNING: Invalid End on Line " << num_files+1 << endl;
                                err_cnt++;
                                continue;
                                }
                            }
                        }
                    }
                else
                    {
                    mode_str[num_files]="123456";
                    }
                }
            else
                {
                cerr << "WARNING: Invalid Filename on Line " << num_files+1 << endl;
                err_cnt++;
                continue;
                }
            num_files++;
            }
        }
    else
        {

//
// No file, so go through command line arguments and build the file list
//

        if (optind < argc)
            {
            for (i=optind; i < argc; i++)
                {
                target[num_files].base=ast.remove_path_extension(string(argv[i]), false, true);
                num_files++;
                }
            }
        else
            {
            cerr << "ERROR: No files specified" << endl;
            exit(1);
            }
        }

//
// If there was an input file, assign the modes here
//

    if (inp_mode)
        {
        for (i=0; i <= num_files; i++)
            {
            if (!(mode_str[i].empty()))
                {
                for(auto cval=mode_str[i].cbegin(); cval != mode_str[i].cend(); ++cval)
                    {
                    val=(int) *cval;
                    if ((val >= M_INI) || (val <= M_FIN))
                        {
                        target[i].mode[val]=true;
                        }
                    else
                        {
                        cerr << "WARNING: Unknown mode " << *cval << " on line " << i << endl;
                        }
                    }
                }
            else
                {
                for (j=M_INI+1; j <= M_FIN; j++) target[i].mode[j]=true;
                }
            }
        }

//
// Check the mode values from the command line or the input file
//

    if ((modeinp[0] != '\0')&&(modeinp[1] != '\1'))
        {
        item=strtok((char *)modeinp.c_str(),",");
        while ( item != nullptr )
            {
            val=strtol(item, nullptr,10);
            if ((val >= M_INI) || (val <= M_FIN))
                {
                for (i=0; i <= num_files; i++) target[i].mode[val]=true;
                }
            else
                {
                cerr << "ERROR: Unknown mode " << item << endl;
                exit(1);
                }
            item = strtok(nullptr,",");
            }
        }
    else
        {
        if (!inp_mode)
            {
            for (i=0; i <= num_files; i++)
                {
                for (j=1; j <= M_FIN; j++) target[i].mode[j]=true;
                }
            }
        }

    fftw_plan   plan;

//
// Allocate the FFT arrays.  These need to be allocated with fftw_ functions
//   since they are not C-style 2D arrays.
//

    fftw_complex *in_data;
    fftw_complex *out_data;

    if (verbose) cout << "Allocating FFT Arrays..." << endl;

    in_data = (fftw_complex *) fftw_malloc((DIM_RAD*DIM_THT+1) * sizeof(fftw_complex));
    if(nullptr == in_data)
        {
        cerr << "ERROR: FFTW Memory allocation failed for in_data[]" << endl;
        exit(-1);
        }

    out_data = (fftw_complex *) fftw_malloc((DIM_RAD*DIM_THT+1) * sizeof(fftw_complex));
    if(nullptr == out_data)
        {
        cerr << "ERROR: FFTW Memory allocation failed for out_data[]" << endl;
        exit(-1);
        }

//
// Build a plan for the FFT transform
//

    if (verbose) cout << "Building plan for FFT..." << endl;
    plan=fftw_plan_dft_2d( (int) DIM_THT, (int) DIM_RAD, in_data, out_data, FFTW_BACKWARD, FFTW_MEASURE);
    if ( plan == nullptr )
        {
        cerr << "ERROR: FFTW plan failed, Exiting" << endl;
        exit(1);
        }
    else
        {
        if (verbose) cout << "Done" << endl;
        }

//
// MAIN LOOP through the list of input files to process them
//

    for(looper=0; looper < num_files; looper++)
        {

//
// Need to set start and end values appropriately
//

        if (DEBUG) cout << "St " << st << " En " << en << " start " << target[looper].start << " End " << target[looper].end << endl;

        beg_rad=finish=-1;
        if ((st != 0)&&(en !=0))
            {
            beg_rad=st;
            finish=en;
            }
        else
            {
            if (target[looper].start > 0) beg_rad=target[looper].start;
            if (target[looper].end > 0) finish=target[looper].end;
            }

        if (beg_rad < 0) beg_rad=1;

//
// If the filename ends in .fits (for user convenience), strip it
//

        if (DEBUG) cout << target[looper].base << "is the filename" << endl;
        target[looper].base=ast.remove_path_extension(target[looper].base, false, true);
        if (DEBUG) cout << target[looper].base << "after transformation" << endl;

//
// Read the first file to get the maximum radius.  If we fail to find this,
//   skip it and move on to the next file.
//

        if (verbose) cout << "  --> Processing Files for " << target[looper].base << endl;

        ostringstream infile;
        infile << target[looper].base << ".h5";

//
// Open the HDF5 data file and get the radius and the normalization values
//

        try
            {
            data_file=H5File(infile.str(), H5F_ACC_RDONLY);
            Attribute attr = data_file.openAttribute("radius");
            DataType typer = attr.getDataType();
            attr.read(typer,&maxrad);

            DataSet norm_set=data_file.openDataSet("/normalization");
            DataSpace norm_space=norm_set.getSpace();
            norm_set.read(&norma[1], PredType::NATIVE_DOUBLE);
            }
        catch( FileIException error)
            {
            cerr << "WARNING: Cannot open " << infile.str() << "...Skipping" << endl;
            err_cnt++;
            continue;
            }
        catch( DataTypeIException error)
            {
            cerr << "WARNING: Cannot get radius from " << infile.str() << "...Skipping" << endl;
            err_cnt++;
            continue;
            }

        if (DEBUG) cout << "MAXRAD " << maxrad << endl;

        if ((maxrad < 1) || (maxrad > (MAX_DIM-2)))
            {
            cerr << "WARNING: Error in file " << infile.str() << " (" << maxrad << ")...Skipping" << endl;
            err_cnt++;
            continue;
            }

//
// The last 10% of the radius calculations tend to return invalid results (like
//   -nan values, so reduce radius by 10%
//

        maxrad90=(int)((float)maxrad*0.9);

//
// Do some checking on the radius to see if it's logical
//

        if ((maxrad90 < 1) || (maxrad90 > MAX_DIM/2))
            {
            cerr << "WARNING: Invalid radius " << maxrad90 << " in file " << infile.str() << "...Skipping" << endl;
            err_cnt++;
            continue;
            }

        if ((maxrad < 1) || (maxrad > MAX_DIM/2))
            {
            cerr << "WARNING: Invalid radius " << maxrad << " in file " << infile.str() << "...Skipping" << endl;
            err_cnt++;
            continue;
            }

        if (verbose) cout << target[looper].base << ": Radius=" << maxrad << ":" << maxrad90 << endl;

//
// New set finish based on the radius
//

        if (finish<0)
            {
            finish=maxrad90;
            }
        else
            {
            if (finish > maxrad90)
                {
                finish=maxrad90;
                cerr << "WARNING: End radius beyond 90 percent for file " << target[looper].base << "...Trimming to " << finish << endl;
                }
            }

//
// Zero out the mat and val arrays completely, even though we only use a
//   subset of them.  Needs to be done once for each new file/directory, not
//   each radius.
//
        for (i=0; i < MAX_DIM; i++)
            {
            for (j=0; j < MAX_DIM; j++)
                {
                mat[i][j]=0.0;
                vals[i][j]=0.0;
                }
            }

//
// Set up the dimension variables as these will be the same for each radius.
//

        dim=(maxrad*2)+1;

        radstep=2.*PI/STEP_P/DIM_RAD;
        theta_step=2.*PI/GR_RAD/DIM_THT;

//
// Must completely zero the data arrays each time or you get incorrect results
//

        for(x=0;x<DIM_RAD*DIM_THT+1;x++)
            {
            in_data[x][0]=0.0;
            in_data[x][1]=0.0;
            out_data[x][0]=0.0;
            out_data[x][1]=0.0;
            }

//
// Loop for each radius.  Do the logarithm of the max radius outside the loop
//   for better performance.
//

        log_maxrad=log((double)finish);

        if (DEBUG) cout << "Beg_Rad " << beg_rad << " Finish " << finish << endl;
        for (radius = beg_rad; radius <= finish; radius++)
            {

//
// Read in files by mode.
//

            for (m=M_INI; m <= M_FIN; m++)
                {
                counter=m*DIM_RAD;

//
// Check if this mode is to be plotted
//

                if (!target[looper].mode[m])
                    {
                    continue;
                    }

//
// Create the data filename and open it
//

                struct  fft_out fft_data[401];
                ostringstream infile2;
                infile2 << "/rip_r"<< radius << "_m" << m;

                try
                    {
                    DataSet dataset=data_file.openDataSet(infile2.str());
                    DataSpace dataspace=dataset.getSpace();
                    dataset.read(fft_data, PredType::NATIVE_DOUBLE);
                    }
                catch (...)
                    {
                    cerr << "WARNING: Cannot read " << infile2.str() << "\n...Skipping" << endl;
                    continue;
                    }

//
// Map the dataset entries to the data array. P2DFFT writes these in frequency
//   order going from lowest to highest, but that's not the same order in
//   the data file.  This comment is long, but it's important if you want
//   to make code changes (like adding a different frequency cutoff). Of
//   course, it is vital that this mapping match the P2DFFT program, or the
//   output will be meaningless.
//
//      in_data     Description                      fft_data Index  HDF5 Index
//      -------     ---------------------            --------------  ----------
//        0,0       Real DC/0 Hz Component                200           400
//        0,1       Imaginary DC/0 Hz Component           200           401
//        1,0       Real 0.25 Hz (Min) Component          201           402
//        1,1       Imaginary 0.25 Hz (Min) Component     201           403
//       200,0      Real 50 Hz Component                  400           800
//       200,1      Imaginary 50 Hz Component             400           801
//       201,0      Real 50.25 Hz Component               N/S           N/S
//       201,1      Imaginary 50.25 Hz Component          N/S           N/S
//      1024,0      Real 256 Hz Component (Max)           N/S           N/S
//      1024,1      Imaginary 256 Hz Component (Max)      N/S           N/S
//      1025,0      Real -256 Hz Component (Max)          N/S           N/S
//      1025,1      Imaginary -256 Hz Component (Max)     N/S           N/S
//      1847,0      Real -50.25 Hz Component              N/S           N/S
//      1847,1      Imaginary -50.25 Hz Component         N/S           N/S
//      1848,0      Real -50 Hz Component                   0             0
//      1848,1      Imaginary -50 Hz Component              0             1
//      2047,0      Real -0.25 Hz Component (Min)         199           398
//      2047,1      Imaginary -0.25 Hz Component (Min)    199           399
//
//   This mapping is also for m0 only, other modes would have the same fft_data
//   and rip values, but the data indices would have mode*2048 added to them.
//
//   Finally, this table also assumes a fequency mapping of -50 to +50, if thats
//   different, then the start and end will be different.
//

                for(x= 0 ;x < 200; x++)
                    {
                    if (isfinite(fft_data[x+201].real)) in_data[counter+x+1][0] += fft_data[x+201].real*norma[radius];
                    if (isfinite(fft_data[x+201].imag)) in_data[counter+x+1][1] += fft_data[x+201].imag * -1.0*norma[radius];
                    if (DEBUG) cout << "Map fft_data " << counter+x+1 << " to in_data " << x+201 << endl;


                    if (isfinite(fft_data[x].real)) in_data[counter+x+1848][0] += fft_data[x].real*norma[radius];
                    if (isfinite(fft_data[x].imag)) in_data[counter+x+1848][1] += fft_data[x].imag * -1.0*norma[radius];
                    if (DEBUG) cout << "Map fft_data " << counter+x+1848 << " to in_data " << x << endl;

//                    if (DEBUG && radius==1)
                    }

                if (isfinite(fft_data[200].real)) in_data[counter][0] += fft_data[200].real * norma[radius];
                if (isfinite(fft_data[200].imag)) in_data[counter][1] += fft_data[200].imag * -1.0 * norma[radius];
                if (DEBUG) cout << "Map fft_data " << counter << " to in_data " << 200 << endl;
                }

//
// This if statement is handy for debugging if you make changes
//

            if (DEBUG && radius == 1)
                {
                for (x=0;x< DIM_RAD*DIM_THT; x++)
                    {
                    cout << "In Data[" << x << "][0]=" << in_data[x][0] << endl;
                    cout << "In Data[" << x << "][1]=" << in_data[x][1] << endl;
                    }
                }
            }

//
// This if statement is handy for debugging if you make changes
//

        if (DEBUG)
            {
            for (x=0;x< DIM_RAD*DIM_THT; x++)
                {
                cout << "All In Data[" << x << "][0]=" << in_data[x][0] << endl;
                cout << "All In Data[" << x << "][1]=" << in_data[x][1] << endl;
                }
            }

        fftw_execute_dft(plan, in_data, out_data);

        for (x=0; x < DIM_RAD*DIM_THT; x++)
            {
            out_data[x][0]/=(DIM_RAD*DIM_THT);
            out_data[x][1]/=(DIM_RAD*DIM_THT);
            }

//
// This if statement is handy for debugging if you make changes
//

        if (DEBUG)
            {
            for (x=0;x< DIM_RAD*DIM_THT; x++)
                {
                cout << "Out Data[" << x << "][0]=" << out_data[x][0] << endl;
                cout << "Out Data[" << x << "][1]=" << out_data[x][1] << endl;
                }
            }

//
// Map the polar coordinates in out_data[][] to Cartesian. The original mapping
//   in P2DFFT makes radial slices in small steps of theta, so this just
//   reverses the mapping.  Please note that some values are duplicated in the
//   polar version, so we need to account for this when mapping back to cart.
//

        if (verbose) cout << "Transform data lnr theta ---> X,Y" << endl;
        counter=0;
        count_theta=1;
        log_rad=log((double)finish);

//
// Step around theta angles (360 degrees in 0.35 steps)
//

        for(theta_degrees=0.0;count_theta<=DIM_THT;theta_degrees+=theta_step)
            {
            count_theta++;

//
// Convert the degrees to radians
//

            theta_radians=theta_degrees*GR_RAD;
            count_radians=1;

            for(lnr=0.0;count_radians<=DIM_RAD;lnr+=radstep)
                {
                count_radians++;
                if(lnr>(double)log_rad)
                    {
                    ++counter;
                    continue;
                    }

                fx=exp(lnr)*cos(theta_radians);
                fy=exp(lnr)*sin(theta_radians);

                x=(int)fx+maxrad+1;
                y=(int)fy+maxrad+1;

//
// If the data is valid, add the result to the combined matrix and increment the
//   number of values used.  This will be used to normalize the total value
//   later.  Invalid values tend to occur at outer radii, but can happen in
//   other places.  Having a NAN result in the image file is allowed, but
//   causes programs to ds9 to display the data in a less useful way.
//

                if (!(out_data[counter][0]!=out_data[counter][0]))
                    {
                     mat[x][y]+=out_data[counter][0];

                     vals[x][y]+=1.0;

                    if (DEBUG) cout << "Radius: " << radius << ": Assign Mat[" << x << "][" << y << "]=" << out_data[counter][0] << ", vals[" << x << "][" << y << "]=" << vals[x][y] << ", Index=" << counter << endl;
                    }
                ++counter;
                }
            }

//
// Need to create a matrix with the exact size and average data from all runs.
//   This is needed because the CFITSIO libraries can return incorrect results
//   if part of a larger array is used.  In addition, the matrix must have a
//   contiguous memory space, so you the astro_class function to allocate.
//

        if (verbose) cout << "Creating Output File..." << endl;

        result = ast.ArrayAlloc(dim,dim);

        for(i=0;i<dim;i++)
            {
            for(j=0;j<dim;j++)
                {
                result[i][j]=0.0;
                }
            }

//
// Normalize the values
//

        for(i=0;i<dim;i++)
            {
            for(j=0;j<dim;j++)
                {
                if (vals[j][i] != 0.0)
                    {
                    result[i][j] = mat[i][j] / vals[i][j];
                    if (DEBUG) cout << "Result[" << j << "][" << i << "]=" << result[j][i] << " mat=" << mat[i][j] << " vals=" << vals[i][j] << endl;
                    }
                }
            }

//
// Create binary FITS file
//

        naxes[0] = (long) dim;
        naxes[1] = (long) dim;

        ostringstream outfile;
        if ((mode_opt) || (inp_mode))
            {
            outfile << "I_";
            for (i = 1; i <= M_FIN; i++)
                {
                if (target[looper].mode[i]==1) outfile << i;
                }
            outfile << "_" << target[looper].base << ".fits";
            }
        else
            {
            outfile << "I_" << target[looper].base << ".fits";
            }

//
// The CFITSIO libraries don't work if the file already exists, so remove it
//

        sprintf(cmd,"rm -f %s",(char *)outfile.str().c_str());
        status=system(cmd);

        fits_create_file(&fptr,(char *)outfile.str().c_str(), &status);

        fits_create_img(fptr,FLOAT_IMG,naxis,naxes, &status);

        fits_write_img(fptr,TFLOAT,1,dim*dim,result[0],&status);

        fits_close_file(fptr, &status);

        fits_report_error(stderr,status);

        free(result);
        }

//
// Clean up open files and memory allocations
//

    fftw_destroy_plan(plan);
    fftw_free(in_data);
    fftw_free(out_data);
    }
