//
// PITCH_CLASS.CPP - This class provides functions for analysis and ordering
//                   of the FFT output data from P2DFFT.
//
//
// Version 1.6  17-Oct-2021
//
//
// Authors:  Ian Hewitt & Dr. Patrick Treuthardt,
//           NC Museum of Natural Sciences,
//           Astronomy & Astrophysics Lab,
//           Raleigh, NC USA.
//           http://github.com/treuthardt/P2DFFT
//
//
// LICENSE
//
// P2DFFT Spiral Galaxy Arm Pitch Angle Analysis Suite
// Copyright (c) 2016-2024  Ian B. Hewitt & Dr. Patrick Treuthardt
//
// The program is free software:  you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation, version 3.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
// details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see < https://www.gnu.org/licenses >.
//
// The authors can be contacted at:
//
//      North Carolina Museum of Natural Sciences
//      Astronomy & Astrophysics Laboratory
//      11 West Jones Street
//      Raleigh, NC, 27601  USA
//      +1.919.707.9800
//
//      -- or --
//
//      patrick.treuthardt@naturalsciences.org
//
//
// Revision History:
//      1.6  17-Oct-2021: - Fix bug where an incorrect pitch angle value would
//                          be returned if all amplitudes were 0.
//      1.5  17-Dec-2020: - Change multiple functions to use boolean values
//                        - Change NaN checking to use explicit function
//                        - Use enumerated error types instead of hard coded
//                          return values
//                        - Change to stream based I/O
//                        - Change float to double to match FFTW3 return values
//      1.4  16-Jun-2020: - Added explicit conversion for phase angle values
//                          to increase precision
//      1.3  07-Apr-2018: - Change snr() and fwhm() to set calculated values in
//                          the return structure and just return a staus code
//      1.2  16-Mar-2018: - Fix bug due to FP rounding error in SNR
//                        - Add warn flag and set_warn() function, and add
//                          checks for this flag on print statements
//                        - Add prefix to print statements (ERROR, WARNING)
//      1.1  18-Feb-2018: - Add snr() and fwhm() functions
//                        - Fix small bug in pitch_phase()
//                        - Remove DC component from calculations
//                        - Add return codes from NaN and errors
//                        - Add include file version number in print
//                        - Clean up error messaging
//      1.0  05-Feb-2018: - Initial version
//

#include    <cstdio>
#include    <string>
#include    <fstream>
#include    <sstream>
#include    <magic.h>
#include    <cmath>
#include    <sys/stat.h>
#include    <sys/types.h>

#include    "globals.h"
#include    "pitch_class.h"

using namespace std;

const string PITCH_VER="1.5/20201217";

bool        pitch_warn=false;

//
// Define the error variable macro to set the error
//

pitch_error_t   pitch_errno=PITCH_ERR_NONE;

//
// CONSTANTS -- These must match the values used in the P2DFFT algorithms
//

#define LO_INDEX    824
#define HI_INDEX    1226

//
// FUNCTIONS
//


//
// SET_WARN() - Sets the value of the warning flag which controls the
//              printing of warning messages
//
// Arguments:
//      value   - 0 for no warnings, non-zero for warnings
//
// Return Value: NONE
//

void    pitch::set_warn(bool value)
    {
    pitch_warn=value;
    }


//
// VERSION() - This function will print the current version.
//
// Arguments: NONE
//
// Return Value: NONE
//

void    pitch::version()
    {
    cout << "  -- Pitch Class Include Version:  " << PITCH_H_VER << endl;
    cout << "  -- Pitch Class Function Version:  " << PITCH_VER << endl;
    }


//
// GET_ERR() - This function will return the lastest error number
//
// Arguments: NONE
//
// Return Value: Most recent error code defined in pitch_class.h
//

pitch_error_t    pitch::get_err()
    {
    return(pitch_errno);
    }


//
// PITCH_PHASE() - This public function will parse the FFT data and determine
//                 the highest frequency and amplitude.  It will also
//                 calculate the corresponding pitch and phase angles.
//
//                 This routine replace the give_maximum_pitch_phase.f program
//
// Arguments:
//      fft     - Pointer to array of FFT output data
//      res     - Structure For return information
//
// Return Value:
//      true    - Processing ended normally, results in res valid`
//      false   - Processing returned NaN (low to no signal) or error
//                encountered and no results returned
//

bool   pitch::pitch_phase(fft_out *fft, int mode, result_pa *res)
    {
    int     i;
    int     nan=1;
    int     index;

    double  amp;
    double  a_max;

//
// Find Highest Amplitude/Frequency
//

    a_max=-255.0;
    index=-1;
    for (i=0; i < 401; i++)
        {
//
// Calculate the amplitude
//

        amp = sqrt(pow(fft[i].real,2.0)+pow(fft[i].imag,2.0));

//
// Need at least one NaN value or the results are not valid
//

        if (!(isnan(amp))) nan=0;

        if ((amp > a_max) && (i != 200))
            {
            index=i;
            a_max=amp;
            }
        }

    if (DEBUG) clog << "DEBUG: Max Amp " << a_max << ", Index=" << index << endl;

    if (nan)
        {
        pitch_errno = PITCH_ERR_ALLNANS;
        return(false);
        }

    if (index < 0)
        {
        if (pitch_warn) cerr<< "WARNING: Can't locate maximum amplitude" << endl;
        pitch_errno = PITCH_ERR_MAX_AMP;
        return(false);
        }

    res->amp=a_max;

//
// Need to check if the highest amnplitude is zero (this is possible), so we
//   want a frequency of 0
//

    if (a_max > 0.0)
        {
        res->freq=-50.0 + ((double) index * 0.25);
        res->index=index;
        }
    else
        {
        res->freq=0.0;
        res->index=200;
        }

//
// Calculate the pitch and phase angles
//

    res->pa=atan2((double)-mode,res->freq)*(1.0/GR_RAD);

    if (fabs(res->pa) > 90.0) res->pa+=180.0;
    res->phase=atan2(fft[index].imag,fft[index].real)*(1.0/GR_RAD)/(double)mode;
    return(true);
    }


//
// SNR() - Returns the signal to noise value for a FFT data block.
//
// Arguments:
//      fft     - Pointer to array of FFT output data
//      res     - Return information from pitch phase
//
// Return Value:
//      true    - Processing ended normally, results in res valid`
//      false   - Processing returned NaN (low to no signal) or error
//                encountered and no results returned
//

bool   pitch::snr(fft_out *fft, result_pa *res)
    {
    int     i;

    double  amp;
    double  L=0.0;
    double  sigma;
    double  avg=0.0;
    double  vals=0.0;

//
// Find the average value, L, and set it in the return structure
//

    for (i=0; i < 401; i++)
        {
//
// Calculate the amplitude
//

        amp = sqrt(pow(fft[i].real,2.0)+pow(fft[i].imag,2.0));

        if ((i != 200) && !(isnan(amp)))
            {
            avg+=amp;
            vals+=1.0;
            }
        }

    if (vals < 0.5)
        {
        pitch_errno = PITCH_ERR_ALLNANS;
        return(false);
        }

    L=avg/vals;
    res->avg_amp=L;

    avg=0.0;

//
// Determine the SNR/sigma
//

    for (i=0; i < 401; i++)
        {
//
// Calculate the amplitude
//

        amp = sqrt(pow(fft[i].real,2.0)+pow(fft[i].imag,2.0));
        if ((i != 200) && !(isnan(amp))) avg+=pow((amp-L),2.0);
        }

    sigma=pow((avg/vals),0.5);

    if (sigma <= 1e-10)
        {
        pitch_errno = PITCH_ERR_SIGMA;
        return(false);
        }

    res->snr=(res->amp-L)/sigma;

    if (DEBUG) clog << "DEBUG: SNR=" << res->snr << ", Sigma=" << sigma << ", L=" << L << endl;

    if (isnan(res->snr))
        {
        pitch_errno = PITCH_ERR_ALLNANS;
        return(false);
        }

    return(true);
    }


//
// FWHM() - Returns the FWHM for an FFT data block.
//
//         NOTE: pitch_phase() and snr() must have been called and populated the
//               res data structure (with valid data) before calling this
//               routine.
//
// Arguments:
//      fft     - Pointer to array of FFT output data
//      res     - Return information from pitch phase
//
// Return Value:
//      PITCH_RET_OK       - Processing ended normally, results in res valid`
//      PITCH_RET_NAN      - Processing returned NaN (low to no signal)
//      PITCH_RET_ERR      - Error encountered, no results returned
//


bool   pitch::fwhm(fft_out *fft, result_pa *res)
    {
    int     i;
    int    lo=0;
    int    hi=0;

    double  amp;
    double  limit;

//
// Check the data in res block.  Ideally this should never happen, but we check
//   to make sure.
//

    if ((res->index < 0) || (res->index > 400))
        {
        if (pitch_warn) cerr << "WARNING: Invalid data in res block" << endl;
        pitch_errno = PITCH_ERR_INVALID;
        return(false);
        }

//
// Track the slope of the right side (positive direction) of the peak.  Stop
//   when the slope is no longer negative or noise floor is encountered.
//

    limit=res->amp - ((res->amp - res->avg_amp)/2.0);
    i=res->index+1;

    while (i < 401)
        {
//
// Calculate the amplitude
//

        amp = sqrt(pow(fft[i].real,2.0)+pow(fft[i].imag,2.0));

        if (DEBUG) clog << "DEBUG: Process Index " << i << ", ABS=" << amp << ", LIMIT=" << limit << endl;
        if (i != 200)
            {
            if (amp < limit)
                {
                hi=i-1;
                break;
                }
            }
        i++;
        }

    i=res->index-1;

    while (i >= 0)
        {
//
// Calculate the amplitude
//

        amp = sqrt(pow(fft[i].real,2.0)+pow(fft[i].imag,2.0));

        if (DEBUG) clog << "DEBUG: Process Index " << i << ", ABS=" << amp << ", LIMIT=" << limit << endl;
        if (i != 200)
            {
            if (amp < limit)
                {
                lo=i+1;
                break;
                }
            }
        i--;
        }

    if (DEBUG) clog << "DEBUG: Hi=" << hi << ", Lo=" << lo << endl;

    if ((hi==0) || (lo==0))
        {
        pitch_errno = PITCH_ERR_SCANFWHM;
        return(false);
        }

    res->fwhm=(double)(hi - lo + 1);

    if (isnan(res->fwhm))
        {
        pitch_errno = PITCH_ERR_ALLNANS;
        return(false);
        }

    return(true);
    }
