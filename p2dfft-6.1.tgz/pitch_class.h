//
// PITCH_CLASS.H - This class provides functions for interpreting the FFT
//                 results from P2DFFT.
//
//
// Version 1.5: 26-Dec-2020
//
//
// Authors:  Ian Hewitt & Dr. Patrick Treuthardt,
//           NC Museum of Natural Sciences,
//           Astronomy & Astrophysics Lab,
//           Raleigh, NC USA.
//           http://github.com/treuthardt/P2DFFT
//
//
// LICENSE
//
// P2DFFT Spiral Galaxy Arm Pitch Angle Analysis Suite
// Copyright (c) 2016-2024  Ian B. Hewitt & Dr. Patrick Treuthardt
//
// The program is free software:  you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation, version 3.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
// details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see < https://www.gnu.org/licenses >.
//
// The authors can be contacted at:
//
//      North Carolina Museum of Natural Sciences
//      Astronomy & Astrophysics Laboratory
//      11 West Jones Street
//      Raleigh, NC, 27601  USA
//      +1.919.707.9800
//
//      -- or --
//
//      patrick.treuthardt@naturalsciences.org
//
//
// Revision History:
//	1.6  29-Oct-2024: - Change structure alignment to be set to the
//                          required minimum alignment instead of a fixed value
//      1.5  26-Dec-2020: - Add data alignment directives
//                        - Move fft_out type definition to globals.h
//      1.4  17-Dec-2020: - Change error values from fixed values to enumerated
//                          types
//                        - Update prototypes for changes to C++17 types
//                        - Remove macros
//      1.3  07-Apr-2018: - Change to put snr and fwm in the result_pa struct
//      1.2  16-Mar-2018: - Add get_warn() function
//      1.1  17-Feb-2018: - Add snr() and fwhm() functions
//                        - Update error code
//                        - Add return code definitions
//                        - Add include file version number
//      1.0  04-Feb-2018: - Initial version
//

#include    <cstddef>
#include    <iostream>
#include    <string>

using namespace std;

const string PITCH_H_VER="1.6/20241029";

//
// Error Values
//

enum  pitch_error_t
          {
          PITCH_ERR_NONE,       // No Error
          PITCH_ERR_INVALID,    // Frequency Index Out of Range
          PITCH_ERR_MAX_AMP,    // Failed to Determine Maximum Amplitude
          PITCH_ERR_ALLNANS,    // No Valid Values in Input Structure
          PITCH_ERR_SIGMA,      // Error Too Small To Calculate
          PITCH_ERR_SCANFWHM    // Failed to Calculate FWHM
          };

//
// Data structure for FFT basic output analysis
//

struct  alignas(alignof(double)) result_pa
    {
    int         index;     /* Index of highest amplitude                */
    double      freq;      /* Frequency of highest amplitude            */
    double      amp;       /* Highest amplitude                         */
    double      avg_amp;   /* Average amplitude (noise level)           */
    double      pa;        /* Calculated pitch angle                    */
    double      phase;     /* calculated phase angle                    */
    double      snr;       /* calculated signal-to-noise ratio          */
    double      fwhm;      /* calculated full width half maximum        */
    };

//
// Class definition values
//

class   pitch {
              public:
                  void           set_warn(bool value);
                  void           version();
                  pitch_error_t  get_err();
                  bool           pitch_phase(fft_out *fft, int mode, result_pa *res);
                  bool           snr(fft_out *fft, result_pa *res);
                  bool            fwhm(fft_out *fft, result_pa *res);
              };
