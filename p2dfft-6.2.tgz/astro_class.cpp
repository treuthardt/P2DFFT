//
// ASTRO_CLASS.CPP - This class provides functions for astronomical analysis,
//                   specifically the P2DFFT pitch angle analysis packages.
//
//
// Version 3.7: 25-Nov-2024
//
//
// Authors:  Ian Hewitt & Dr. Patrick Treuthardt,
//           NC Museum of Natural Sciences,
//           Astronomy & Astrophysics Lab,
//           Raleigh, NC USA.
//           http://github.com/treuthardt/P2DFFT
//
//
// LICENSE
//
// P2DFFT Spiral Galaxy Arm Pitch Angle Analysis Suite
// Copyright (c) 2016-2024  Ian B. Hewitt & Dr. Patrick Treuthardt
//
// The program is free software:  you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation, version 3.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
// details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see < https://www.gnu.org/licenses >.
//
// The authors can be contacted at:
//
//      North Carolina Museum of Natural Sciences
//      Astronomy & Astrophysics Laboratory
//      11 West Jones Street
//      Raleigh, NC, 27601  USA
//      +1.919.707.9800
//
//      -- or --
//
//      patrick.treuthardt@naturalsciences.org
//
//  Revision History:
//
//      3.7  25-Nov-2024: - Remove using directive
//                        - Remove file_type() and file_exists functions
//                        - Add support in read_lines() for specifying inner
//                          radius
//                        - Add support for comments and ignoring spaces/tabs
//                          in the parameter file
//      3.6  10-Nov-2024: - Change code to use one constant for max image
//                          dimension
//      3.5  03-Sep-2022: - Fix spelling error in comments
//                        - Update error message in fits_read() with better
//                          information
//                        - Fix error in version string formatting
//      3.4  11-Oct-2021: - Reverse the order of the radius and output prefix
//                          in parameter file (readlines)
//                        - Fix incorrect version string
//                        - Fix comments
//      3.3  17-Dec-2020: - Correct header comment errors
//                        - Change char* to string
//                        - Remove macros
//                        - Add remove path_extension() function
//                        - Change all I/O to use streams
//                        - Change to C++ include style
//                        - Fix bug where processing rectangular image files
//                          would result in incorrect dimensions
//                        - Fix bug where non-string file input was not handled
//                          correctly
//                        - Change to use explicit null pointer values
//                        - Change some memory allocation calls to newer C++
//                          style calls (new())
//                        - Remove incorrect exit call
//      3.2  16-Jun-2020: - Fix bug in fits_dims() which reversed the x and y
//                          dimensions which caused errors in non-square images
//                        - Fix bug in version string
//      3.1  23-Feb-2020: - Fix all return codes to be constants in
//                          astro_class.h instead of hard coded values
//                        - Improve logic in the input file reading routine to
//                          be more consistent and less redundant
//      3.0  12-Jun-2018: - Update FITS data read/write routines to use 2D
//                          functions and to compensate for row/col ordering
//                        - Fix fits_read() to allocate a buffer based on the
//                          size specified and not a fixed number
//      2.2  26-May-2018: - Add fits_write() function code
//                        - Add fits_header_write() function code
//                        - Add ASTRO_******* return codes
//                        - Update comments
//                        - Align error message output
//                        - Remove placeholders for fits_text_read/write
//                        - Fix bug  where multiple calls to a function
//                          might fail
//      2.1  16-Mar-2018: - Fix bug in debug statement (very meta)
//                        - Add warn flag and set_warn() function
//                        - Add warn flag check to print statements
//                        - Add prefixes to print statements (ERROR, WARNING)
//                        - Add astro_class.h version output to version()
//      2.0  05-Feb-2018: - Add version print function
//                        - Update comments
//                        - Use globals.h instead of local defs (e.g. DEBUG)
//                        - Add get_err function and remove extern var for
//                          error numbers
//                        - Removed deprecated cmd_path() function
//                        - Remove the astro_print variable and have all
//                          routines automatically print error messages
//                        - Remove requirement that images are square
//      1.3  28-Aug-2017: - Minor changes to eliminate compiler warnings on
//                          some Linux distributions
//      1.2  07-Jun-2017: - CRITICAL Fix:  Remove all C++11 code and replace
//                          it with traditional C++ code because some
//                          compiler/library combinations caused the C++11
//                          code to return erroneous results
//                        - Remove redefinition of BIN_DIR since it is
//                          passed in on the compiler line from the makefile
//      1.1  21-Feb-2017: - Change fitsio.h include to system (<>) from
//                          from local ("")
//                        - All error message did not return the FITS text
//                          error message along with the code.  This was
//                          added where missing.
//                        - Remove unused variable
//      1.0  19-Feb-2017: - Initial version
//

#include    <string.h>
#include    <unistd.h>
#include    <fstream>
#include    <sstream>
#include    <magic.h>
#include    <sys/stat.h>
#include    <sys/types.h>

#include    "astro_class.h"
#include    <fitsio.h>

#include    "globals.h"

const std::string ASTRO_VER="3.7/20241125";

bool        astro_warn=false;

//
// Define macro and variable for error handling
//

astro_error_t astro_errno=ASTRO_ERR_NONE;

//
// FUNCTION BLOCK
//

//
// SET_WARN() - Set the value of the warning flag to indicate if warnings
//              should be printed to standard out
//
// Arguments: NONE
//      0 for no warnings.   Error value if there is a an error/warning.
//
// Return Value: NONE
//

void   astro::set_warn(bool value)
    {
    astro_warn=value;
    }


//
// GET_ERR() - This function will return the latest error number
//
// Arguments: NONE
//
// Return Value: Most recent error code defined in astro_class.h
//

astro_error_t  astro::get_err()
    {
    return(astro_errno);
    }


//
// VERSION() - This function will print the current version.
//
// Arguments: NONE
//
// Return Value: NONE
//

void    astro::version()
    {
    std::cout << "  -- Astro Class Include Version:  " << ASTRO_H_VER << "\n";
    std::cout << "  -- Astro Class Function Version:  " << ASTRO_VER << "\n";
    }


//
// REMOVE_PATH_EXTENSION() - Takes a filename and strips the extension and path
//                           to make a return string of the base filename.  If
//                           no extension and/or path is found, the original
//                           argument is returned.
//
// Arguments:
//      filename - string with path/filename
//
// Return Value:
//      String with filename without extension/[ath], or if no extension is
//      present,the original filename is returned
//

std::string astro::remove_path_extension(std::string filename, bool pathr, bool extr)
    {
//
// Locate potential extension
//

    size_t slashpos;
    if (pathr)
        {
        slashpos = filename.find_last_of("/");

//
// If we get back bad slashpos values, need to correct so we get the entire
//   string.  Technically npos is == -1 already, but that may change in the
//   future.
//

        if (slashpos == std::string::npos) slashpos=-1;
        }
    else slashpos=-1;

    size_t lastdot;
    if (extr) lastdot = filename.find_last_of(".");
    else lastdot=std::string::npos;

//
// Copy, stripping extension and path
//

    return filename.substr(slashpos+1, lastdot-slashpos-1);
    }


//
//   READ_LINES() - Reads the contents of parameter file and populates the
//                  file_rec structure with the results.
//
// Arguments:
//      fname   - String with file name to be read
//      rec     - Pointer to vector (array) of file_rec structs (astro_class.h)
//
// Return Value:
//      true    - Success
//      false   - Failure (astro_errno will be set with detailed code)
//
// Errors:  Function will set astro_errno with return code (see astro_class.h)
//

bool  astro::read_lines(std::string fname, std::vector<file_rec> *rec)
    {
    int         x, y;
    int         calc_rad;
    std::string token;

//
// Try to open parameters file
//

    std::ifstream   fs;
    if (DEBUG) std::cout << "DEBUG: astro::read_lines() Calling Open\n";
    fs.open(fname);

//
// Check if any error flags are set
//

    if (!fs.good())
        {
        if (astro_warn==true) std::cerr << "WARNING: astro::read_lines: Input Parameter Filename Error\n";
        astro_errno=ASTRO_ERR_OPEN;
        return(false);
        }

    std::string     line;

    if (DEBUG) std::cout << "DEBUG: astro::read_lines() Starting Loop\n";

    while (getline(fs, line))
        {
        if (DEBUG) std::cout << "DEBUG: Line: " << line << ":\n";

//
// Ignore any blank lines
//

        if (line.empty())
            {
            if (DEBUG) std::cout << "DEBUG: Skipping Blank Line...\n";
            continue;
            }

//
// Ignore any comments
//

        auto found = line.find_first_not_of(" \t", 0, 2);
        if (line[found] == '#')
            continue;

//
// Set up variables to read in the line.  We stream the line read from
//   the file as a character stream, ss
//

        file_rec    f;
        std::istringstream  ss(line);

//
// Get the FITS input file name.  This should always be there.  If not, it's an
//   error, so skip the line.
//

        getline(ss, f.name, ',');
        if (DEBUG) std::cout << "DEBUG: Name: " << f.name << "\n";

//
// Check if filename is missing for some reason and if so, skip this line
//

        if (f.name.empty())
            {
            if (astro_warn==true) std::cerr << "WARNING: astro::read_lines: Filename Missing\n";
            if (DEBUG) std::cout << "DEBUG: Skipping Missing Filename...\n";
            continue;
            }

//
// We have a name entry. Check the file by getting the dimensions, even if we
//   will not use the dimensions to get the radius.
//

        if (fits_dims(f.name, &x, &y)==false)
            {
            if (astro_warn==true) std::cerr << "WARNING: astro::read_lines: FITS Read Failed for " << f.name << "\n";
            if (DEBUG) std::cout << "DEBUG: Skipping File with Bad FITS Header...\n";
            continue;
            }

//
// Calculate default result value
//

        std::string def_res = remove_path_extension(line.substr(0, line.find(',')), true, true);

//
// The filename is a valid FITS file. Check for an other values (if there).
//

        getline(ss, token, ',');

        if (token.empty())
            {
//
// This is case where we only have a filename, so everthing is
//   default
//

            f.inner = 1;
            if (y < x)
                {
                f.radius=(y-1)/2;
                }
            else
                {
                f.radius=(x-1)/2;
                }
            f.result = def_res;

            if (DEBUG) std::cout << "DEBUG: Defaults for FITS file: " << f.inner << " " << f.radius << " " << f.result << "\n";
            
            f.valid=true;            
            }
        else // There is an inner radius value
            {
            f.inner = std::stoi(token);
            getline(ss, token, ',');

            if (token.empty()) // No outer radius or result name
                {
                if (y < x)
                    {
                    f.radius=(y-1)/2;
                    }
                else
                    {
                    f.radius=(x-1)/2;
                    }
                f.result = def_res;

                if (DEBUG) std::cout << "DEBUG: Inner Only: " << f.inner << " " << f.radius << " " << f.result << "\n";
            
                f.valid=true;            
                }
            else // There is an outer radius value
                {
                f.radius = std::stoi(token);
                getline(ss, token, ',');

                if (token.empty()) // No outer radius or result name
                    {
                    f.result = def_res;

                    if (DEBUG) std::cout << "DEBUG: Inner and Outer: " << f.inner << " " << f.radius << " " << f.result << "\n";
            
                    f.valid=true;                           
                    }
                else
                    {
                    f.result = token;
                    f.valid = true;
                    }
                }
            }
        token.clear();
        rec->push_back(f);
        }

    return(true);
    }


//
// FITS_DIMS() - Reads the FITS header of a file and returns the rows and
//               columns in the file.  This routine currently assumes only
//               two axes.
//
//               PLEASE NOTE: FITS and C/C++ have different senses of
//               slowest and fastest varying dimensions (they are opposite).
//               This function preserves FITS ordering of the dimensions.
//
// Arguments:
//      fname   - Text string of filename to be read
//      rows    - Number of rows (slowest changing index)
//      columns - Number of columns (fastest changing index)
//
// Return Value:
//      true    - Success getting values
//      false   - Failure
//
// Other External Effects:
//      rows    - Will be updated with the number of rows
//      columns - Will be updated with the number of columns
//
// Errors:  Function will set astro_errno with error type (see astro_class.h)
//

bool    astro::fits_dims(std::string fname, int *rows, int *cols)

    {
    int         status=0;
    char        err_text[81];
    char        *file;
    long        naxes[2];
    fitsfile    *dim_p=nullptr;

    file=(char *) fname.c_str();
    if (fits_open_file(&dim_p, file, READONLY, &status)!=0)
        {
        fits_get_errstatus(status,err_text);
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_dims:fits_open_file() Error " << status << ": " << err_text << "\n";
        astro_errno = ASTRO_ERR_OPEN;
        return(false);
        }

    if (fits_get_img_size(dim_p, 2, naxes, &status)!=0)
        {
        fits_get_errstatus(status,err_text);
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_dims:fits_get_img_size() Error " << status << ": " << err_text << "\n";
        fits_close_file(dim_p, &status);
        astro_errno = ASTRO_ERR_GET_SIZE;
        return(false);
        }

    *cols=(int)naxes[0];
    *rows=(int)naxes[1];


    if (DEBUG) std::cout << "DEBUG: rows=" << *rows << ":cols=" << *cols << "\n";

    if (fits_close_file(dim_p, &status)!=0)
        {
        fits_get_errstatus(status,err_text);
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_dims:fits_close_file() Error " << status << ": " << err_text << "\n";
        astro_errno = ASTRO_ERR_CLOSE;
        return(false);
        }

    return(true);
    }


//
// FITS_HEADER_READ() - Reads all fields of the FITS header and returns a
//                      character array with the information (on record per
//                      string)
//
// Arguments:
//      fname   - Test string with FITS filename to be read
//      nkey    - Pointer to variable which will contain the number of keys
//                (fields) in the header
//
// Return Value:
//      char ** - Array of strings (one string per header record/field)
//
// Errors:  Function will return nullptr andset astro_errno with return code
//          (see astro_class.h)
//

char    **astro::fits_header_read(std::string fname, int *nkeys)
    {
    int         i, pos, status=0;
    char        card[2048];
    char        err_text[81];
    char        **hdr_blk;
    fitsfile    *hdr_p=nullptr;

    if (DEBUG) std::cout << "DEBUG: astro::fits_header_read:Call fits_open_file()\n";

    if (fits_open_file(&hdr_p, fname.c_str(), READONLY, &status)!=0)
        {
        fits_get_errstatus(status,err_text);
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_header_read:fits_open_file() Error " << status << ": " <<  err_text << "\n";
        astro_errno = ASTRO_ERR_OPEN;
        return(nullptr);
        }

    if (DEBUG) std::cout << "DEBUG: astro::fits_header_read:Call fits_get_hdrpos()\n";

    if (fits_get_hdrpos(hdr_p, nkeys, &pos, &status)!=0)
        {
        fits_get_errstatus(status,err_text);
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_header_read:fits_get_hdrpos() Error " << status << ": " << err_text << "\n";
        fits_close_file(hdr_p, &status);
        astro_errno = ASTRO_ERR_HDR_POS;
        return(nullptr);
        }

//
// Allocate memory for return value
//

    if (DEBUG) std::cout << "DEBUG: astro::fits_header_read:Call ArrayAlloc()\n";

    if ((hdr_blk=CArrayAlloc(*nkeys, 2048))==nullptr)
        {
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_header_read:CArrayAlloc() Error\n";
        fits_close_file(hdr_p, &status);
        astro_errno = ASTRO_ERR_MALLOC;
        return(nullptr);
        }

    if (DEBUG)
        {
        std::cout << "DEBUG: astro::fits_header_read:Keys=" << *nkeys << ", hdr_blk=" << hdr_blk << "," << hdr_blk[0] << "\n";
        std::cout << "DEBUG: astro::fits_header_read:Start read_record loop\n";
        }

    for (i=1; i <= *nkeys; i++)
        {
        if (fits_read_record(hdr_p, i, card, &status)!=0)
            {
            fits_get_errstatus(status,err_text);
            if (astro_warn==true) std::cerr << "WARNING: astro::fits_header_read:fits_read_record() Error " << status << ": " << err_text << "\n";
            free(hdr_blk);
            fits_close_file(hdr_p, &status);
            astro_errno = ASTRO_ERR_RD_REC;
            return(nullptr);
            }

        if (DEBUG) std::cout << "DEBUG: " << i << ":**" << card << "**\n";
        strncpy(hdr_blk[i-1],card,2048);
        }

    if (DEBUG) std::cout << "DEBUG: astro::fits_header_read:Call fits_close_file()\n";

    if (fits_close_file(hdr_p, &status)!=0)
        {
        fits_get_errstatus(status,err_text);
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_header_read:fits_close_file() Error " << status << ": " << err_text << "\n";
        free(hdr_blk);
        astro_errno = ASTRO_ERR_CLOSE;
        return(nullptr);
        }

    return(hdr_blk);
    }


//
// FITS_HEADER_WRITE() - Routine to write one or more keys to a FITS file
//
// Arguments:
//      fname   - Text filename for FITS file to be written
//      keys    - Array of strings with the key names to be written
//      items   - Array of strings containing the value for each key
//      num     - number of keys to be written
//
// Return Value:
//      true    - All keys written successfully
//      false   - Error writing one or more keys
//
// Errors:  Function will set astro_errno with return code (see astro_class.h)
//

bool   astro::fits_header_write(std::string fname, std::string keys[], std::string items[], int num)
    {
    int         i;
    int         status=0;
    char        err_text[81];
    fitsfile    *fptr=nullptr;

//
// Open the file for read/write
//

    if (DEBUG) std::cout << "DEBUG: astro::fits_header_write:fits_open_file\n";

    if (fits_open_file(&fptr, fname.c_str(), READWRITE, &status)!=0)
        {
        fits_get_errstatus(status,err_text);
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_header_write:open() Error " << status << ": " << err_text << "\n";
        astro_errno = ASTRO_ERR_OPEN;
        return(false);
        }

//
// Loop through the keys
//

    for (i=0; i<num; i++)
        {
        if (fits_write_key(fptr, TSTRING, keys[i].c_str(), (char *) items[i].c_str(), nullptr, &status)!=0)
            {
            fits_get_errstatus(status,err_text);
            if (astro_warn==true) std::cerr << "WARNING: astro::fits_header_write:fits_write_key() Error " << status << ": " << err_text << "\n";
            astro_errno = ASTRO_ERR_KEY;
            return(false);
            }
        }

    if (fits_close_file(fptr, &status)!=0)
        {
        fits_get_errstatus(status,err_text);
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_header_write:fits_close_file() Error " << status << ": " << err_text << "\n";
        astro_errno = ASTRO_ERR_CLOSE;
        return(false);
        }

    return(true);
    }


//
// FITS_READ() - Reads the image data from a 2D binary FITS file and returns
//               it in one dimensional array.   All the data read will be
//               converted to floating point format regardless of it's
//               encoding in the FITS file.
//
//               PLEASE NOTE:  The sense of indices will be preserved.  The
//               fastest varying index will be rows and the slowest varying
//               index will be columns.  This is opposite of how C/C++ usually
//               manages these.
//
//               PLEASE ALSO NOTE:  FITS files will start data at index 1,
//               not zero.  Size will be set to the number of entries, but
//               this means the array in C will go from [0...size], instead
//               [0...size-1].
//
// Arguments:
//      fname   - Text filename for FITS file to be read
//      size    - Pointer to variable that will be set to the number of data
//                entries in the return array.
//
// Return Value:
//      float * - pointer to base of one dimensional array with image data
//
// Errors:  Function will return nullptr and set astro_errno with return code
//          (see astro_class.h)
//

float   *astro::fits_read(std::string fname, int *size)
    {
    int         i, xnum, ynum, status=0;
    long        nelements, fpixel[2];
    float       *fdata;
    char        err_text[81];
    fitsfile    *p=nullptr;

//
// Get Actual size of data in file.  Don't set astro_errno here because
//   fits_dims() will set it appropriately if there is a problem.
//

    if (fits_dims(fname, &xnum, &ynum)==false)
        {
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_read:fits_dims() Error\n";
        return(nullptr);
        }

        if (DEBUG) std::cout << "DEBUG: astro::fits_read:dims xnum=" << xnum << ", ynum=" << ynum << "\n";

//
// Open the file for reading
//

    if (fits_open_file(&p, fname.c_str(), READONLY, &status)!=0)
        {
        fits_get_errstatus(status,err_text);
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_read:fits_open_file() Error " << status << ": " << err_text << "\n";
        astro_errno = ASTRO_ERR_OPEN;
        return(nullptr);
        }

    if (DEBUG) std::cout << "DEBUG: astro::fits_read:fits_file_open\n";

//
// Allocate memory for the data reading buffer based on the size dimensions
//

    try
        {
        fdata=new float[xnum*ynum]{0.0};
        }
    catch (...)
        {
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_read:new() - Could not allocate buffer\n";
        fits_close_file(p, &status);
        astro_errno = ASTRO_ERR_MALLOC;
        return(nullptr);
        }

    if (DEBUG) std::cout << "DEBUG: astro::fits_read:new " << xnum*ynum << " (" << xnum << " x " << ynum << " x float size) bytes\n";

    fpixel[0]=fpixel[1]=(long) 1;
    nelements=(long)(xnum*ynum);

    if (fits_read_pix(p, TFLOAT, fpixel, nelements, nullptr, fdata, nullptr, &status)!=0)
        {
        fits_get_errstatus(status,err_text);
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_read:fits_read_pix() Error " << status << ": " << err_text << "\n";
        delete [] fdata;
        fits_close_file(p, &status);
        astro_errno = ASTRO_ERR_READPIX;
        return(nullptr);
        }

    if (fits_close_file(p, &status)!=0)
        {
        fits_get_errstatus(status,err_text);
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_read:fits_close_file() Error " << status << ": " << err_text << "\n";
        delete [] fdata;
        astro_errno = ASTRO_ERR_CLOSE;
        return(nullptr);
        }
    *size=xnum*ynum;
    return(fdata);
    }


//
// FITS_WRITE() - Write an image to a FITS file.  The image can be written to
//                an existing file or will create a new file.
//
// Arguments:
//      fname   - Text filename for FITS file to be written
//      data    - Image data to be written to the file
//      x_size  - Number of rows in the image
//      y_size  - Number of cloumns in the image
//      newfile - Flag to create a file.  If true, create a new file (overwrite
//                any existing one.  If false, will write to the data block in
//                an existing file.
//      pname   - Text string for program name in PROGRAM key value
//      version - Test string with version information for PROGRAM key value
//
// Return Value:
//      true    - Write was successful
//      false   - Write failed
//
// Errors:  Function will set astro_errno with return code (see astro_class.h)
//

bool   astro::fits_write(std::string fname, float *fdata, int x_size, 
                         int y_size, bool newfile, const std::string pname,
                         const std::string version)
    {
    int         status=0;
    int         checkx;
    int         checky;
    long        naxes[2];
    char        key[81];
    char        err_text[81];
    fitsfile    *fptr=nullptr;
    long        fpixel[2]= { 1, 1};

    naxes[0]=(long) x_size;
    naxes[1]=(long) y_size;

    if (x_size < 1 || y_size < 1 || x_size > MAX_DIM || y_size > MAX_DIM)
        {
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_write: Image Size Invalid\n";
        astro_errno = ASTRO_ERR_WRITE;
        return(false);
        }

    if (newfile)
        {
//
// Create a new FITS file
//

        if (fits_create_file(&fptr,fname.c_str(), &status)!=0)
            {
            fits_get_errstatus(status,err_text);
            if (astro_warn==true) std::cerr << "WARNING: astro::fits_write:fits_create_file() Error " << status << ": " << err_text << "\n";
            astro_errno = ASTRO_ERR_CREATE;
            return(false);
            }

//
// Create a new FITS image unit in the file
//

       if (fits_create_img(fptr, FLOAT_IMG, 2, naxes, &status)!=0)
            {
            fits_get_errstatus(status,err_text);
            if (astro_warn==true) std::cerr << "WARNING: astro::fits_write:fits_create_img() Error " << status << ": " << err_text << "\n";
            astro_errno = ASTRO_ERR_IMAGE;
            return(false);
            }
        }
    else
        {
//
// Check the size of the primary image unit
//

        if (fits_dims(fname, &checkx, &checky)==false) return(false);

        if ((checkx != x_size) || (checky != y_size))
            {
            if (astro_warn==true) std::cerr << "WARNING: astro::fits_write: Exist File Size Error " << x_size << ":" << checkx << "-" << y_size << ":" << checky << "\n";
            astro_errno = ASTRO_ERR_SIZE;
            return(false);
            }

//
// Open the file for read/write
//

        if (DEBUG) std::cout << "DEBUG: astro::fits_read:fits_file_open\n";

        if (fits_open_file(&fptr, fname.c_str(), READWRITE, &status)!=0)
            {
            fits_get_errstatus(status,err_text);
            if (astro_warn==true) std::cerr << "WARNING: astro::fits_write:fits_open_file() Error " << status << ": " << err_text << "\n";
            astro_errno = ASTRO_ERR_OPEN;
            return(false);
            }
        }

//
// Write the image to the FITS files
//

    if (fits_write_pix(fptr, TFLOAT, fpixel, long(x_size*y_size), fdata, &status)!=0)
        {
        fits_get_errstatus(status,err_text);
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_write:fits_write_pix() Error " << status << ": " << err_text << "\n";
        astro_errno = ASTRO_ERR_WRITE;
        return(false);
        }

//<FIX>    sprintf(key,"HDU Created by %s/%s - %s", MAJOR_VERSION.str(), pname, version);
    if (fits_write_key(fptr, TSTRING, "PROGRAM", key, nullptr, &status)!=0)
        {
        fits_get_errstatus(status,err_text);
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_write:fits_write_key() Error " << status << ": " << err_text << "\n";
        astro_errno = ASTRO_ERR_KEY;
        return(false);
        }

    if (fits_close_file(fptr, &status)!=0)
        {
        fits_get_errstatus(status,err_text);
        if (astro_warn==true) std::cerr << "WARNING: astro::fits_write:fits_close_file() Error " << status << ": " << err_text << "\n";
        astro_errno = ASTRO_ERR_CLOSE;
        return(false);
        }

    return(true);
    }


//
// CarrayAlloc() - This function will dynamically allocate a 2D character
//                 array.  This is needed because we need to dynamically
//                 allocate an array for many FITS functions.  It has to be
//                 the exact size (required by many CFITSIO routines) and
//                 needs to be a monolithic block of data (which is why you
//                 can't use the traditional series of mallocs per row to
//                 create it).
//
//                 PLEASE NOTE:  This function uses the C/C++ sense of
//                 indices and not the FITS sense (which is opposite).
//
// Arguments:
//      crows    - Number of rows (X dimension, slowest changing index)
//      ccolumns - Number of columns (Y dimension, fastest changing index)
//
// Return Value:
//      char **  - Pointer to the base of the allocated 2D array
//
// Errors:  Function will set astro_errno with return code (see astro_class.h)
//

char     **astro::CArrayAlloc(int crows, int ccolumns)

    {
    int a;
    char **cptr;

//
// Double index arrays have a header containing pointer to each row
//

    int header = crows * sizeof(char*);
    int body = 0;

    if (DEBUG) std::cout << "DEBUG: astro::ArrayAlloc (C): crows=" << crows << ", ccolumns=" << ccolumns << ", header=" << header << "\n";

    for(a=0; a<crows; a++) body+=ccolumns;
    body*=sizeof(char);

    if (DEBUG) std::cout << "DEBUG: astro::ArrayAlloc (C): body=" << body << "\n";

//
// Allocate the total space needed
//

    if ((cptr = (char**)malloc(header + body))==nullptr)
        {
        if (astro_warn==true) std::cerr << "WARNING: astro::ArrayAlloc:malloc() error\n";
        astro_errno = ASTRO_ERR_MALLOC;
        return(nullptr);
        }

    if (DEBUG) std::cout << "DEBUG: astro::ArrayAlloc (C): cptr=" << cptr << "\n";

    char* buf  = (char*)(cptr + crows);

    if (DEBUG) std::cout << "DEBUG: astro::ArrayAlloc (C): buf=" << buf << "\n";

//
// Now populate all the row pointers with the correct values
//

    cptr[0] = buf;
    for(a = 1; a < crows; ++a)
        {
        cptr[a] = cptr[a-1] + ccolumns;
        if (DEBUG) std::cout << "DEBUG: astro::ArrayAlloc (C): cptr[" << a << "]=" << cptr[a] << "\n";
        }
    return(cptr);
    }


//
// ArrayAlloc() - This function will dynamically allocate a 2D float
//                array.  This is needed because we need to dynamically
//                allocate an array for many FITS functions.  It has to be
//                the exact size (required by many CFITSIO routines) and
//                needs to be a monolithic block of data (which is why you
//                can't use the traditional series of mallocs per row to
//                create it).
//
//                PLEASE NOTE:  This function uses the C/C++ sense of
//                indices and not the FITS sense (which is opposite).
//
// Arguments:
//      frows    - Number of rows (X dimension, slowest changing index)
//      fcolumns - Number of columns (Y dimension, fastest changing index)
//
// Return Value:
//      float ** - Pointer to the base of the allocated 2D array
//
// Errors:  Function will set astro_errno with return code (see astro_class.h)
//

float   **astro::ArrayAlloc(int frows, int fcolumns)

    {
    int     a;
    float   **fptr;

//
// Double index arrays have a header containing pointer to each row
//

    int header = frows * sizeof(float*);
    int body = 0;

    for(a=0; a<frows; a++) body+=fcolumns;
    body*=sizeof(float);

//
// Allocate the total space needed
//

    if ((fptr = (float**)malloc(header + body))==nullptr)
        {
        if (astro_warn==true) std::cerr << "WARNING: astro::ArrayAlloc:malloc() error\n";
        astro_errno = ASTRO_ERR_MALLOC;
        return(nullptr);
        }

    float* buf  = (float*)(fptr + frows);

//
// Now populate all the row pointers with the correct values
//

    fptr[0] = buf;
    for(a = 1; a < frows; ++a)
        {
        fptr[a] = fptr[a-1] + fcolumns;
        }
    return(fptr);
    }
