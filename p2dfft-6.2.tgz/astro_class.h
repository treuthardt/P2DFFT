//
// ASTRO_CLASS.H - This class provides functions for astronomical analysis,
//                 specifically the P2DFFT pitch angle analysis package.
//
//
// Version 2.2: 25-Nov-2024
//
//
// Authors:  Ian Hewitt & Dr. Patrick Treuthardt,
//           NC Museum of Natural Sciences,
//           Astronomy & Astrophysics Lab,
//           Raleigh, NC USA.
//           http://github.com/treuthardt/P2DFFT
//
//
// LICENSE
//
// P2DFFT Spiral Galaxy Arm Pitch Angle Analysis Suite
// Copyright (c) 2016-2024  Ian B. Hewitt & Dr. Patrick Treuthardt
//
// The program is free software:  you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation, version 3.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
// details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see < https://www.gnu.org/licenses >.
//
// The authors can be contacted at:
//
//      North Carolina Museum of Natural Sciences
//      Astronomy & Astrophysics Laboratory
//      11 West Jones Street
//      Raleigh, NC, 27601  USA
//      +1.919.707.9800
//
//      -- or --
//
//      patrick.treuthardt@naturalsciences.org
//
//
// Revision History:
//
//      2.2  25-Nov-2024: - Remove using directive
//                        - Remove file_type() and file_exists() functions
//                        - Add support for specifying inner radius
//      2.1  17-Dec-2020: - Correct/update header comments
//                        - Add remove_path_extension() declaration
//                        - Change char* declarations to string
//                        - Remove unused ASTR_ERR_DIMSIZE and
//                          ASTRO_ERR_HOMEDIR error codes
//                        - Change errors to use enumerated types
//                        - Change return values from integer to boolean
//      2.0  26-May-2018: - Add fits_write() function
//                        - Add new error codes
//                        - Add return constants
//                        - Remove placeholders for fits_text_read/write
//                        - Add error code for invalud buffer size
//      1.2  16-Mar-2018: - Add set_warn() function
//                        - Add version constant
//      1.1  03-Feb-2018: - Update comments
//                        - Add version print function
//                        - Add get_err function
//                        - Remove astro_print declarations
//                        - Remove external astro_errno declarations (now it
//                          is a private variable)
//      1.0  17-Feb-2017: - Initial version
//

#include      <cstddef>
#include      <iostream>
#include      <string>
#include      <vector>

#include      <fitsio.h>

//using namespace std;

const std::string  ASTRO_H_VER="2.2/20241125";

//
// astro_class file type return values
//

enum  astro_file_t
          {
          ASTRO_TXT_FILE,    // ASCII/UTF-8 Text FITS File
          ASTRO_BIN_FILE,    // Binary FITS File
          ASTRO_UNK_FILE     // Other Type of File
          };

//
// astro_class error number definitions
//

enum  astro_error_t
          {
          ASTRO_ERR_KEY,        // Failed to Write FITS Header Keyword
          ASTRO_ERR_NONE,       // No Error
          ASTRO_ERR_OPEN,       // Failed to Open File
          ASTRO_ERR_SIZE,       // Invalid FITS Image Size
          ASTRO_ERR_CLOSE,      // Failed to Close FITS File
          ASTRO_ERR_WRITE,      // Failed to Write to FITS File
          ASTRO_ERR_IMAGE,      // Failed to Create FITS Image Structure
          ASTRO_ERR_CREATE,     // Failed to Create FITS Image File
          ASTRO_ERR_MALLOC,     // Failed to Alllocate Memory
          ASTRO_ERR_RD_REC,     // Failed to Read FTIS Keyword Record
          ASTRO_ERR_HDR_POS,    // Failed to Get FITS Header Block
          ASTRO_ERR_READPIX,    // Failed to Read FITS Pixel Values
          ASTRO_ERR_GET_SIZE    // Failed to Read FITS Dimension Values
          };

//
// Data structure used for the file parameters
//

struct  file_rec
    {
    bool          valid;      /* Flag to indicate if data is valid         */
    std::string   name;       /* File name                                 */
    std::string   result;     /* Prefix for overall output files           */
    int           inner;      /* Inner radius starting value               */
    int           radius;     /* Outer radius value                        */
    };

//
// Class definition values
//

class   astro
            {
            public:
                void          set_warn(bool value);
                astro_error_t get_err();
                void          version();
                std::string   remove_path_extension(std::string filename, 
                                    bool pathr, bool extr);
                bool          read_lines(std::string fname,
                                    std::vector<file_rec> *rec);
                bool          fits_dims(std::string fname, int *rows,
                                    int *cols);
                char          **fits_header_read(std::string fname, int *keys);
                bool          fits_header_write(std::string fname,
                                    std::string keys[], std::string items[],
                                    int num);
                float         *fits_read(std::string fname, int *size);
                bool          fits_write(std::string fname, float *fdata,
                                    int x_size, int y_size, bool newfile,
                                    const std::string pname, 
                                    const std::string version);
                char          **CArrayAlloc(int crows, int ccols);
                float         **ArrayAlloc(int frows, int fcols);
            };
