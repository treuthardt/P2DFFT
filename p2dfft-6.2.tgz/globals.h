//
// GLOBALS.H - This file provides the global constants for the P2DFFT package.
//
//
// Version 1.5: 25-Nov-2024
//
//
// Authors:  Ian Hewitt & Dr. Patrick Treuthardt,
//           NC Museum of Natural Sciences,
//           Astronomy & Astrophysics Lab,
//           Raleigh, NC USA.
//           http://github.com/treuthardt/P2DFFT
//
//
// LICENSE
//
// P2DFFT Spiral Galaxy Arm Pitch Angle Analysis Suite
// Copyright (c) 2016-2024  Ian B. Hewitt & Dr. Patrick Treuthardt
//
// The program is free software:  you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation, version 3.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
// details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see < https://www.gnu.org/licenses >.
//
// The authors can be contacted at:
//
//      North Carolina Museum of Natural Sciences
//      Astronomy & Astrophysics Laboratory
//      11 West Jones Street
//      Raleigh, NC, 27601  USA
//      +1.919.707.9800
//
//      -- or --
//
//      patrick.treuthardt@naturalsciences.org
//
//
// Revision History:
//
//      1.5  25-Nov-2024: - Remove using directive
//      1.4  10-Nov-2024: - Change from macros to const variables for constants
//                        - Update descriptions of constants and guidance
//                          on changing them
//                        - Change from macros to constexprs for compile time
//                          options
//                        - Eliminate redundant constants
//                        - Add header guard
//      1.3  15-Sep-2021: - Update version for P2DFFT V6
//                        - Move fft_out structure here and remove amplitude
//                          and frequency components
//      1.2  16-Jun-2020: - Add variable for the maximum file name length
//      1.1  01-Jun-2018: - Add window limits
//                        - Add maximum and minimum FITS image sizes
//                        - Add overall version string
//                        - Add FREQ constants
//                        - Remove MAX_THREADS (made code too complex)
//                        - Add MAX_FILES
//      1.0  05-Feb-2018: - Initial version
//

//
// Header guard
//

#ifndef GLOBALS_H
#define GLOBALS_H

//
// Overall Version String for the P2DFFT Package
//

const   std::string MAJOR_VERSION = "P2DFFT/V6";

//
// Constants
//

constexpr   bool    DEBUG = false;       // Set to true to get debugging ouptut

//
//  MAX_DIM sets the size of memory allocated for the data matrices, so
//   in effect is the maximum size of any dimension of the image file.
//   Increasing this will require some other code changes.
//

const   int MAX_DIM = 2048;

//
//  MAX_FILES set the number of file arguments that can be specified.
//    for some of the programs. This can be increased or decreased
//    without any other code changes.
//

const   int MAX_FILES = 1024;

//
//  MAX_THREADS sets the largest number of threads that will be used. 
//    This is the upper limit, so if the system has less threads
//    available, that number will be used. This can saefly be increased
//    or decreased without any other code changes being needed.
//

const   int MAX_THREADS = 128;

//
//  DIM_RAD and DIM_THT are the number of radial slices and number of angular
//    slices used in the algorithm to map the Cartesian values to polar. Any
//    changed to these values will require a lot of changes in the fft code.
//

const   int DIM_THT = 1024;
const   int DIM_RAD = 2048;

//
//  The starting and ending number of modes (spiral arms) to calculate. These
//    should be changeable without too much impact.
//

const   int M_INI = 0;
const   int M_FIN = 6;

//
//  The starting and ending FFT frequency values. Any changes would require some
//    downstream code changes.
//

const   int FREQ_START = -50.0;
const   int FREQ_END = 50.0;

//
//  Permitted range of values for p2dfft fixed annulus size. Should be
//    changeable without any downstream code changes.
//

const   int MIN_WINDOW = 5;
const   int MAX_WINDOW = 125;

//
//  Math constants. Should not change these unless you are modeling a different
//    universe.
//

const   double  STEP_P = 0.25;
const   double  PI = 3.1415926;
const   double  GR_RAD = (PI/180.0);

//
//  Maximum arguments and argument length. These can be changed with no
//    other code changes.
//

const   int MAX_ARGS = 64;
const   int MAX_FILENAME = 256;

//
// File structure for filtered FFT data
//

struct  alignas (double) fft_out
    {
    double      real;      /* Real component of FFT output              */
    double      imag;      /* Imaginary component of FFT output         */
    };

#endif