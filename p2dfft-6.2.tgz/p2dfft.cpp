//
// P2DFFT.CPP - This program will calculate the 2D FFT for determining pitch
//              angles.
//
//  Version 6.9: 25-Nov-2024
//
//           The program was derived from the original 2DFFT program by the
//           NC Museum of Natural Sciences Astronomy & Astrophysics lab.  It
//           calculates the pitch angles of spiral galaxy arms using the
//           log-polar mapped Fourier transform over a series of annuli.  The
//           annuli have an increasing inner starting radius with a fixed outer
//           radius (by default).  It runs the calculations for each annulus
//           in parallel, which makes for much faster execution on
//           multi-threaded machines.  In addition, there have been some
//           changes to the input to the programs to increase usability.
//           Finally, the program has changed the FFT algorithm to the
//           Harvard "Fastest Fourier Transform in the West" (FFTW3) library.
//
//  2DFFT (Original) Author: Dr. Ivanio Puerari
//                Instituto Nacional de Astrofisca, Optica y Electronica
//                Santa Maria Tonantzintla, Puebla, Mexico
//
//  2DFFT (Revised) Lead Author: Dr. Marc Seigar
//                University of Minnesota, Duluth
//                Duluth, MN USA
//
//  2DFFT (Progenitor of P2DFFT) Lead Author: Dr. Benjamin Davis
//                Swinburne University of Technology,
//                Centre for Astrophysics and Supercomputing,
//                Melbourne, Victoria, Australia
//                http://www.d.umn.edu/~msseigar/2DFFT/2DFFT.tar.gz
//
//  P2DFFT By: Ian Hewitt & Dr. Patrick Treuthardt
//                NC Museum of Natural Sciences
//                Astronomy & Astrophysics Lab,
//                Raleigh, NC USA
//                https://github.com/treuthardt/P2DFFT
//
//  LICENSE
//
//  P2DFFT Spiral Galaxy Arm Pitch Angle Analysis Suite
//  Copyright (c) 2016-2024  Ian B. Hewitt & Dr. Patrick Treuthardt
//
//  The program is free software:  you can redistribute it and/or modify it
//  under the terms of the GNU General Public License as published by the Free
//  Software Foundation, version 3.
//
//  This program is distributed in the hope that it will be useful, but WITHOUT
//  ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or
//  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
//  more details.
//
//  You should have received a copy of the GNU General Public License along with
//  this program.  If not, see < https://www.gnu.org/licenses >.
//
//  The authors can be contacted at:
//
//      North Carolina Museum of Natural Sciences
//      Astronomy & Astrophysics Laboratory
//      11 West Jones Street
//      Raleigh, NC, 27601  USA
//      +1.919.707.9800
//
//      -- or --
//
//      patrick.treuthardt@naturalsciences.org
//
//
//  Usage: p2dfft [-i|--input <file>] [-v|--verbose] [-w|--warn]  [-r|--reverse]
//                [-f|--fixed <size>] [-p|--polar] [-t|--threads <num>]
//                [-a|--all] [-s|--start <num>] [-e|--end <num>]
//                [-d|--data] [<FITS files>]
//
//         p2dfft will process a list of files.  These files can come from
//         standard input, the command line, or an input file.  The files can
//         be binary FITS files or ASCII text FITS files. By default, no
//         radius or output file prefix needs to be provided as these will
//         determined by the program.
//
//         There are several options:
//              -i|--input  : Will read file names, results file, starting
//                            radius, and ending radius from the parameter
//                            file specified
//              -v|--verbose: Prints status messages during the
//                            processing
//              -w|--warn:    Causes warnings to be printed when individual
//                            values are not rational or minor processing
//                            problems are discovered.
//              -r|--reverse: By default the pitch angle is calculated using
//                            different annuli with increasing inner radius,
//                            this option performs the calculations with
//                            annuli with decreasing outer radius.
//              -f|--fixed  : Use annuli with a fixed radius (specified by
//                            the argument to fixed.  The inner radius of
//                            the annuli will start from 1 and increase but
//                            the end will always be the start value plus the
//                            argument to fixed.
//              -p|--polar  : Generate a FITS file with the logarithmic polar
//                            mapping used by P2DFFT.
//              -s|--start  : Specifies an starting radius instead of the 
//                            default of 1
//              -e|--end    : Specifies an ending radius instead of the 
//                            default of the radius to the image edge
//              -a|--all    : Calculate the signal-to-noise ratio and the
//                            full width half maximum of the FFT data peak
//              -t|--threads: Specifies the largest number of threads to use
//                            when processing. The default is to use the
//                            maximum available.
//              -d|--data   : Write a binary file the base name and the suffix
//                            of .fft containing the FFT output matrix
//
//
//  Input formats:
//
//         Command Line Arguments - The file names of the binary (or web) FITS
//         files are specified on the command line.  The result file for
//         each file will be all characters of the file name before the first
//         occurrence of a "."  The radius will start at one and go to the
//         maximum radius based on the size of the image unless the -s and/or
//         the -e options are specified.
//
//         Parameter File - The format of the parameter file is:
//
//           image_file_1,inner_radius_1,outer_radius_1,result_file_1
//           image_file_2,inner_radius_2,outer_radius_2,result_file_2
//           image_file_3,inner_radius_3,outer_radius_3,result_file_3
//           image_file_etc,inner_radius_etc,outer_radius_etc,result_file_etc
//
//        The inner radius, outer radius, and result file name radius are 
//        optional (e.g. you can just have a line like "image_file_1"
//        or "image_file_1,inner_radius_1".  If they are not specified, the
//        program will calculate them. Blank lines are allowed in the file,
//        but are no longer needed and will be ignored. You can also have
//        lines that are just commments by starting the line with a '#'.
//
//        Taking filenames from standard input is no longer supported as of
//        P@DFFT v6.
//
//  Version History:
//
//      6.9  25-Nov-2024 - Remove using directives
//                       - Fix multi-threaded code for parallel operation
//                       - Update comments/descriptions
//                       - Add ability to specify inner radius
//                       - Add ability to specify number of threads to use
//                       - Remove variable length arrays
//                       - Remove use of std::endl for better performance
//                       - Remove unused variables
//                       - Remove high pass (-h) and mask (-m) options
//                       - Change snr fwhm flag to be -a|--all instead of -s
//                       - Add support for specifying inner starting radius
//                       - Fully convert to C++ strings instead of char ptrs
//                       - Fixed bug where old command line options where still
//                         included in getopt
//                       - Fixed bug where required argument values were marked
//                         as optional
//                       - Remove quiet option and make no output unless 
//                         verbose flag is set
//                       - Remove file checking and rely on error handling
//                         in cfitsio
//                       - Support not only binary fits, but web files and all
//                         other formats supported by cfitsio
//      6.8  10-Nov-2024 - Remove special compilation includes which are no
//                         needed after to switching to a CMAKE build system
//                       - Removed parallel multi-threading code since there is
//                         a problem on some systems. The change will be done
//                         in version 6.2 of p2dfft.cpp
//                       - Remove unused variables
//                       - Change macros to constexprs
//      6.7  21-Sep-2023 - Change default background value to be 0.1
//      6.6  03-Sep-2022 - Remove deprecated code and spell check comments
//                       - Fix memory leak where running large (> 10,000)
//                         numbers of files would consume > 20 GB of memory
//      6.5  23-Nov-2021 - Correct bug in fixed annuli code that caused code
//                         crashes by not calculating the annuli bounds
//                         correctly
//      6.4  18-Oct-2021 - Add -q option for use in batch scripts
//                       - Remove the code to process ASCII FITS and the
//                         compatability to take 2dfft scripts via stdin
//                       - Improve code by explicitly checking for return
//                         values instead of relying on implicit value
//                       - Rewrite the code to wrote all the intermediate data
//                         and the raw data (if the -d option is selected) to
//                         an HDF5 data file.  Also change the intermediate
//                         data to only store the FFT output data and no longer
//                         store the amplitude and frequency.
//                       - Change the first column of the per mode radius/PA
//                         files to remove outi_ prefix and just make it
//                         equal to the radius
//                       - Change the parameter file so the radius file
//                         precedes the output file prefix
//                       - Fix bug in fixed width annuli code where no results
//                         could be produced for valid input
//                       - Fix bug where 0.0 values could show up as -0.0
//      6.3  17-Dec-2020 - Update error messages for enumerated types in
//                         pitch_class.h and astro_class.h
//                       - Change flags from integer to boolean
//                       - Updated to new style include syntax
//                       - Switch to C++ filesystem library
//                       - Switch to streams for all I/O
//                       - Change char* and functions to strings
//                       - Change deprecated functions to pointer safe ones
//                       - Remove macros
//                       - Make exit codes consistent
//                       - Update printed error messages
//                       - Fix bug in deprojecting rectangular images
//                       - Fix incorrect/outdated comments
//                       - Add additional debug code
//                       - Fix small bug in debug output code
//                       - Change to explicit null ptr values/checks
//                       - Change some ambiguous variable names
//                       - Change code to not exit for certain errors, but to
//                         just skip to the next file
//                       - Remove file/path processing and switch to astro_class
//                         function remove_path_extension() to correct path/file
//                         processing
//                       - Fix bug in parameter file parsing
//                       - Improve .rip/.dat file error handling
//                       - Fix bug in radius value output in .rip file
//      6.2  25-Jun-2020 - Remove code for summed FFT output files (since this
//                         is not used)
//                       - Fix bug in the fftw input matrix where the real
//                         component was sign reversed instead of the imaginary
//                         component.  This created an inverse image, but still
//                         returned accurate pitch angles.
//                       - Removed the experimental -z option since it did not
//                         improve the algorithm
//                       - Made some changes in type casting that prevented
//                         compilation on later Mac systems
//                       - Changed some deprecated functions to more modern
//                         versions
//      6.1  04-May-2020 - Add check for parameter (input) file to insure it is
//                         a text file
//                       - Change references for input file to parameter file
//                       - Fix implicit returns from astro class to specific
//                         astro_class.h return codes
//                       - Change mapping of input FITS files to match that
//                         used in 2DFFT.  This has a very small effect on
//                         pitch angles, but a significant one on phase angles
//                       - Fix incorrect version numbers in comments and code
//                       - Improve error message text and add some additional
//                         printed error messages
//                       - Small changes to correct for difference in negative
//                         transform used by FFTW and positive used in older
//                         numerical recipes FFT routine
//                       - Added -s option to make SNR and FWHM calculations
//                         optional
//                       - Fixed deprecated and missing command line options in
//                         the code and command help text
//                       - Added additional compile time debug option, DEBUG_MAP
//      6.0  19-Dec-2019 - Fix bug in fixed which caused no PA's to be found
//                       - Minor comment cleanup
//                       - Fix missing library call needed to build on Mac
//      5.9  20-Jun-2019 - Remove incorrect FFT row sense fix
//      5.8  02-Jun-2019 - Change 2D FFT row sense to correct bug left over
//                         from FFTW migrations and to improve accuracy
//                       - Remove deprecated leftover -s argument code
//      5.7  21-May-2019 - Fix incorrect original author attribution with
//                         apologies to those previously left out of the list
//      5.6  08-May-2019 - Eliminate the -s option so the program will always
//                         create the FFT data files
//                       - Add additional debugging to show .rip file mapping
//      5.5  18-Dec-2018 - Fix bug where save files are not created in the
//                         current working directory if fits file is not
//                         located in the current working directory
//                       - Fix bug where failure to write the the .dat or
//                         .rip files would cause a crash
//      5.4  20-Oct-2018 - Change the version printing to only happen when -v
//                         is specified
//                       - Add -m|--mask option to mask bright core values
//                       - Add -z|--zero option to add artificial FFT window
//                       - add -p|--polar option to generate polar FITS image
//                       - Change the mapping from the fits file to account
//                         for the FITS/C++ row ordering difference.
//                       - Change version printing to only occur with -v
//                       - Bug fix for failure when using non local arguments
//                       - Update comments and remove unused code blocks
//      5.3  19-Jun-2018 - Fix two bugs with sum output to address potential
//                         race conditions which caused indeterminate output
//                       - Fix bug in summation when multiple files specified
//                       - Fix bug in reverse mode where annuli changing in
//                         wrong direction
//      5.2  27-May-2018 - Add -r|--reverse and -f|--fixed options
//                       - Simplify center location logic
//                       - Remove unused variables
//                       - Fix bug that resulted in center being off by 1
//                         for certain sizes
//                       - Update comments/usage info
//                       - Remove unused variables
//                       - Move fftw plan creation so it's only done once
//                       - instead of for every file
//                       - Add summed FFT data files to output
//                       - Remove code to limit threads because it was too
//                         complex for marginal usefulness
//                       - Remove fftw3 multithreaded code and replace with
//                         OpenMP code for better utilization of threads
//                       - Replace fixed frequency values with FREQ constants
//      5.1  15-Mar-2018 - Add support for sn() and fwhm() functions and adding
//                         their results to the output
//                       - Clean up error handling for pitch_class to return
//                         less extraneous output
//                       - Add -w|--warning option to allow/suppress warning
//                         messages being printed
//                       - Fix small bug in getopt_long() call
//                       - Preface each printed message with aa class (warning,
//                         debug, or error)
//                       - Fix bug where an error would not cause an orderly
//                         exit
//                       - Print the total items and how many were successfully
//                         processed at the end of the program
//                       - Significant comment updates
//      5.0  05-Feb-2018 - Change name and comments from 2dfft to p2dfft
//                       - Significant changes to file I/O scheme.  Will no
//                         longer write/use temporary files (.rip & .data)
//                         if saverip is not enabled.
//                       - saverip data files are no longer created in the
//                         current working directory, but are created in the
//                         <result_file> subdirectory.
//                       - Remove external give_maximum_pitch_phase executable
//                         and replace it with a pitch_class function.  This
//                         eliminates the need for FORTRAN and a multitude
//                         of interim working files.
//                       - Remove the code to automatically remove working
//                         files in the current directory and change the code
//                         which creates the <result_file> output files
//                       - Add comments for variables and change some variable
//                         names to de-obfuscate the code :-)
//                       - Clean up version print code and add class versions
//                       - Move global constants to a separate include file
//                       - Remove requirement that images files are square
//                       - Add capability to override default number of threads
//                       - Change DEBUG to be a variable, not a comp. cond.
//                       - Add comments for array mapping information
//                       - Add error handling for output files, including
//                         deselecting saverip if data files can't be opened
//      4.0  28-Aug-2017 - Rewrite program to use FFTW3 libraries
//                       - Make some changes to mapping algorithm to improve
//                         performance
//                       - Eliminate creates of the gal.* file
//                       - Updated header comments
//                       - Add code for more detailed debugging output
//                       - Updated/fixed comments
//                       - Fixed bug in reading from input file where no files
//                         would be found, even in a valid input file
//                       - Minor changes to eliminate compiler warnings on
//                         some Linux distributions
//      3.4  27-Jul-2017 - Print limited status information even when -v is
//                         not specified
//      3.3  09-Jun-2017 - Correct an error in the mapping of ASCII fits files
//                       - Update comments
//                       - Fix some error messages
//                       - Remove deprecated -f/--force_read logic
//                       - Add code to print out version when run
//                       - Correct help printout error
//      3.2  07-Jun-2017 - Print version number to stdout
//      3.1  21-Feb-2017 - Remove unused variable opt_err
//      3.0  20-Feb-2017 - Significant rewrite to add the following changes:
//                          * Move setup blocks of code and rearrange for
//                            readability.
//                          * Move from C to C++ (to get classes)
//                          * Program always builds for for multiple threads
//                            (will still work on single threaded machine)
//                          * Make other compile time options into command line
//                            options (STATUS and SAVE_RIP)
//                          * Add astro class functions for working with
//                            FITS files (see astro_class.cpp)
//                          * Eliminate the need for scripter.  2dfft can
//                            now read the input files originally meant for
//                            scripter.  This is done with the -i option.
//                          * If the input file does not have the result
//                            file (used to be keyword) or radius, it will
//                            be calculated automatically.
//                          * 2dfft can now take image file names via the
//                            command line.
//                          * 2dfft now reads both ASCI FITS image and binary
//                            FITS images (of any sort).
//      2.5  03-Jan-2017 - Add check during reading of input file.  If the file
//                         has a FITS header, it will loop forever.  Now it
//                         will abort with an error message and move on to the
//                         next file.
//      2.4  30-Dec-2016 - Add check for EOF when looking for input file.  This
//                         prevents 2DFFT from getting in an infinite loop when
//                         the input file does not exist.
//      2.3  27-Nov-2016 - Change the program to now look for the
//                         give_maximum_pitch_phase program based on the
//                         BIN_DIR entry in the makefile.  The program will:
//                          * Look in the current directory and use that one
//                          * Look in the BIN_DIR and use that one
//                          * If not found, search some common locations
//                         The first executable version found will be used.
//      2.2  27-Sep-2016 - Some changes to address:
//                          * In parallel mode, add reading of the final output
//                            filename so we can make the *_m[0-6] files
//                            correctly (so it works with scripter.cpp v2.2)
//                          * Reduced loop to calculate one less iteration in
//                            parallel mode to give exact match for old results.
//                          * Fixed bug in non-parallel mode output by setting
//                            radius = r_min.  This allowed a number of
//                            conditional compile statements to be removed,
//                            which simplified the code.
//                          * Fix path name for give_maximum_pitch_phase which
//                            was hard-coded. Now it just relies on it being in
//                            the command path. <This change is deprecated>
//      2.1  26-Sep-2016 - Fixed two subtle race conditions in the parallel
//                         loop.  Also cleaned up STATUS messages to be
//                         cleaner and print less (for better performance)
//      2.0  12-Sep-2016 - Update for openMP parallel threads and to add
//                         compile time options (See Makefile and Readme.txt)
//

#include    <iostream>
#include    <fstream>
#include    <sstream>
#include    <iterator>
#include    <iomanip>
#include    <cmath>
#include    <cstdio>
#include    <cstdlib>
#include    <cstring>
#include    <cerrno>

#include    <filesystem>

#include    <sys/types.h>
#include    <sys/stat.h>

#include    <getopt.h>
#include    <omp.h>

//
// Include fftw3 headers
//

#include    <fftw3.h>

//
// GLOBAL CONSTANTS
//

#include    "globals.h"

//
// Include the Astro Functions class
//

#include    "astro_class.h"
#include    "pitch_class.h"

//
// Include HDF5 Libraries
//

#include    "H5Cpp.h"

//
// Version number definition
//

const   std::string VERSION="6.9/20241125";

//
// Set this flag to #define to get a data matrix debugging information.  This
//   is independent of the DEBUG flag in globals.h because it produces a lot
//   of output.  Highly recommend redirecting stdout to a file when using this
//   option.
//

constexpr   bool    DEBUG_DAT = false;

//
// Set this flag to #define to get a input matrix debugging information.  This
//   is independent of the DEBUG flag in globals.h because it produces a lot
//   of output.  Highly recommend redirecting stdout to a file when using this
//   option.
//

constexpr   bool    DEBUG_MAT = false;

//
// Set this flag to #define to get the cartesian 2D to polar mapping numbers
//

constexpr   bool    DEBUG_MAP = false;

//
// Set this flag to print out the various sizes and indexes. This is uesful
//   when getting segmentation faults on different machines because there
//   are several parts ot the code that use a rolling counter.
//

constexpr   bool    DEBUG_INDEX = false; 

//
//   GLOBAL (NON-THREAD) VARIABLES
//

int     c;                 /* Return value for command line options parser   */
int     i, j;              /* Index variables                                */
int     rend=0;            /* Ending radius value for annuli                 */
int     msize;             /* Binary FITS file data size                     */
int     fix_w=0;           /* Flag for fixed annuli for calculations         */
int     dindex;            /* Counter for debug statement counting           */
int     rstart = 1;        /* Starting radius value for the annuli           */
int     counter;           /* Index variable for the polar data array        */
int     threads = -1;      /* Number of threads to use for multiprocessing   */
int     x_0, y_0;          /* Cartesian coordinates for the image center     */
int     proc_error;        /* Input file error count                         */
int     x_dim, y_dim;      /* The cartesian dimensions of the input file     */

bool    raw=false;         /* Flag for writing raw FFT output data           */
bool    rev=false;         /* Flag to control if inner or outer radius varies*/
bool    warn=false;        /* Flag to indicate if warnings are printed       */
bool    polar=false;       /* Flag to control if polar proj image created    */
bool    verbose=false;     /* Flag for printing of status messages           */
bool    snr_fwhm=false;    /* Flag for calculating/printing SNR & FWHM data  */
bool    input_file=false;  /* Flag to indicate if input file is used         */

unsigned    int     it;    /* Files vector index variable                    */

float   **mat;             /* 2D cartesian image data                        */
float   *proj;             /* Polar mapped image data matrix                 */
float   *idata;            /* Input image data matrix                        */
float   log_rad;           /* The natural log of the current radius value    */
float   log_bar;           /* The natural log of the bar radius value        */
float   log_itrad;         /* The natural log of the maximum radius value    */
float   freq_counter;      /* Frequency counter value                        */

double  norma[MAX_DIM+1];  /* FFT normalization value for each radius        */

std::string  infile;       /* Input filename for -i                          */
std::string  keyword;      /* String for intermediate data file prefix       */
std::string  resultfile;   /* Summary file (*_m[0-6]) file name              */

const   float   radstep=2.0*PI/STEP_P/DIM_RAD;    /* ln-r mapping increment  */
const   float   theta_step=2.0*PI/GR_RAD/DIM_THT; /* Mapping theta increment */

astro   ast;               /* Instantiation of astro_class functions object  */
pitch   pit;               /* Instantiation of pitch_class functions object  */

hsize_t raw_dim[1] = { DIM_THT * DIM_RAD *2 }; /* Size of raw data space     */
hsize_t data_dim[2] = { 401, 2 }; /* Size of data space for one annuli       */

fftw_plan   plan;          /* FFTW execution plan                            */

std::vector  <file_rec>  items; /* Vector of input files                     */

struct  fft_out     fft_data[MAX_DIM][M_FIN+1][401];  /* FFT output array    */

struct  result_pa   mode_data[M_FIN+1][(MAX_DIM/2)+1];   /* FFT analysis data*/

//
// FUNCTIONS
//


//
// H5WRITE() - Write all the data to the HDF5 file. The output data is written
//             to a global data structure because the HDF5 library is not
//             thread-safe/reentrant so it has to be called once all the threads
//             have finished running. The HDF5 file saves the output that used
//             to be saved in the .rip and .dat files.
//
//
// Arguments:
//      name -    File name prefix
//      radius -  Outer radius of annuli
//
// Return Value:
//      None
//

void    h5_write(std::string name, int radius)
    {
    H5::H5File              out_file;      /* HDF5 output file              */
    double                  fp_fill=0.0;   /* Fill value for data sets      */
    H5::DSetCreatPropList   prop_list;     /* Property list for data sets   */

//
// Open data files and write the initial data
//

    try
        {
        std::string filename = name + ".h5";
        out_file = H5::H5File(filename, H5F_ACC_TRUNC);
        H5::DataSpace rad_space(H5S_SCALAR);
        H5::Attribute attr_rad = out_file.createAttribute("radius", H5::PredType::NATIVE_INT, rad_space);
        attr_rad.write(H5::PredType::NATIVE_INT, &radius);
        prop_list.setFillValue(H5::PredType::NATIVE_DOUBLE, &fp_fill);
        }
    catch (...)
        {
        std::cerr << "WARNING: Cannot Create Output File: " << items[it].result << ".h5 Skipping...\n";
        return;
        }

    for (int rad = 0; rad <= radius; rad++)
        {
        for (int m = 0; m <= 6; m++)
            {
            H5::DataSpace rip_space(2,data_dim);
            if (DEBUG_INDEX) std::cout << "Mode " << m << ", data_dim=" << data_dim[0] << ", " << data_dim[1] << "\n";
            std::string rip_set = "/rip_r";
            rip_set= rip_set + std::to_string(rad) + "_m" + std::to_string(m);
            H5::DataSet rip_block = out_file.createDataSet(rip_set,H5::PredType::NATIVE_DOUBLE, rip_space,prop_list);
            if (DEBUG_INDEX) std::cout << "Complete rip write for Mode " << m << "\n";
            rip_block.write(fft_data[rad][m], H5::PredType::NATIVE_DOUBLE);
            }
        }

//
// Write the normalization data set
//

    hsize_t sdim[1];
    sdim[0]=radius;
    H5::DataSpace norm_space(1,sdim);
    std::string norm_set = "/normalization";
    H5::DataSet norm_block = out_file.createDataSet(norm_set,H5::PredType::NATIVE_DOUBLE, norm_space,prop_list);
    norm_block.write(&norma[1], H5::PredType::NATIVE_DOUBLE);
    }


//
// FIND_BAR() - This routine is used with the mask option.  It will start by
//              in the center of the image and search for the LARGEST radius
//              which has a pixel value greater than the limit provided.  That
//              will be assumed to be the bar radius.
//
// Arguments:
//      rad -     Outer radius of image
//      x_org -   X coordinate of center point
//      y_org -   Y coordinate of center point
//      lim_val - Limit value for masking
//
// Return Value:
//      Radius of estimated bar
//

float   find_bar(int rad, int x_org, int y_org, float lim_val)
    {
    int     skip;          /* Loop variable set to 1 after low value found   */
    int     aa, bb;        /* Cartesian coordinates of ln(r)/theta in image  */
    int     cnt_rad;       /* Counter for theta steps in radians             */
    int     cnt_tht=1;     /* Counter for theta steps in degrees             */

    float   r;             /* Natural log of radius for a certain point      */
    float   lb;            /* Largest bar radius value                       */
    float   curr;          /* Pixel value at current radius (for slope)      */
    float   prev1;         /* Pixel value at current radius -1 (for slope)   */
    float   prev2;         /* Pixel value at current radius -1 (for slope)   */
    float   prev3;         /* Pixel value at current radius -1 (for slope)   */
    float   xx, yy;        /* Relative cartesian coordinates of ln(r)/theta  */
    float   log_edge;      /* Natural log of current value of radius         */
    float   tht_deg;       /* Current theta (polar angle) in degrees         */
    float   tht_rad;       /* Current theta (polar angle) in radians         */

    if (DEBUG) std::cout << "Rad=" << rad << ", X_org=" << x_org << ", Y_org=" << y_org << ", Lim_val=" << lim_val << "\n";

//
// log() functions are computationally expensive, so calculate the logs
//   outside of the loop.
//

    log_edge=log((double) rad);
    if (DEBUG) std::cout << "Log_edge=" << log_edge << "\n";
    lb=0.0;

//
// Step around theta angles (360 degrees in 0.35 steps)
//

    for(tht_deg=0.0;cnt_tht<=DIM_THT;tht_deg+=theta_step)
        {
        cnt_tht++;
        tht_rad=tht_deg*GR_RAD;
        cnt_rad=1;
        skip=0;
        curr=-65535.0;
        prev1=-65535.0;
        prev2=-65535.0;
        prev3=-65535.0;

//
// Step out along radius steps
//

        for(r=0.0;cnt_rad<=DIM_RAD;r+=radstep)
            {
            cnt_rad++;

            if (skip) continue;
            if (r > log_edge) continue;

            xx=expf(r)*cosf(tht_rad);
            yy=expf(r)*sinf(tht_rad);

            aa=(int)xx+x_org;
            bb=(int)yy+y_org;

//
// Set the slope values for calculation
//

            prev3=prev2;
            prev2=prev1;
            prev1=curr;
            curr=mat[aa][bb];


            if (DEBUG) std::cout << "R=" << r << ", Mat[" << aa << "][" << bb << "]=" << mat[aa][bb] << "\n";
            if (mat[aa][bb] >= lim_val)
                {
                if (r > lb) lb=r;
                }
            else
                {
                skip=1;
                }
            }
        }

    if (verbose==true) std::cout << "--- bar length: " << (int) expf(lb) << " (" << lb << ")\n";
    return(lb);
    }


//
// MAIN() CODE
//

int main(int argc, char **argv)
    {
//
// Parse the command line options, if any, and set the flags associated
//   with the options
//

    static struct option long_options[] =
        {
        {"all",      no_argument,    0, 'a'},
        {"data",     no_argument,    0, 'd'},
        {"polar",    no_argument,    0, 'p'},
        {"warning",  no_argument,    0, 'w'},
        {"verbose",  no_argument,    0, 'v'},
        {"reverse",  no_argument,    0, 'r'},
        /* These options require an argument. */
        {"end",      required_argument, 0, 'e'},
        {"fixed",    required_argument, 0, 'f'},
        {"input",    required_argument, 0, 'i'},
        {"start",    required_argument, 0, 's'},  
        {"threads",  required_argument, 0, 't'},
        {0, 0, 0, 0}
        };

    int option_index = 0;

    while ((c = getopt_long (argc, argv, "adpwvre:f:i:s:t:", long_options, &option_index)
) != -1)
        {
        switch (c)
            {
            case 'a':
                {
                snr_fwhm = true;
                break;
                }
            case 'p':
                {
                polar = true;
                break;
                }
            case 'd':
                {
                raw = true;
                break;
                }
            case 'v':
                {
                verbose = true;
                break;
                }
            case 'r':
                {
                rev = true;
                break;
                }
            case 's':
                {
                rstart = strtol(optarg, nullptr, 10);
                break;
                }
            case 'e':
                {
                rend = strtol(optarg, nullptr, 10);
                break;
                }
            case 'w':
                {
                warn = true;
                pit.set_warn(true);
                ast.set_warn(true);
                break;
                }
            case 'f':
                {
                fix_w=strtol(optarg, nullptr, 10);
                if ((fix_w > MAX_WINDOW) || (fix_w < MIN_WINDOW))
                    {
                    std::cerr << "ERROR: Window Size Must Be Between " << MIN_WINDOW << " and " << MAX_WINDOW << "...Exiting\n";
                    exit(EXIT_FAILURE);
                    }
                break;
                }
            case 't':
                {
                threads=strtol(optarg, nullptr, 10);
                if (threads < 1)
                    {
                    std::cerr << "ERROR: Threads Cannot Be Less Than One\n";
                    exit(EXIT_FAILURE);
                    }
                if (threads > omp_get_max_threads())
                    {
                    std::cerr << "ERROR: Threads Cannot Be Greater Than " << omp_get_max_threads() << "\n";
                    exit(EXIT_FAILURE);
                    }
                if (threads > MAX_THREADS)
                    {
                    std::cerr << "INTERNAL ERROR: Increase MAX_THREADS\n";
                    exit(EXIT_FAILURE);
                    }
                break;
                }
            case 'i':
                {
                input_file = true;
                infile=std::string(optarg);
                break;
                }
            default:
                {
                std::cerr << "Usage: p2dfft [-i|--input <file>] [-v|--verbose] [-w|--warning]  [-r|--reverse] [-f|--fixed <size>] [-p|--polar] [-s|--start <num>] [-e|--end <num>] [-a|--all] [-d|--data] [-t|--threads <num>] [<FITS files>]\n";
                exit(EXIT_FAILURE);
                break;
                }
            }
        }

//
// Output version numbers
//

    if (verbose==true)
        {
        std::cout << "p2dfft version: " << VERSION << "\n";
        ast.version();
        pit.version();
        }

//
// Check for conflicting arguments
//

    if (fix_w && (rev==true))
        {
        std::cerr << "ERROR: Cannot specify -r|-reverse and -f|--fixed...Exiting\n";
        exit(EXIT_FAILURE);
        }

//
// Allocate the Cartesian data array.  Also, zero out the first cell of mat
//   because FITS image indices start at 1.  Please Note:  ArrayAlloc()
//   allocates a C-style array, not a FFTW3 style array.
//

    if (verbose==true) std::cout << "Allocating Cartesian mat[] Array...\n";

    if ((mat=ast.ArrayAlloc(MAX_DIM, MAX_DIM))==nullptr)
        {
        std::cerr << "ERROR: Memory allocation failed while allocating for mat[]\n";
        exit(EXIT_FAILURE);
        }

    mat[0][0]=0.1; //Used to be 0.0

//
// Get number of threads for this machine.  By default this should return
//   a value = #cores * threads per core. If the threads option was specified,
//   use that value instead.
//

    if (threads < 1) threads=omp_get_max_threads();

    if (threads > MAX_THREADS)
        {
        std::cerr << "INTERNAL ERROR: Increase MAX_THREADS\n";
        exit(EXIT_FAILURE);
        }

    if (DEBUG_INDEX)
        {
        std::cout << "Thread Count=" << threads << "\n";
        std::cout << "rawdim[0/1]=" << raw_dim[0] << "\n";
        std::cout << "data_dim[0/2]=" << data_dim[0] << ", data_dim[1/2]=" << data_dim[1] << "\n";
        std::cout << "FFT in/out array size=" << DIM_RAD*DIM_THT << "\n";
        }

//
// Allocate the FFT arrays.  These need to be allocated with fftw_ functions
//   since they are not C-style 2D arrays and the fact they need to be aligned
//   on 16 byte boundaries if the target machine has SIMD support.
//
// Note we need to allocate one set per thread, since this program is managing
//   the threads and not the FFTW library.
//

    if (polar == true) proj = (float *) malloc((DIM_RAD*DIM_THT) * sizeof(float));

    fftw_complex    *in_data[MAX_THREADS];
    fftw_complex    *out_data[MAX_THREADS];

    for ( i=0; i < threads; i++ )
        {
        in_data[i] = (fftw_complex *) fftw_malloc((DIM_RAD*DIM_THT) * sizeof(fftw_complex));

    if(nullptr == in_data[i])
            {
            std::cerr << "ERROR: FFTW Memory allocation failed for in_data[" << i << "]\n";
            exit(EXIT_FAILURE);
            }

        out_data[i] = (fftw_complex *) fftw_malloc((DIM_RAD*DIM_THT) * sizeof(fftw_complex));
        if(nullptr == out_data[i])
            {
            std::cerr << "ERROR: FFTW Memory allocation failed for out_data[" << i << "]\n";
            exit(EXIT_FAILURE);
            }
        }

//
// Read the parameters for the analysis.  The parameters include:
//
//     * Filenames to be processed
//     * Keywords associated with those files (optional)
//     * Outer radius values (optional)
//     * Starting radius values (optional)
//
// Parameters can come from one of the following sources (in
//  priority order):
//
//     * Parameter file specified with -i
//     * Command line arguments
//

    if (input_file)
        {
        if (ast.read_lines(infile, &items)==false)
            {
            std::cerr << "ERROR: Can't Read Parameter File: " << infile << "\n";
            exit(EXIT_FAILURE);
            }
        if ((items.size()==0))
            {
            std::cerr << "ERROR: No Valid Filenames in Parameter File: " << infile << "\n";
            exit(EXIT_FAILURE);
            }
        }
    else
        {
//
// Check if there are command line arguments
//

        if (DEBUG) std::cout << "optind=" << optind << ", argc=" << argc << "\n";

        if (optind >= argc)
            {
//
// No command line arguments for files, so generate an error
//

            std::cerr << "ERROR: No Input File or File Argumements...Exiting\n";
            exit(EXIT_FAILURE);
            }

//
// Get the command line arguments and put them in vector of items
//

        for (i=optind; i < argc; i++)
            {
            if (DEBUG) std::cout << "argv[" << i << "]=" << argv[i] << "\n";

            file_rec    f;

            f.name=std::string(argv[i]);
            f.result=ast.remove_path_extension(f.name, true, true);
            f.inner = rstart;
            f.radius=rend;
            f.valid=false;
            items.push_back(f);
            }
        }

//
// Final check to make sure we have items. No reason to fail here, but......
//

    if (items.size() == 0)
        {
        std::cerr << "ERROR: No Valid Files to Process (Empty work list)\n";
        exit(EXIT_FAILURE);
        }
    else
        {
        if (verbose==true) std::cout << "Total files to Process:    " << (unsigned int)items.size() << "\n";
        }

    proc_error=0;

//
// Build the plan for the FFT transform
//

    if (verbose==true) std::cout << "Building plan for FFTW...\n";
    plan=fftw_plan_dft_2d( (int) DIM_THT, (int) DIM_RAD, in_data[0], out_data[0], FFTW_FORWARD, FFTW_MEASURE);
    if ( plan == nullptr )
        {
        std::cerr << "ERROR: FFTW Plan (" << i << ") Build Failed\n";
        exit(EXIT_FAILURE);
        }
    if (verbose==true) std::cout << "Done\n";

//
// Now we have the list of files.  Loop through all of them and process.
//

    for ( it = 0; it < items.size();  it++)
        {

//
// Zero out x_dim and y_dim.  This is important for the logic to
//   determine the radius
//

        x_dim=0;
        y_dim=0;

        if (verbose==true) std::cout << "Processing Entry - Name: " << items[it].name << "\n";
        if (DEBUG) std::cout << " Result: " << items[it].result << " Radius: " << items[it].radius << " Valid: " << items[it].valid << "\n";

//
// Read the data from the image and determine the radius, if needed.
//

        if ((idata=ast.fits_read(items[it].name, &msize))==nullptr)
            {

//
// Read Failure
//

            std::cerr << "WARNING: Can't Read Binary File: " << items[it].name << " Skipping...\n";
            proc_error++;
            delete[] idata;
            continue;
            }

//
// Get the radius
//

        if (ast.fits_dims(items[it].name.c_str(),&x_dim, &y_dim)==false)
            {

//
// Failure to get size from Header
//

            std::cerr << "ERROR: Can't Read Binary File Size: " << items[it].name << " Skipping...\n";
            proc_error++;
            delete[] idata;
            continue;
            }

        if (DEBUG_INDEX) std::cout << "x_dim=" << x_dim << ", y_dim=" << y_dim << "\n";

//
// Check starting and ending radius to see if they are valid and if not, set
//   them to the appropriate values. Images are no longer required to be square
//   so find the shortest dimension for the outer radius if needed..
//

        if (!items[it].valid)
            {
            if (items[it].inner < 1) items[it].inner = 1; 

            if (items[it].radius < 1)
                {
                if ( x_dim < y_dim )
                    {
                    items[it].radius=(x_dim-1)/2;
                    }
                else
                    {
                    items[it].radius=(y_dim-1)/2;
                    }
                }
            items[it].valid=true;
            }

        if (DEBUG_INDEX) std::cout << "radius(items)=" << items[it].radius << "\n";

//
// Copy the FITS data into the mat 2D Cartesian array
//

        if (DEBUG_INDEX) std::cout << "msize=" << msize << "\n";

        if (DEBUG_DAT)
            {
            for(i=0;i<msize; i++)
                {
                if (idata[i] != 0.0) std::cout << "DEBUG: data[" << i << "]=" << idata[i] << "\n";
                }
            }

//
// The data linear array contains the FITS data.  Translate it into a 2D
//   matrix so it can be polar mapped from the center outward.  Note that
//   FITS arrays are column major order, not row major order, so a swap is
//   done.  The image could be processed without swapping, but to maintain
//   synergy with previous versions of 2DFFT (that performed the swap), it
//   is also done here.
//

        for(i=1;i<=x_dim;i++)
            {
            for(j=1;j<=y_dim;j++)
                {
                mat[i][j]=idata[(i-1)*y_dim+j-1];
                }
            }
    
        delete[] idata;

        if (DEBUG_MAT)
            {
            for(i=1;i<=x_dim;i++)
                {
                for(j=1;j<=y_dim;j++)
                    {
                    std::cout << "DEBUG: mat[" << i << "][" << j << "]=" << mat[i][j] << "\n";
                    }
                }
            }

        if (verbose==true) std::cout << "Processing Entry - Name: " << items[it].name << " Result: " << items[it].result << " Radius: " << items[it].radius << " Valid: " << items[it].valid << "\n";

        if (verbose==true) std::cout << "--- transforming X x Y -> Theta x ln r" << "\n";

//
// Use (dim-1)/2 for each dimension.  This makes it work for both odd and even
//   sized images.
//

        x_0=((x_dim-1)/2)+1;
        y_0=((y_dim-1)/2)+1;
        log_bar=0.1;  //Used to be 0.0

//
// log() functions are computationally expensive, so calculate the log
//   outside of the loop.
//

        log_itrad=log((double)items[it].radius);

//
// Initialize the normalization array
//

        for (i=0; i <= MAX_DIM; i++) norma[i]=0.0;

//
// Determine the starting radius.  For most cases, this will be 1, but if
//   using a fixed window, it has to move out to half the window size.
//

        if (fix_w)
            {
            rstart = (fix_w/2)+1;
            if (rstart > fix_w + items[it].radius)
                {
                std::cout << "Error processing " << items[it].name << " Annulus Size" << fix_w << " End " << items[it].radius << " Skipping...\n";
                continue;
                }
            }
        else
            {
            if (rstart >= items[it].radius)
                {
                std::cout << "Error processing " << items[it].name << " End " << items[it].radius << " Skipping...\n";
                continue;
                }
            }

//
//  This is the parallel portion of the code.  All the inner radius values for
//    each annuli will be calculated in groups of parallel threads starting
//    here. Even if there is is only one thread, this code will still work.
//

#pragma omp parallel for num_threads(threads)

        for (int radius = rstart; radius < items[it].radius; radius++)
            {

//
// VERY IMPORTANT - current is unique to each thread, so it must be defined
//   inside this block of code.  Since these threads run in parallel, any
//   variable must be unique per thread.  We do this by making them arrays
//   and using the thread number as the index.  This is current and it will
//   appear often below, except for any variable defined here (which by virtue
//   of it's location will be unique per thread.
//

int     current=omp_get_thread_num(); /* Current index for arrays for thread */

//
// Other definitions that are unique instances per thread.
//

int     a, b;              /* Cartesian coordinates of ln(r)/theta in image  */
int    	mode;              /* Mode index value                               */
int     jm, im;            /* Local index variables                          */
int     cont_p;            /* Index for remapping output data in fft_data    */
int     counter=0;         /* FFT array index value                          */
int     count_theta=1;     /* Counter for theta steps in degrees             */
int     count_radians;     /* Counter for theta steps in radians             */

float   lnr;               /* Natural log of radius for a certain point      */
float   x, y;              /* Relative cartesian coordinates of ln(r)/theta  */
float   log_lo;            /* Natural log of the inside of the fixed annuli  */
float   log_hi;            /* Natural log of the outside of the fixed annuli */
float   log_rad;           /* Natural log of current value of radius         */
float   freq_save;         /* Current frequency calculation value            */
float   theta_degrees;     /* Current theta (polar angle) in degrees         */
float   theta_radians;     /* Current theta (polar angle) in radians         */

//
// Calculate the end value for ln(radius)
//

            if (rev==true)
                {
                log_rad=log((double)(items[it].radius-radius+1));
                }
            else
                {
                log_rad=log((double)radius);
                }

//
// If using a fixed annulus, need to drop before getting to the last radius
//

            if (fix_w && (radius >= items[it].radius-(fix_w/2))) continue;

//
// Calculate the values used for fixed width annuli, if needed
//

            if (fix_w)
                {
                log_lo=log((double)(radius-(fix_w/2)+1));
                log_hi=log((double)(radius+(fix_w/2)));
                }

//
// Zero out the arrays.  This is REALLY important to getting the correct
//   results.
//

            for (im=0; im < DIM_RAD*DIM_THT; im++)
                {
                in_data[current][im][0]=0.1; // Used to be 0.0
                in_data[current][im][1]=0.0;
                out_data[current][im][0]=0.0;
                out_data[current][im][1]=0.0;
                }

            if (DEBUG_INDEX) std::cout << "Clearing " << DIM_RAD*DIM_THT << " entries is in/out data\n";

//
// Step around theta angles (360 degrees in 0.35 degree steps)
//

            if (DEBUG_INDEX) std::cout << "Start counter at " << counter << "\n";

            for(theta_degrees=0.0;count_theta<=DIM_THT;theta_degrees+=theta_step)
                {
                count_theta++;

//
// Convert the degrees to radians
//

                theta_radians=theta_degrees*GR_RAD;
                count_radians=1;

                for(lnr=0.0;count_radians<=DIM_RAD;lnr+=radstep)
                    {
                    count_radians++;

//
// Here's the bit that controls what get mapped and what is set to zero.
//   These tests depend on the value of reverse and fixed.
//

                    if ((rev==true) && (lnr>log_rad || lnr>log_itrad))
                        {
                        in_data[current][counter][0]=0.1;
                        in_data[current][counter++][1]=0.0;
                        continue;
                        }

                    if (fix_w && (lnr>log_hi || lnr<log_lo))
                        {
                        in_data[current][counter][0]=0.1;
                        in_data[current][counter++][1]=0.0;
                        continue;
                        }

                    if ((rev==false) && !fix_w && (lnr>log_itrad || lnr<log_rad))
                        {
                        in_data[current][counter][0]=0.1;
                        in_data[current][counter++][1]=0.0;
                        continue;
                        }

                    x=expf(lnr)*cosf(theta_radians);
                    y=expf(lnr)*sinf(theta_radians);

                    a=(int)x+x_0;
                    b=(int)y+y_0;

                    if (DEBUG_MAP)
                        {
                        if (radius==1) std::cout << "Map " << a << ", " << b << ", to " << counter << "\n";
                        }
                    in_data[current][counter][0]=(double) mat[a][b];
                    norma[radius]+=in_data[current][counter][0];
                    in_data[current][counter++][1]=0.0;
                    }
                }

            if (DEBUG_INDEX) std::cout << "Out with counter=" << counter << "\n";

            if (verbose==true) std::cout << "--- calculating 2DFFT: " << radius << "/" <<  items[it].radius << "\n";

            if (DEBUG_DAT)
                {
                if (radius<2)
                    {
                    std::cout << "RADIUS: " << radius << "\n";
                    for(im=0;im<=counter;im++)
                        {
                        if (in_data[current][im][0] != 0.0) std::cout << "In[" << im << "][0]" << in_data[current][im][0] << "\n";
                        }
                    }
                }

//
// Save the polar mapped image if the -p option was specified
//

            if ((polar == true) && (radius==1))
                {
                counter=0;
                for (jm=0; jm < DIM_RAD; jm++)
                    {
                    for (im=0; im < DIM_THT; im++)
                        {
                        proj[counter++]=(float) in_data[current][(im*2048)+jm+1][0];
                        }
                    }

                if (verbose==true) std::cout << "  --- Write P_" << items[it].name << " File" << items[it].name << "\n";

                const std::string pfile = "!P_" + items[it].name;

                if (ast.fits_write(pfile, proj, DIM_THT, DIM_RAD, 1, "p2dfft/",VERSION)==false)
                    {
                    std::cerr << "WARNING: fits_write(" << pfile << ") Failed (" << ast.get_err() << ")\n";
                    }
                }

//
// Perform the FFT using the plan
//

            fftw_execute_dft(plan,in_data[current],out_data[current]);

//
// Normalize the output data
//

            if (DEBUG_INDEX) std::cout << "Normalize with counter=" << counter << "\n";

            for(im=0;im<counter;im++)
                {
                if (DEBUG_DAT)
                    {
                    if (out_data[current][im][0] != 0.0) std::cout << "DEBUG: Out Data[" << im << "][0]=" << out_data[current][im][0] << "\n";
                    if (out_data[current][im][1] != 0.0) std::cout << "DEBUG: Out Data[" << im << "][1]=" << out_data[current][im][1] << "\n";
                    }
                out_data[current][im][0]=out_data[current][im][0]/(double)norma[radius];
                out_data[current][im][1]=out_data[current][im][1]/(double)norma[radius];
                }

//
// Write the raw FFT output data
//

            if ((raw==true)&&(radius==1))
                {
                try
                    {
                    if (verbose==true) std::cout << "Write Raw FFT Data File\n";
                    }
                catch (...)
                    {
                    std::cerr << "WARNING: Could Not Write To:" << items[it].result << ".h5\n";
                    }
                }

//
// Loop to get the data for each mode
//

            for(mode=M_INI;mode<=M_FIN;mode++)
                {
                counter=mode*DIM_RAD;

                if (DEBUG_INDEX) std::cout << "Counter for Mode=" << mode << " is " << counter << "\n";

//
// Extract the FFT output components for -50 to +50 Hz and populate them in
//   the fft_data structure.  P2DFFT uses a different order than FFTW uses
//   for it's output.   The mapping is:
//
//      out_data    Description                      fft_data Index  HDF5 Index
//      --------    ---------------------            --------------  ----------
//        0,0       Real DC/0 Hz Component                200           400
//        0,1       Imaginary DC/0 Hz Component           200           401
//        1,0       Real 0.25 Hz (Min) Component          201           402
//        1,1       Imaginary 0.25 Hz (Min) Component     201           403
//       200,0      Real 50 Hz Component                  400           800
//       200,1      Imaginary 50 Hz Component             400           801
//       201,0      Real 50.25 Hz Component               N/S           N/S
//       201,1      Imaginary 50.25 Hz Component          N/S           N/S
//      1024,0      Real 256 Hz Component (Max)           N/S           N/S
//      1024,1      Imaginary 256 Hz Component (Max)      N/S           N/S
//      1025,0      Real -256 Hz Component (Max)          N/S           N/S
//      1025,1      Imaginary -256 Hz Component (Max)     N/S           N/S
//      1847,0      Real -50.25 Hz Component              N/S           N/S
//      1847,1      Imaginary -50.25 Hz Component         N/S           N/S
//      1848,0      Real -50 Hz Component                   0             0
//      1848,1      Imaginary -50 Hz Component              0             1
//      2047,0      Real -0.25 Hz Component (Min)         199           398
//      2047,1      Imaginary -0.25 Hz Component (Min)    199           399
//
//   This mapping is also for m0 only, other modes would have the same fft_data
//   and rip values, but the data indices would have mode*2048 added to them.
//
//   Finally, this table also assumes a frequency mapping of -50 to +50, if
//   thats different, then the start and end will be different.
//
//   Also note that we multiply the imaginary component by -1.0 because FFTW3
//   returns a sign reversed value compared to the previous algorithm.
//

                for(cont_p= 0 ;cont_p < 200; cont_p++)
                    {
                    fft_data[radius][mode][cont_p+201].real=
                        out_data[current][counter+cont_p+1][0];
                    if (out_data[current][counter+cont_p+1][1] != 0.0)
                        {
                        fft_data[radius][mode][cont_p+201].imag=
                        -1.0*out_data[current][counter+cont_p+1][1];
                        }
                    else
                        {
                        fft_data[radius][mode][cont_p+201].imag= out_data[current][counter+cont_p+1][1];
                        }

                    fft_data[radius][mode][cont_p].real=
                        out_data[current][counter+cont_p+1848][0];
                    if (out_data[current][counter+cont_p+1848][1] != 0.0)
                        {
                        fft_data[radius][mode][cont_p].imag=
                        -1.0*out_data[current][counter+cont_p+1848][1];
                        }
                    else
                        {
                        fft_data[radius][mode][cont_p].imag=
                        out_data[current][counter+cont_p+1848][1];
                        }
                    }

//
//
// Since there are 401 entries, add the zero frequency data here
//

                fft_data[radius][mode][200].real=
                    out_data[current][counter][0];
                fft_data[radius][mode][200].imag=
                    -1.0*out_data[current][counter][1];

//
// The pitch_phase routine should have populated the mode_data structure with
//   all the data for this radius.  However, if the FFT returned NaN's, this
//   must be handled before calling additional analysis functions.   NOTE:
//   NaN's do not necessarily represent an error (can happen if the image is
//   small in the frame or signal is low), but it does prevent any further
//   meaningful analysis.
//

                if (!(pit.pitch_phase(fft_data[radius][mode], mode, &mode_data[mode][radius])))
                    {
                    if (warn==true) std::cerr << "WARNING: pitch_phase() failed (" << pit.get_err() << ") for radius " << radius << " and mode " << cont_p << "\n";
                    mode_data[mode][radius].index=0;
                    mode_data[mode][radius].freq=NAN;
                    mode_data[mode][radius].amp=NAN;
                    mode_data[mode][radius].avg_amp=NAN;
                    mode_data[mode][radius].pa=NAN;
                    mode_data[mode][radius].phase=NAN;
                    mode_data[mode][radius].snr=NAN;
                    mode_data[mode][radius].fwhm=NAN;
                    }
                else
                    {
                    if (snr_fwhm)
                        {
                        if (!(pit.snr(fft_data[radius][mode], &mode_data[mode][radius])))
                            {
                            if (warn==true) std::cerr << "WARNING: snr() failed (" << pit.get_err() << ") for radius " << radius << " and mode " << cont_p << "\n";
                            mode_data[mode][radius].avg_amp=NAN;
                            mode_data[mode][radius].snr=NAN;
                            mode_data[mode][radius].fwhm=NAN;
                            }
                        else
                            {
                            if (!(pit.fwhm(fft_data[radius][mode], &mode_data[mode][radius])))
                                {
                                if (warn==true) std::cerr << "WARNING: fwhm() failed (" << pit.get_err() << ") for radius " << radius << " and mode " << cont_p << "\n";
                                mode_data[mode][radius].fwhm=NAN;
                                }
                            }
                        }
                    }
                if (DEBUG) std::cout << "DEBUG: Pitch Phase Angle=" << mode_data[mode][radius].pa << ", SNR=" << mode_data[mode][radius].snr << ", FWHM=" << mode_data[mode][radius].fwhm << "\n";
                }
            }

//
// **** END OF PARALLEL THREAD LOOP
//

//
// Create the output data file (what used to be the .rip and .dat files)
//

        h5_write(items[it].result, items[it].radius);

//
// Now that all radii are complete, write the per mode and summed output files
//

        for (i = M_INI; i <= M_FIN; i++)
            {
            std::ostringstream outfile;
            outfile << items[it].result << "_m" << i;
            std::ofstream mode_out (outfile.str(), std::ios::out | std::ios::trunc);

            if (!mode_out)
                {
                std::cerr << "ERROR: Could Not Write " << outfile.str() << " Skipping...\n";
                continue;
                }

            for (j = items[it].inner; j <= items[it].radius; j++)
                {
                if (snr_fwhm)
                    {
                    mode_out << std::setw(6) << i << std::setw(11) << j << std::setw(8) << std::setprecision(2) << std::fixed << mode_data[i][j].freq << std::setw(12) << std::setprecision(3) << mode_data[i][j].amp << std::setw(9) << std::setprecision(2) << std::fixed << mode_data[i][j].pa << std::setw(11) << std::setprecision(3) << mode_data[i][j].phase << std::setw(11) << std::setprecision(3) << mode_data[i][j].snr << std::setw(11) << std::setprecision(3) << mode_data[i][j].fwhm << "\n";
                    }
                else
                    {
                    mode_out << std::setw(6) << i << std::setw(11) << j << std::setw(8) << std::setprecision(2) << std::fixed << mode_data[i][j].freq << std::setw(12) << std::setprecision(3) << mode_data[i][j].amp << std::setw(9) << std::setprecision(2) << std::fixed << mode_data[i][j].pa << std::setw(11) << std::setprecision(3) << mode_data[i][j].phase << "\n";
                    }
                }
            mode_out.close();
            }
        }
    if (verbose==true)
        {
        std::cout << "-------------------------------\n";
        it=(unsigned int)items.size()-(unsigned int)proc_error;
        std::cout << "Successfuly Processed        " << it << "\n";
        std::cout << "Errors                       " << proc_error << "\n";
        std::cout << "-------------------------------\n";
        }
    }
