//
// P2SPIRAL.CPP - Generate Spiral Galaxy Models for Testing
//
//            This program will generate FITS files of model galaxies.  The
//            files can be either binary floating point images of ASCII FITS
//            files.  Multiple features of the image can be specified through
//            the options (see below).
//
//
// Version 5.8: 26-Nov-2024
//
//
// Authors:  Ian Hewitt & Dr. Patrick Treuthardt,
//           NC Museum of Natural Sciences,
//           Astronomy & Astrophysics Lab,
//           Raleigh, NC USA.
//           http://github.com/treuthardt/P2DFFT
//
//
// LICENSE
//
// P2DFFT Spiral Galaxy Arm Pitch Angle Analysis Suite
// Copyright (c) 2016-2024  Ian B. Hewitt & Dr. Patrick Treuthardt
//
// The program is free software:  you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by the Free
// Software Foundation, version 3.
//
// This program is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
// details.
//
// You should have received a copy of the GNU General Public License along with
// this program.  If not, see < https://www.gnu.org/licenses >.
//
// The authors can be contacted at:
//
//     North Carolina Museum of Natural Sciences
//     Astronomy & Astrophysics Laboratory
//     11 West Jones Street
//     Raleigh, NC, 27601  USA
//     +1.919.707.9800
//
//     -- or --
//
//     patrick.treuthardt@naturalsciences.org
//
//
// Implementation: A quick note on how the code is implemented.  Near the top
//                 of the code, there are are the defaults which can easily
//                 be changed.  These defaults are all done with specific
//                 constants that are then used to populate the various data
//                 structures.
//
//                 The code to read the input file will change between various
//                 states.  This allows the input file format to be very
//                 flexible.  The states are:
//                      READING DEFAULT VALUES - Keywords will set default
//                      values from this point onwards.
//                      CREATING FILES - New keyword pairs will define model
//                      files to be created.
//                      FILE MODE - Keyword pairs will set parameters for one
//                      specific file.
//                 The transitions for the states are:
//                      DEFAULTS: Keyword (no argument) will change to the
//                      READING DEFAULT VALUES state.
//                      MODELS: Keyword (no argument) will change to the
//                      CREATING FILES state.
//                      name= keyword (with a value) will change to the FILE
//                      MODE.   Another occurrence of of the name= keyword will
//                      finish the current file entry and reenter FILE MODE
//                      with everything set to the current defaults.
//                 This would be better in a state diagram, but it's hard to
//                 do it with text only.
//
//
// References:
//
//           "Measurement of Galactic Logarithmic Spiral Arm Pitch Angle Using
//            Two-Dimensional Fast Fourier Transform Decomposition."
//
//           Davis, Benjamin L., Berrier, Joel C., Shields, Douglas W.,
//           Kennefick, Julia, Kennefick, Daniel, Seigar, Marc S., Lacy,
//           Claud H.S., & Puerari, Ivanio, 2012, ApJS, 199, 33
//
//           - or -
//
//           http://arxiv.org/abs/1202.4870
//
//
// Usage: p2spiral [-v|--verbose] [-p|--print] [-d|--default] [-e|--extend]
//                 [-s|--sg] <file>
//
//        If p2spiral is called with no argument, the user will be
//        prompted for all the parameters (see below). Entering <ctrl>-D will
//        stop the input and start the generation of the files.  For each entry
//        a 32-bit floating point FITS file will be created. Alternatively, a
//        file can be specified which list the parameters for the models to be
//        created (see below for data file description).
//
//        The complete list of command line options is:
//
//              -s|--sg : Arm width will be based on arm length only (will
//                        ignore any feather directives).
//              -v|--verbose : Causes status messages to be printed.
//              -p|--print : Print a listing of pitch angle by radius to stdout
//              -e|--extend : Add extra keywords with details for each model
//                            (this is used for testing purposes)
//              -d|--default : Print a listing of program defaults to stdout
//
//
// INPUT FILE FORMAT:
//
//   The input file describes the models to be created.  It consists of two
//   section types.  The DEFAULTS: section type defines default values for all
//   subsequent models.  These parameters will be used for all the files in
//   the MODELS: section, unless a different value is specified for a particular
//   model.  The MODELS: section contains a description for each model.  Please
//   note that it is not necessary to include all the possible parameters in
//   either the DEFAULTS: or MODELS: section of the input file.  Any parameters
//   not specified will be assigned the defaults defined in p2spiral (the ones
//   shown when the -d option is used).  This makes the order of precedence:
//
//           1. Parameter for a particular model in the MODELS: section
//           2. Parameter specified in the DEFAULTS: section
//           3. Value specified in the program constants
//
//   The general format of the file is:
//
//           DEFAULTS:
//           keyword=value,keyword=value,keyword=value
//           keyword=value
//           MODELS:
//           name=value,keyword=value,keyword=value
//           keyword=value
//
//   The keyword/value pairs can be put on separate lines and/or separated by
//   commas (they can be mixed).  A new model entries always starts with the
//   'name' keyword and all subsequent key/value pairs will apply to that model,
//   until the next name keyword starts a new model.
//
//   You can have multiple DEFAULTS: and MODELS: sections.  Every time a
//   DEFAULTS: section is used, the changes will be in effect for all
//   following models (unless another DEFAULTS: section changes them).
//   Using a second DEFAULTS: section does not change any of the settings
//   defined in a previous DEFAULTS: section (i.e. using a new DEFAULTS:
//   does not cause everything else to go back to the default values).
//
//   Blank lines will be ignored and lines beginning with a # symbol are
//   treated as comments and also ignored.
//
//   The keywords are:
//
//      name -      The prefix of the file name to be generated (not including
//                  the .fits suffix, which will be added to this value)
//      pa -        Pitch angle of the arms.  Can be a positive or negative
//                  floating point number. Using this keyword will alway make
//                  the first arm have this pa value.  All subsequent arms will
//                  also have this pa value unless one of the other pitch angle
//                  keywords is used.
//      pa2 -       Pitch angle for the second arm only
//      pa3 -       Pitch angle for the third arm only
//      pa4 -       Pitch angle for the fourth arm only
//      arms -      The integer number of spiral arms
//      hsize -     The integer width of the output image
//      vsize -     The integer height of the output image
//      feather -   Integer value in pixels that will be added to each side of
//                  the arm (arm will be 2 times the width plus 1).  This will
//                  be the width value used for all arms unless other feather
//                  keywords are used.
//      feather2 -  Arm width for the second arm only
//      feather3 -  Arm width for the third arm only
//      feather4 -  ARm width for the fourth arm only
//      sweep -     Value which indicates how far in azimuthal polar
//                  coordinates to map the arms (in degrees), e.g. 720.0 is
//                  two complete circles.
//      gal_radius - All arms will extend to this radius value (as opposed to
//                   having a fixed sweep or length)
//      arm_len -   Arm length (in pixels) for the first arm and all other arms
//                  where there is no other arm_len directive. This should be
//                  used before any other arm-len keywords.
//      arm_len2 -  Arm length for the second arm only
//      arm_len3 -  Arm length for the third arm only
//      arm_len4 -  Arm length for the fourth arm only
//      rotate -    Rotation of the arm start in degrees.  By default (0.0),
//                  the first arm will start horizontal to the left of the
//                  center and the others starting evenly spaced around the
//                  core.  Positive values move the start of the arms in a
//                  clockwise direction.
//      radius -    Initial integer radius of the core/start of arms.  This
//                  value does not include any bar feature radius.
//      core -      How to treat the circular core:
//                      0: none of the core is filled with any values
//                      1: fills core the starting value of arms
//                      2: fills in the central core with values twice the
//                         starting arm pixel value.  .
//      major_bar - Semi-major axis of bar (0=no bar), must be an integer.
//      minor_bar - Semi-minor axis of bar (integer). Ignored if major_bar=0.
//      margin -    Outside margin in pixels.  Value must be an integer.
//                  Nothing will be mapped beyond this, no matter what
//                  other settings are used.
//      fg -        Foreground value for first arm and any other arm without
//                  a fg directive
//      fg2 -       Foreground value for the second arm only
//      fg3 -       Foreground value for the third arm only
//      fg4 -       Foreground value for the fourth arm only
//      bg -        Background value in the image.  This is equivalent to the
//                  bias, and any noise will be added to this value.
//      delta -     Change in pitch angle (negative or positive) in degrees of
//                  the arms over their length.  Currently, if the model has
//                  arms with differing pitch angles, this value will apply
//                  equally to all arms unless delta2, delta3, or delta4 is
//                  used.  NOTE:  For positive delta values, the pitch angle
//                  formula can become unstable in outer regions, so the
//                  increase may be under calculated.
//      delta2 -    Change in pitch angle (negative or positive) in degrees for
//                  the second arm.  Using this will not change the the number
//                  of arms created in any event.
//      delta3 -    Change in pitch angle (negative or positive) in degrees for
//                  the third arm.  Using this will not change the the number
//                  of arms created in any event.
//      delta4 -    Change in pitch angle (negative or positive) in degrees for
//                  the fourth arm.  Using this will not change the the number
//                  of arms created in any event.
//      lum -       Change in luminosity (negative or positive) of an arm over
//                  it's length.  This is a percentage value between -0.99
//                  and 0.99.  Currently, if the model has arms with differing
//                  pitch angles, this value will apply equally to all arms
//                  unless lum2, lum3, or lum4 is used.
//      lum2 -      Change in luminosity (negative or positive) of the second
//                  arm over it's length.  This is a percentage value between
//                  -0.99 and 0.99.  Using this will not change the number of
//                  arms created in any event.
//      lum3 -      Change in luminosity (negative or positive) of the third
//                  arm over it's length.  This is a percentage value between
//                  -0.99 and 0.99.  Using this will not change the number of
//                  arms created in any event.
//      lum4 -      Change in luminosity (negative or positive) of the fourth
//                  arm over it's length.  This is a percentage value between
//                  -0.99 and 0.99.  Using this will not change the number of
//                  arms created in any event.
//      log -       Whether arm luminosity change is logarithmic (1) or
//                  linear (0)
//      arm_lum -   Apply change in luminosity over the width of an arm as well
//                  as it's length. A value of 0 means constant width
//                  luminosity and 1 means decreasing luminosity.
//      bg_noise -  This is a floating point value of the amount of simulated
//                  Poisson (shot) noise in the image.  This value sets the
//                  largest possible value of the noise in any pixel and the
//                  actual noise values used in any given pixel will be
//                  random up to this amount. Please note that noise will not
//                  be added to the core or arms and those values should
//                  generally greater than the noise value.
//      reset -     Reset all values to the default values defined in the
//                  program
//
//      IMPORTANT NOTE:  Using directives like pa, feather, arm_len, delta, fg,
//                       and lum will cause all the arms to take on these
//                       values . The corresponding directives for the second
//                       through fourth arms for these features must come AFTER
//                       the use of pa, feather, arm_len, delta, fg, or lum
//                       directive.
//
//      A an example is:
//
//      DEFAULTS:
//      vsize=255
//      hsize=255
//      pa=-35.0
//
//      MODELS:
//      name=File_1,vsize=435,hsize=435
//      pa=10.0
//      name=File_2
//      radius=50,hsize=128
//
//      DEFAULTS:
//      pa=45.0
//      feather=5
//
//      MODELS:
//      name=File_3
//      fg=512
//      bg=128
//
//      This will generate three FITS files:  File_1.fits, File_2.fits, and
//      File_3.fits.
//
// Revision History:
//
//      5.8  26-Nov-2024: - Remove using directive
//                        - Converting remaing flags to booleans
//                        - Remove char code to convert to C++ strings
//                        - Add ability to generate a FITS image for each
//                          individual arm file in addition to the image with
//                          all arms
//                        - Replace char array with vector
//                        - Now handle spaces in input file
//                        - Small changes to FITS keyword code
//      5.7  10-Nov-2024: - Remove duplicate definition of MAX_FILES
//                          from globals.h
//                        - Change STR_SIZE to be constant set in 
//                          globals.h
//                        - Change from macros to constexprs
//      5.6  21-Sep-2023: - Change default background value to be 0.1
//                        - Add FITS keyword for max radius (MAX_R)
//      5.5  03-Sep-2022: - Fix comment spelling errors and remove
//                          deprecated code
//                        - Fix bug where specifying a bar would fill in the bar
//                          and ignore the core directive
//                        - Fix incorrectly formatted version string
//      5.4  04-Jun-2022: - Remove a loop and change the way arm length is
//                          calculated
//                        - Fix bug in pitch/luminosity change calculations
//                          which were under-calculated
//                        - Increase sweep limits and maximum files
//                        - Fix bug in limit code which caused arms to
//                          turn (instead of stop) at limits
//                        - Update comments and documentation
//                        - Add ability to change feathering, arm length, and
//                          foreground value for individual arms
//                        - Add the ability to reset to default values with
//                          one keyword
//                        - Add the ability to limit arms by galactic radius
//                        - Change behavior so using a directive that applies
//                          to arms 2-4 will not override the setting in the
//                          arms directive
//      5.3  13-Jun-2021: - Add new keywords: pa2, pa3, pa4, lum2, lum3, lum4,
//                          delta2, delta3, and delta4 for generating spirals
//                          with different PA arms
//                        - Correct prompting format error/logic for inputting
//                          semi-minor axis
//                        - Remove ASCII text file generation flag and code
//                        - Fix bug that caused an error in interactive mode
//                          because the file count was incorrect
//                        - Update placeholder comments to contain actual
//                          useful information
//                        - Fix bug in help string output
//                        - Update exit codes to use current standard
//                        - Correct errors in comments
//                        - Fix bug where linear or log change in luminosity was
//                          underestimated
//                        - Remove deprecated arm length code
//                        - Decrease sweep resolution for better performance
//                        - Add code to fill in between generated points (with
//                          feathering) to fill in any gaps in the arms in the
//                          outer portions
//                        - Remove ARM_LEN keyword for extended mode
//                        - Change pitch angle and luminosity change rate to
//                          be based on radius, not linear arm length
//      5.1  17-Dec-2020: - Add error checking for .txt output file writing
//                        - Fix small bug in radius calculations
//                        - Change char* & functions to stream I/O
//                        - Change file I/O and other I/O to streams
//                        - Change flags from integer to boolean
//                        - Remove Macros
//                        - Change to C++ include style
//                        - Fix bug in bar major axis max value
//                        - Fix incorrect error messages
//                        - Fix incorrect prompts for several input values that
//                          had incorrect text or showed incorrect values
//                        - Fix small bug in setting initial radius values
//                        - Fix formatting error in pitch angle output file
//                        - Remove unnecessary system call to remove the output
//                          file
//      5.0  25-Jun-2020: - Increase rotation limits from +90/-90 to +180/-180
//                          degrees
//                        - Fix errors in comments and remove deprecated
//                          comments
//                        - Major changes to input file format to be less
//                          confusing and to use defaults defined in the
//                          program if not specified in the input file
//                        - Move defaults and limits to a section at the top
//                          of the program to make it easier to find and change
//                        - Fix bug in version string
//                        - Fix incorrect help string with old options
//                        - Tweak default values
//                        - Fix bug where specifying only one file may not
//                          result in any output
//                        - Change matrix printing to use a separate debugging
//                          variable (DEBUG_MAT)
//                        - Add command line option to print default values
//                          built into the program
//                        - Change deprecated functions to more modern/type-
//                          safe ones
//      4.3  21-Nov-2019: - Fix bug where bar was sometimes incompletely
//                          drawn (was clipped on some edges)
//      4.2  13-Jul-2019: - Fix bug where bar/core rotation direction was
//                          reversed
//                        - Fix bug where certain rotation values caused arms
//                          to not start at the ends of the bars
//                        - Add BAR keyword to model files
//                        - Change input file specification to command line
//                          (-i no longer needed)
//      4.1  13-Dec-2018: - Fix bug in feathering code to make more consistent
//                          arm widths
//      4.0  10-Jun-2018: - Add parameter to add/specify a bar
//                        - Change to C++ (only minor changes needed, so
//                          keep revision numbering scheme)
//                        - Change FITS writing code to use astro_class
//                        - Change array declarations to match FITS standard
//                        - Update comments/usage information
//                        - Fix bug with non-comma delimiters not working
//                        - Swich array allocation to use the one in
//                          astro_class
//                        - Move MAX_FILES to globals.h
//                        - Allow different vertical and horizontal dimensions
//                        - Increase maximum dimensions
//      3.0  16-Mar-2018: - Correct bug in command line option structure
//                        - Add input field for type of brightness change,
//                          arm width brightness change, and one to control
//                          core brightness value.
//                        - Add simulated Poisson noise to images
//                        - Significantly update comments
//                        - Make arm sweep part of input files rather than
//                          command line option
//                        - Add support for comments and blank lines in input
//                          file to improve readability
//                        - Reorder parameters into logical order (group
//                          similar ones together)
//                        - Remove optional parameters, all parameters need
//                          to be specified for all images (this is clearer)
//                        - Add subroutines for input parameters to simplify
//                          the code
//                        - Increased most default values to allow more varied
//                          output files
//                        - Fix bug in command line option processing for -p
//                        - Fix bug in linear brightness change algorithm with
//                          increasing brightness
//                        - Fix bug in variable pitch angle calculation
//                        - Fix bug where specifying too many input files would
//                          cause unpredictable behavior instead of giving error
//      2.1  21-Jan-2018: - Add option to specify change in luminosity with
//                          radius
//                        - Add command line option for arm sweep
//      2.0  04-Jan-2018: - Add input option for rotation of spiral (-90 to 90
//                          degrees) for each file
//                        - Add input option to specify initial radius (r0) for
//                          each file
//                        - Add input option specify if the core area should be
//                          filled in with a value twice the value of the arm
//                          foreground pixel value
//                        - Add input option to specify feather value
//                        - Add input options to specify default foreground and
//                          background pixel values
//                        - Add input option to specify the change in pitch
//                          angle from beginning to end
//                        - Add input option to specify outer margin (i.e. the
//                          number of pixels at the edge where nothing is
//                          plotted)
//                        - Remove restriction on file size being odd
//                        - Change input scheme to include defaults and not
//                          fail, but re-ask if invalid value is given
//                        - Change theta value from a function of size to 360
//                          degrees
//                        - Make ASCII FITS file generation optional by
//                          specifying a command line flag
//                        - Add option to list pitch angle by radius
//                        - Fix FITS generation code to use CFITSIO function
//                          built-in code to remove existing file
//                        - Update/correct comments
//      1.4  28-Aug-2017: - Fix bug in file close statement
//                        - Fix four small errors that led to compiler warnings
//                          on some Linux distributions (like Ubuntu)
//      1.3  18-Jan-2017: - Added the optional parameters to control values to
//                          adjust signal to noise ratio in the images
//                        - Changed delimiter in input file from tab to comma
//                        - Fixed error in comments/help test
//      1.2  13-Dec-2016: - Fixed bug where chirality was reversed
//      1.1  07-Dec-2016: - Increased maximum number of files from 64 to 256
//      1.0  06-Dec-2016:   Initial version
//
//

/*****************************************************************************/
//
// USER CONSTANTS - Can change these to alter the program limits.  These should
//   all be safe to change to your preferred values.
//
// LIMITS - These are the highest and lowest acceptable values accepted for
//   the keyword values.
//
/*****************************************************************************/

const float MIN_PA=     -75.0; /* Minimum pitch angle (floating point)       */
const float MAX_PA=      75.0; /* Maximum pitch angle (floating point)       */
const int   MIN_ARM=        1; /* Minimum number of spiral arms              */
const int   MAX_ARM=        6; /* Maximum number of spiral arms              */
const int   MIN_SIZE=      50; /* Minimum file size (should be at least 50)  */
const int   MAX_SIZE=    2048; /* Maximum files size ( < 2049 for P2DFFT)    */
const int   MIN_FEATH=      0; /* Minimum feather setting (integer)          */
const int   MAX_FEATH=     15; /* Maximum feather setting (integer)          */
const float MIN_SWEEP=    0.0; /* Minimum arm sweep (< 45 is not meaningful) */
const float MAX_SWEEP=  720.0; /* Maximum arm mapping angle                  */
const float MIN_GALRAD=   0.0; /* Minimum arm extent by galactic radius      */
const float MAX_GALRAD=1024.0; /* Maximum arm extent by galactic radius      */
const float MIN_LEN  =    0.0; /* Minimum arm arm length                     */
const float MAX_LEN=   1024.0; /* Maximum arm arm length                     */
const float MIN_ROT=   -180.0; /* Minimum rotation angle (floating point)    */
const float MAX_ROT=    180.0; /* Maximum rotation angle (floating point)    */
const float MIN_R0=       1.0; /* Minimum initial radius (floating point)    */
const float MAX_R0=    1000.0; /* Maximum initial radius (floating point)    */
const int   MIN_CORE=       0; /* Lowest core mapping value                  */
const int   MAX_CORE=       2; /* Highest core mapping value                 */
const float MIN_BARA=     0.0; /* Minimum bar semi-major axis                */
const float MAX_BARA=  1024.0; /* Maximum bar semi-major axis                */
const float MIN_BARB=     0.0; /* Minimum bar semi-minor axis                */
const float MAX_BARB=  1024.0; /* Maximum bar semi-minor axis                */
const int   MIN_MAR=        0; /* Minimum outer margin of blank space        */
const int   MAX_MAR=      200; /* Maximum outer margin of blank space        */
const float MIN_PIXEL=-1024.0; /* The minimum value for fg and bg variables  */
const float MAX_PIXEL= 1024000.0; /* Maximum value for fg and bg variables   */
const float MIN_DELTA=  -60.0; /* Minimum pitch angle change (floating point)*/
const float MAX_DELTA=   60.0; /* Maximum pitch angle change (floating point)*/
const float MIN_LUM=    -0.99; /* Minimum brightness change (floating point) */
const float MAX_LUM=     0.99; /* Maximum brightness change (floating point) */
const int   MIN_LOG=        0; /* Lowest brightness option                   */
const int   MAX_LOG=        1; /* Highest brightness option                  */
const int   MIN_ARM_LUM=    0; /* Lowest arm width luminosity change value   */
const int   MAX_ARM_LUM=    1; /* Highest arm width luminosity change value  */
const float MIN_NOISE= -512.0; /* The minimum value for fg and bg variables  */
const float MAX_NOISE=  512.0; /* The maximum value for fg and bg variables  */

//
// Default values for the models.  These are the numbers used if no other
//   value is specified in the input file.  These can all be changed as long
//   as the new value does not exceed the maximum number defined above or is
//   is not smaller than the minimum limit defined above. Please note that
//   some values are integers and some are floating point.
//

const float DEF_PA=      25.0; /* Default pitch angle (degrees)              */
const float DEF_PA2=      0.0; /* Default PA (degrees) for second arm        */
const float DEF_PA3=      0.0; /* Default PA (degrees) for third arm         */
const float DEF_PA4=      0.0; /* Default PA (degrees) for fourth arm        */
const int   DEF_ARMS=       2; /* Default number of arms                     */
const int   DEF_VSIZE=    255; /* Default vertical size of image             */
const int   DEF_HSIZE=    255; /* Default horizontal size of image           */
const int   DEF_FEATH=      1; /* Default feathering value                   */
const int   DEF_FEATH2=     0; /* Feathering value for second arm            */
const int   DEF_FEATH3=     0; /* Feathering value for third arm             */
const int   DEF_FEATH4=     0; /* Feathering value for fourth arm            */
const float DEF_SWEEP=  180.0; /* Arm mapping angle                          */
const float DEF_GALRAD=   0.0; /* Galactic radius for extent of arms         */
const float DEF_LEN=      0.0; /* Default arm length                         */
const float DEF_LEN2=     0.0; /* Second arm length                          */
const float DEF_LEN3=     0.0; /* Third arm length                           */
const float DEF_LEN4=     0.0; /* Fourth arm length                          */
const float DEF_ROT=      0.0; /* Rotation (degrees) value                   */
const float DEF_R0=      20.0; /* Initial core radius                        */
const int   DEF_CORE=       1; /* Flag for filling in the core               */
const float DEF_BARA=     0.0; /* Bar feature semi-major axis (in pixels)    */
const float DEF_BARB=     0.0; /* Bar feature semi-major axis (in pixels)    */
const float DEF_FG=     255.0; /* Foreground pixel value (General)           */
const float DEF_FG2=    255.0; /* Foreground pixel value (Second arm)        */
const float DEF_FG3=    255.0; /* Foreground pixel value (Third arm)         */
const float DEF_FG4=    255.0; /* Foreground pixel value (Fourth arm)        */
const float DEF_BG=       0.0; /* Background pixel value                     */
const int   DEF_MAR=       20; /* Outer margin value                         */
const float DEF_DELTA=    0.0; /* Pitch angle change value                   */
const float DEF_DELTA2=   0.0; /* Pitch angle change for the second arm      */
const float DEF_DELTA3=   0.0; /* Pitch angle change for the third arm       */
const float DEF_DELTA4=   0.0; /* Pitch angle change for the fourth arm      */
const float DEF_LUM=      0.0; /* Brightness change over radius              */
const float DEF_LUM2=     0.0; /* Brightness change over radius (second arm) */
const float DEF_LUM3=     0.0; /* Brightness change over radius (third arm)  */
const float DEF_LUM4=     0.0; /* Brightness change over radius (fourth arm) */
const int   DEF_LOG=        1; /* Brightness change algorithm                */
const int   DEF_ARM_LUM=    0; /* Flag for changing brightness over arm width*/
const float DEF_NOISE=    0.0; /* Maximum noise ceiling value                */

/*********************** END OF USER CONSTANTS *******************************/


//
// HEADER FILES
//

#include    <cmath>
#include    <cstdio>
#include    <cstdlib>
#include    <cstring>
#include    <iomanip>
#include    <iostream>
#include    <fstream>
#include    <sstream>
#include    <algorithm>
#include    <getopt.h>
#include    <sys/stat.h>
#include    <sys/types.h>

#include    "globals.h"
#include    "astro_class.h"

//
// SYSTEM CONSTANTS
//

const std::string VERSION="5.8/20241126";

//
// Change these to get debugging information. DEBUG_MAT will print the
//   matrices, which is a lot of output.
//

constexpr   bool    DEBUG_MAT = false;

//
// Keyword return values.  NOTE:  These need to match the table[][] entries!
//

constexpr   int K_BAD = -1;
constexpr   int K_LO = -2;
constexpr   int K_HI = -3;
constexpr   int K_NAME = 0;
constexpr   int K_PA = 1;
constexpr   int K_PA2 = 2;
constexpr   int K_PA3 = 3;
constexpr   int K_PA4 = 4;
constexpr   int K_ARMS = 5;
constexpr   int K_VSIZE = 6;
constexpr   int K_HSIZE = 7;
constexpr   int K_FEATH = 8;
constexpr   int K_FEATH2 = 9;
constexpr   int K_FEATH3 = 10;
constexpr   int K_FEATH4 = 11;
constexpr   int K_SWEEP = 12;
constexpr   int K_GALRAD = 13;
constexpr   int K_LEN = 14;
constexpr   int K_LEN2 = 15;
constexpr   int K_LEN3 = 16;
constexpr   int K_LEN4 = 17;
constexpr   int K_ROT = 18;
constexpr   int K_R0 = 19;
constexpr   int K_CORE = 20;
constexpr   int K_BARA = 21;
constexpr   int K_BARB = 22;
constexpr   int K_FG = 23;
constexpr   int K_FG2 = 24;
constexpr   int K_FG3 = 25;
constexpr   int K_FG4 = 26;
constexpr   int K_BG = 27;
constexpr   int K_MAR = 28;
constexpr   int K_DELTA = 29;
constexpr   int K_DELTA2 = 30;
constexpr   int K_DELTA3 = 31;
constexpr   int K_DELTA4 = 32;
constexpr   int K_LUM = 33;
constexpr   int K_LUM2 = 34;
constexpr   int K_LUM3 = 35;
constexpr   int K_LUM4 = 36;
constexpr   int K_LOG = 37;
constexpr   int K_ARM_LUM = 38;
constexpr   int K_NOISE = 39;
constexpr   int K_RESET = 40;

//
// State variables for reading the input file
//

constexpr   int NO_STATE = 101;
constexpr   int DEFAULT = 102;
constexpr   int CREATE = 103;
constexpr   int MODEL = 104;

//
// Value table variables
//

constexpr   int NONE = 201;
constexpr   int FP = 202;
constexpr   int I = 203;
constexpr   int B = 204;

//
// VARIABLES
//

int     c;                 /* Getopt_long return value                       */
int     r2;                /* Initial core radius squared                    */
int     i, j;              /* Index variables                                */
int     s, t;              /* Index variables                                */
int     x, y;              /* Array index variables                          */
int     ax, by;            /* Array index variables for gap filling          */
int     ind;               /* Current index for the input string             */
int     num;               /* Current index for the input lines              */
int     pts;               /* Number of points to fill in arm gap            */
int     mode;              /* Index used in the formula to process each arm  */
int     feath;             /* Working variable for feathering value          */
int     state;             /* Variable for current input state               */
int     outer;             /* Estimate of arm length                         */
int     longr[6];          /* Estimate of longest radius                     */
int     starti;            /* Starting radius for arms (integer)             */
int     result;            /* Result from lookup() function                  */
int     status;            /* Result from system() command                   */
int     last_x;            /* Previous x coordinate mapped                   */
int     last_y;            /* Previous y coordinate mapped                   */
int     centerx;           /* Center coordinate for x (horizontal) axis      */
int     centery;           /* Center coordinate for x (vertical) axis        */
int     counter;           /* Main processing loop variable                  */
int     opt_ind;           /* Index for command line arguments               */
int     num_keys;          /* Number of FITS keyword entries to be written   */
int     line_num;          /* Current line number of the input file          */
int     num_files;         /* Total number of files to process - 1           */

bool    sg=false;          /* Flag for length based feathering               */
bool    ext=false;         /* Flag for creating extra test FITS keywords     */
bool    list=false;        /* Flag for listing the pitch angles by radius    */
bool    verbose=false;     /* Flag for verbose mode                          */
bool    arm_files=false;   /* Flag for generating individual arm files       */

char    *pos;              /* Pointer to remove newlines from input string   */
char    *buf;              /* Pointer for strsep()                           */
char    *item;             /* Token parsed from input line                   */
char    *value;            /* String for value of keyword in config file     */
char    *keyword;          /* String for keyword in configuration file       */
char    key[256];          /* String for FITS keywords                       */
char    **ptr=&buf;        /* Pointer for strsep()                           */
char    keys[10][32];      /* FITS header key names                          */
char    items[10][80];     /* FITS header key values                         */
char    cmd[MAX_FILENAME+7]; /* String for command to remove old versions    */
//char    line[2048][256];   /* String for reading input file lines            */
char    entry[MAX_FILENAME]; /* Input file name string                       */

float   r;                 /* R value for the polar coordinates              */
float   rn;                /* calculated noise value                         */
float   brt;               /* Current pixel value for foreground             */
float   dist;              /* Cartesian distance from center                 */
float   mb,ma;             /* Bar (ellipse) mapping coordinates              */
float   max_r;
float   si,co;             /* Sine and cosine of ellipse mapping coordinates */
float   theta;             /* Loop variable for theta angles                 */
float   pitch;             /* Loop variable for changing pitch angle         */
float   **mat;             /* Pointer for the Cartesian mapping of image     */
float   mod[6];            /* Modifier for the chirality (direction)         */
float   mod2[6];           /* Modifier for the rotation (direction)          */
float   change[6];         /* Rate of change for varying pitch angles        */
float   startf;            /* Starting radius for arms (float)               */
float   slopex;            /* Horizontal slope for point connecting line     */
float   slopey;            /* Vertical slope for point connecting line       */
float   cur_rad;           /* Current working radius value                   */
float   cur_len;           /* Current working arm length value               */
float   sweeper;           /* Theta value used in arm mapping                */
float   newpitch;          /* Updated pitch value                            */
float   avg_pitch;         /* Average pitch value                            */
float   max_pitch;         /* Maximum pitch value                            */
float   min_pitch;         /* Minimum pitch value                            */
float   num_pitch;         /* Number of pitch values used                    */
float   separation;        /* Angular separation arms (polar coordinates)    */
float   arm_len[6];        /* Length or arms                                 */
float   lum_rate[6];       /* Luminosity change per radius step              */
float   **mat_files[7];    /* Pointer for mapping of individual arms         */

long    naxis=2;           /* CFITSIO number of axes - always 2              */
long    naxes[2];          /* Size of array give to CFITSIO                  */

astro   ast;               /* Instantiation of astro_class                   */

//
// Structure for Models - This is where the default values for the
//   parameters are defined.
//

struct model
    {
    std::string     name;       /* Name of output file.  No default        */
    float           pa[6];      /* Pitch angle (degrees)                   */
    int             arms;       /* Number of arms                          */
    int             vsize;      /* Vertical (Y) size of image              */
    int             hsize;      /* Horizontal (X) size of image            */
    int             feath[6];   /* Feathering/fuzziness value              */
    float           sweep;      /* Pitch angle range for mapping           */
    float           galrad;     /* Galactic radius to map arms             */
    float           len[6];     /* Arm mapping length                      */
    float           rot;        /* Rotation (degrees) of arm start pos     */
    float           r0;         /* Initial radius for each arm             */
    int             core;       /* Flag for filling in the core area       */
    float           bara;       /* Bar feature semi-major axis (in pixels) */
    float           barb;       /* Bar feature semi-major axis (in pixels) */
    float           fg[6];      /* Foreground pixel value                  */
    float           bg;         /* Background pixel value                  */
    int             mar;        /* Outer margin value (pixels)             */
    float           delta[6];   /* Pitch angle change                      */
    float           lum[6];     /* Brightness change over radius           */
    int             log;        /* Brightness change algorithm flag        */
    int             arm_lum;    /* Changing brightness over arm width flag */
    float           noise;      /* Maximum noise ceiling value             */
    }               files[MAX_FILES];


//
// Variables for the default values
//

float   def_pa=DEF_PA;          /* Default pitch angle (degrees)             */
float   def_pa2=DEF_PA2;        /* Default PA (degrees) for second split arm */
float   def_pa3=DEF_PA3;        /* Default PA (degrees) for third split arm  */
float   def_pa4=DEF_PA4;        /* Default PA (degrees) for fourth split arm */
int     def_arms=DEF_ARMS;      /* Default number of arms                    */
int     def_vsize=DEF_VSIZE;    /* Default size of image                     */
int     def_hsize=DEF_HSIZE;    /* Default size of image                     */
int     def_feath=DEF_FEATH;    /* Feathering/fuzziness value for each file  */
int     def_feath2=DEF_FEATH2;  /* Feathering/fuzziness value for second arm */
int     def_feath3=DEF_FEATH3;  /* Feathering/fuzziness value for third arm  */
int     def_feath4=DEF_FEATH4;  /* Feathering/fuzziness value for fourth arm */
float   def_sweep=DEF_SWEEP;    /* Pitch angle range for mapping             */
float   def_galrad=DEF_GALRAD;  /* Galactic radius for mapping arms          */
float   def_len=DEF_LEN;        /* Arm length for mapping                    */
float   def_len2=DEF_LEN2;      /* Second arm mapping length                 */
float   def_len3=DEF_LEN3;      /* Third arm mapping length                  */
float   def_len4=DEF_LEN4;      /* Fourth arm mapping length                 */
float   def_rot=DEF_ROT;        /* Rotation (degrees) value for each file    */
float   def_r0=DEF_R0;          /* Initial radius at 0 degrees for each file */
int     def_core=DEF_CORE;      /* Flag for filling in the core area         */
float   def_bara=DEF_BARA;      /* Bar feature semi-major axis (in pixels)   */
float   def_barb=DEF_BARB;      /* Bar feature semi-major axis (in pixels)   */
float   def_fg=DEF_FG;          /* Foreground pixel value (General)          */
float   def_fg2=DEF_FG2;        /* Foreground pixel value (Second arm)       */
float   def_fg3=DEF_FG3;        /* Foreground pixel value (Third arm)        */
float   def_fg4=DEF_FG4;        /* Foreground pixel value (Fourth arm)       */
float   def_bg=DEF_BG;          /* Background pixel value                    */
int     def_mar=DEF_MAR;        /* Outer margin value                        */
float   def_delta=DEF_DELTA;    /* Pitch angle change value for each file    */
float   def_delta2=DEF_DELTA2;  /* Pitch angle change for the second arm     */
float   def_delta3=DEF_DELTA3;  /* Pitch angle change for the third arm      */
float   def_delta4=DEF_DELTA4;  /* Pitch angle change for the fourth arm     */
float   def_lum=DEF_LUM;        /* Brightness change over radius             */
float   def_lum2=DEF_LUM2;      /* Brightness change over radius for 2nd arm */
float   def_lum3=DEF_LUM3;      /* Brightness change over radius for 3rd arm */
float   def_lum4=DEF_LUM4;      /* Brightness change over radius for 4th arm */
int     def_log=DEF_LOG;        /* Brightness change algorithm flag          */
int     def_arm_lum=DEF_ARM_LUM;/* Change brightness over arm width          */
float   def_noise=DEF_NOISE;    /* Maximum noise ceiling value               */

//
// Table for keys and values
//

#define   NUM_KEYS  41

std::string table[]={"name","pa","pa2","pa3","pa4","arms","vsize",        // 7
               "hsize", "feather","feather2", "feather3", "feather4",     // 5
               "sweep", "gal_radius", "arm_len", "arm_len2", "arm_len3",  // 5
               "arm_len4", "rotate","radius", "core", "major_bar",        // 5
               "minor_bar", "fg", "fg2", "fg3", "fg4", "bg", "margin",    // 7
               "delta", "delta2","delta3", "delta4",                      // 4
               "lum", "lum2", "lum3", "lum4", "log",                      // 5
               "arm_lum", "bg_noise", "reset"};                           // 3

int   val_table[] ={NONE, FP, FP, FP, FP, I, I, I,                        // 8
                    I, I, I, I,                                           // 4
                    FP, FP, FP, FP, FP,                                   // 5
                    FP, FP, FP, I, FP,                                    // 5
                    FP, FP, FP, FP, FP, FP, I,                            // 7
                    FP, FP, FP, FP,                                       // 4
                    FP, FP, FP, FP, I,                                    // 5
                    I, FP, NONE };                                        // 3

int   lo_i[]   ={-1,-1, -1, -1, -1, MIN_ARM, MIN_SIZE, MIN_SIZE,          // 8
                 MIN_FEATH, MIN_FEATH, MIN_FEATH, MIN_FEATH,              // 4
                 -1, -1, -1, -1, -1,                                      // 5
                 -1, -1, -1, MIN_CORE, -1,                                // 5
                 -1, -1, -1, -1, -1, -1, MIN_MAR,                         // 7
                 -1, -1, -1, -1,                                          // 4
                 -1, -1, -1, -1, MIN_LOG,                                 // 5
                 MIN_ARM_LUM, -1, -1 };                                   // 3

int   hi_i[]   ={-1,-1, -1, -1, -1, MAX_ARM, MAX_SIZE, MAX_SIZE,          // 8
                 MAX_FEATH, MAX_FEATH, MAX_FEATH, MAX_FEATH,              // 4
                 -1, -1, -1, -1, -1,                                      // 5
                 -1, -1, -1, MAX_CORE, -1,                                // 5
                 -1, -1, -1, -1, -1, -1, MAX_MAR,                         // 7
                 -1, -1, -1, -1,                                          // 4
                 -1, -1, -1, -1, MAX_LOG,                                 // 5
                 MAX_ARM_LUM, -1, -1 };                                   // 3

float   lo_fp[]  ={-1.0, MIN_PA, MIN_PA, MIN_PA, MIN_PA, -1.0, -1.0, -1.0,// 8
                   -1.0, -1.0, -1.0, -1.0,                                // 4
                   MIN_SWEEP, MIN_GALRAD, MIN_LEN, MIN_LEN, MIN_LEN,      // 5
                   MIN_LEN, MIN_ROT, MIN_R0, -1.0, MIN_BARA,              // 5
                   MIN_BARB, MIN_PIXEL, MIN_PIXEL, MIN_PIXEL, MIN_PIXEL, MIN_PIXEL, -1.0,                                       // 7
                   MIN_DELTA, MIN_DELTA, MIN_DELTA, MIN_DELTA,            // 4
                   MIN_LUM, MIN_LUM, MIN_LUM, MIN_LUM,  -1.0,             // 5
                  -1.0, MIN_NOISE, -1.0 };                                // 3

float   hi_fp[]  ={-1.0, MAX_PA, MAX_PA, MAX_PA, MAX_PA, -1.0, -1.0, -1.0,// 8
                   -1.0, -1.0, -1.0, -1.0,                                // 4
                   MAX_SWEEP, MAX_GALRAD, MAX_LEN, MAX_LEN, MAX_LEN,      // 5
                   MAX_LEN, MAX_ROT, MAX_R0, -1.0, MAX_BARA,              // 5
                   MAX_BARB, MAX_PIXEL, MAX_PIXEL, MAX_PIXEL, MAX_PIXEL, MAX_PIXEL, -1.0,                                       // 7
                   MAX_DELTA, MAX_DELTA, MAX_DELTA, MAX_DELTA,            // 4
                   MAX_LUM, MAX_LUM, MAX_LUM, MAX_LUM, -1.0,              // 5
                  -1.0, MAX_NOISE, -1.0 };                                // 3


//
// SUBROUTINES
//


//
// COPY_DEFAULTS() - Copies the currently defined default values into the
//                   the file structure with the specified index
//
// Globals:
//      files   - Model file data structure
//
// Arguments:
//      num     - Index in the file structure to be written
//
// Return Value:
//      None
//

void copy_defaults(int num)
    {
    files[num].arms=def_arms;
    files[num].vsize=def_vsize;
    files[num].hsize=def_hsize;
    files[num].sweep=def_sweep;
    files[num].galrad=def_galrad;
    files[num].rot=def_rot;
    files[num].r0=def_r0;
    files[num].core=def_core;
    files[num].bara=def_bara;
    files[num].barb=def_barb;
    files[num].bg=def_bg;
    files[num].mar=def_mar;
    files[num].log=def_log;
    files[num].arm_lum=def_arm_lum;
    files[num].noise=def_noise;

    if (DEBUG)
        {
        std::cout << "DEBUG: (copy_defaults) Set pa[0] to Default pa of " << def_pa << "\n";
        }

    for ( int ix=0; ix < 6; ix++) files[num_files].pa[ix]=def_pa;
    if (def_pa2 != 0.0) files[num].pa[1]=def_pa2;
    if (def_pa3 != 0.0) files[num].pa[2]=def_pa3;
    if (def_pa4 != 0.0) files[num].pa[3]=def_pa4;

    for ( int ix=0; ix < 6; ix++) files[num_files].feath[ix]=def_feath;
    if (def_feath2 != 0.0) files[num].feath[1]=def_feath2;
    if (def_feath3 != 0.0) files[num].feath[2]=def_feath3;
    if (def_feath4 != 0.0) files[num].feath[3]=def_feath4;

    for ( int ix=0; ix < 6; ix++) files[num_files].fg[ix]=def_fg;
    if (def_fg2 != 0.0) files[num].fg[1]=def_fg2;
    if (def_fg3 != 0.0) files[num].fg[2]=def_fg3;
    if (def_fg4 != 0.0) files[num].fg[3]=def_fg4;

    for ( int ix=0; ix < 6; ix++) files[num_files].len[ix]=def_len;
    if (def_len2 != 0.0) files[num].len[1]=def_len2;
    if (def_len3 != 0.0) files[num].len[2]=def_len3;
    if (def_len4 != 0.0) files[num].len[3]=def_len4;

    for ( int ix=0; ix < 6; ix++) files[num_files].lum[ix]=def_lum;
    if (def_lum2 != 0.0) files[num].lum[1]=def_lum2;
    if (def_lum3 != 0.0) files[num].lum[2]=def_lum3;
    if (def_lum4 != 0.0) files[num].lum[3]=def_lum4;

    for ( int ix=0; ix < 6; ix++) files[num_files].delta[ix]=def_delta;
    if (def_delta2 != 0.0) files[num].delta[1]=def_delta2;
    if (def_delta3 != 0.0) files[num].delta[2]=def_delta3;
    if (def_delta4 != 0.0) files[num].delta[3]=def_delta4;
    }


//
// LOOKUP() - Takes a keyword and a value (both strings) and looks them up in
//            in table[][] and checks the value against the limits.
//
//            NOTE:  The K_ values must match the entries in table for this
//            function to work properly.
//
// Arguments:
//      keyword - Character string with base name of the file
//      value   - Character string with name of the field
//
// Return Value:
//      ret     - Integer value representing the keyword index or an error
//                condition
//

int lookup(std::string kw, std::string val)
    {
    int   res=K_BAD;

    if (DEBUG)
        {
        std::cout << "DEBUG: Keyword **" << kw << "**, Value=" << val << "\n";
        }

//
// Identify index value and type and store in the structure
//

    for (i=0; i < NUM_KEYS; i++)
        {
        if (kw == table[i])
            {
            res=i;
            break;
            }
        }

//
// Bail on error
//

    if ((res==K_BAD) || (res==K_NAME)) return(res);

//
// Now that the type of keyword is identified, process it
//

    if (val_table[res]==I)
        {
        c=std::stoi(val);
        if (c < lo_i[res])
            {
            res=K_LO;
            }
        else
            {
            if (c > hi_i[res])
                {
                res=K_HI;
                }
            }
        }
    else
        {
        c=std::stof(val);
        if (c < lo_fp[res])
            {
            res=K_LO;
            }
        else
            {
            if (c > hi_fp[res])
                {
                res=K_HI;
                }
            }
        }
    return(res);
    }


//
// GET_INPUT() - Runs a loop to get the input value for a parameter from stdin.
//               Will keep looping until a <ctrl-d>, <cr>, or valid entry is
//               received and will return the appropriate code.  All inputs
//               and outputs are floating point.
//
// Arguments:
//      prompt  - Character string with prompt for user.  Should have one %f
//                  field to show the default value.
//      min     - Minimum value for any valid input
//      max     - Minimum value for any valid input
//      def     - Default value assumed if only <cr> is read
//
// Return Value:
//      ret     - Value to be used from input.  If <ctrl-d> is received, it
//                will be -2048.0
//

float   get_input(const char *prompt, float min, float max, float def)

    {
    float   ret;

//
// Loop until we get a valid entry
//

    while (true)
        {
        std::cout << prompt << def << "]: ";

//
// If a <ctrl-d> set return to -2048.0
//

        std::string entry;

        if (!std::getline(std::cin, entry) && std::cin.eof())
            {
            std::cout << "\n";
            return(-2048.00);
            }

//
// If a <cr> set return to the default
//

        if (entry.empty())
            {
            ret=def;
            }
        else
            {
            ret=stof(entry);
            }

//
// Check the values against min/max
//

        if ((ret < (float) min) || (ret > (float) max))
            {
            std::cerr << "WARNING: Bad Value: " << entry << "\n";
            continue;
            }
        else
            {
            break;
            }
        }
    return(ret);
    }


//
// MAIN ROUTINE
//

int main(int argc, char **argv)
    {

//
// Get and process the command line arguments.
//

    static struct option long_options[] =
        {
        {"sg",      no_argument,         0, 's'},
        {"arms   ", no_argument,         0, 'a'},
        {"print",   no_argument,         0, 'p'},
        {"extend",  no_argument,         0, 'e'},
        {"verbose", no_argument,         0, 'v'},
        {"default", no_argument,         0, 'd'},
        /* These options require an argument. */
        {0, 0, 0, 0}
        };

    int option_index = 0;

    while ((c = getopt_long (argc, argv, "sapevd", long_options, &option_index))
!= -1)
        {
        switch (c)
            {
            case 'a':
                {
                arm_files = true;
                break;
                }
            case 's':
                {
                sg = true;
                break;
                }
            case 'v':
                {
                verbose = true;
                break;
                }
            case 'p':
                {
                list = true;
                break;
                }
            case 'e':
                {
                ext = true;
                break;
                }
            case 'd':
                {
                std::cout << "(" << VERSION << ") Default Values\n";
                std::cout << "_____________________________\n";
                std::cout << "Pitch Angles (Min: " << std::setprecision(1) << std::fixed << MIN_PA << ", Max: " << std::setprecision(1) << std::fixed << MAX_PA << ")=" << std::setprecision(2) << std::fixed << def_pa << "\n";
                std::cout << "Arms (Min: " << MIN_ARM << ", Max: " << MAX_ARM << ")=" << def_arms << "\n";
                std::cout << "Vertical Size (Min: " << MIN_SIZE << ", Max: " << MAX_SIZE << ")=" << def_vsize << "\n";
                std::cout << "Horizontal Size (Min: " << MIN_SIZE << ", Max: " << MAX_SIZE << ")=" << def_hsize << "\n";
                std::cout << "Feather (Min: " << MIN_FEATH << ", Max: " << MAX_FEATH << ")=" << def_feath << "\n";
                std::cout << "Sweep (Min: " << std::setprecision(1) << std::fixed << MIN_SWEEP << ", Max: " << std::setprecision(1) << std::fixed << MAX_SWEEP << ")=" << std::setprecision(1) << std::fixed << def_sweep << "\n";
                std::cout << "Galaxy Radius (Min: " << std::setprecision(1) << std::fixed << MIN_GALRAD << ", Max: " << std::setprecision(1) << std::fixed << MAX_GALRAD << ")=" << std::setprecision(1) << std::fixed << def_galrad << "\n";
                std::cout << "Arm Mapping Length (Min: " << std::setprecision(1) << std::fixed << MIN_LEN << ", Max: " << std::setprecision(1) << std::fixed << MAX_LEN << ")=" << std::setprecision(1) << std::fixed << def_len << "\n";
                std::cout << "Rotation (Min: " << std::setprecision(1) << std::fixed << MIN_ROT << ", Max: " << std::setprecision(1) << std::fixed << MAX_ROT << ")=" << std::setprecision(2) << std::fixed << def_rot << "\n";
                std::cout << "Core Radius (Min: " << std::setprecision(1) << std::fixed << MIN_R0 << ", Max: " << std::setprecision(1) << std::fixed << MAX_R0 << ")=" << std::setprecision(2) << std::fixed << def_r0 << "\n";
                std::cout << "Core Value (Min: " << MIN_CORE << ", Max: " << MAX_CORE << ")=" << def_core << "\n";
                std::cout << "Bar Semi-Major Axis (Min: " << std::setprecision(1) << std::fixed << MIN_BARA << ", Max: " << std::setprecision(1) << std::fixed << MAX_BARA << ")=" << std::setprecision(2) << std::fixed << def_bara << "\n";
                std::cout << "Bar Semi-Minor Axis (Min: " << std::setprecision(1) << std::fixed << MIN_BARB << ", Max: " << std::setprecision(1) << std::fixed << MAX_BARB << ")=" << std::setprecision(2) << std::fixed << def_barb << "\n";
                std::cout << "Foreground Pixel Value (Min: " << std::setprecision(1) << std::fixed << MIN_PIXEL << ", Max: " << std::setprecision(1) << std::fixed << MAX_PIXEL << ")=" << std::setprecision(2) << std::fixed << def_fg << "\n";
                std::cout << "Background Pixel Value (Min: " << std::setprecision(1) << std::fixed << MIN_PIXEL << ", Max: " << std::setprecision(1) << std::fixed << MAX_PIXEL << ")=" << std::setprecision(2) << std::fixed << def_bg << "\n";
                std::cout << "Margin (Pixels) (Min: " << MIN_MAR << ", Max: " << MAX_MAR << ")=" << def_mar << "\n";
                std::cout << "Change in Pitch Angle (Degrees) (Min: " << std::setprecision(1) << std::fixed << MIN_DELTA << ", Max: " << std::setprecision(1) << std::fixed << MAX_DELTA << ")=" << std::setprecision(2) << std::fixed << def_delta << "\n";
                std::cout << "Change in Arm Luminosity Over Length (Percentage) (Min: " << std::setprecision(2) << std::fixed << MIN_LUM << ", Max: " << std::setprecision(2) << std::fixed << MAX_LUM << ")=" << std::setprecision(2) << std::fixed << def_lum << "\n";
                std::cout << "Luminosity Change Rate (Min: " << MIN_LOG << ", Max: " << MAX_LOG << ")=" << def_log << "\n";
                std::cout << "Change in Arm Luminosity Over Width (Min: " << MIN_ARM_LUM << ", Max: " << MAX_ARM_LUM << ")=" << def_arm_lum << "\n";
                std::cout << "Background Noise (Min: " << std::setprecision(1) << std::fixed << MIN_NOISE << ", Max: " << std::setprecision(1) << std::fixed << MAX_NOISE << ")=" << std::setprecision(2) << std::fixed << def_noise << "\n";
                exit(EXIT_SUCCESS);
                }
            default:
                {
                std::cerr << "Usage: p2spiral [-s|--sg] [-a|--arms] [-d|--default] [-v|--verbose] [-e|--extend] [-p|--print] <file>\n";
                exit(EXIT_FAILURE);
                break;
                }
            }
        }

//
// Open the input file name(s), if given
//

    opt_ind=optind;
    num_files=-1;
    if (optind < argc)
        {
        while (opt_ind < argc)
            {     /* Start loop for input files */
            std::string ifname = std::string(argv[opt_ind]);
            std::ifstream file_list(ifname);
            if (!file_list.is_open())
                {
                std::cerr << "ERROR: Cannot open input file - " << std::string(argv[opt_ind]) << "\n";
                continue;
                }

            opt_ind++;

//
// Look for the DEFAULTS: or MODELS: directives
//

            line_num=0;
            std::string row;
            std::vector<std::string> line;
            while (getline(file_list,row))
                {   /* Start loop for file lines */
                line_num++;

                if (DEBUG)
                    {
                    std::cout << "DEBUG: Read Line " << line_num << " **"  << row << "**\n";
                    }

//
// Read all the file lines into a vector of strings.  While populating the
//   array, check for comments or blank lines and ignore them.  For all other
//   lines remove any whitespace.
//

                if ((row.size() < 2) || (row.at(0)=='#'))
                    {
                    if (DEBUG)
                        {
                        std::cout << "DEBUG: Short Line " << line_num << ", Skip Line " << row << "\n";
                        }
                    continue;
                    }

                row.erase(std::remove(row.begin(), row.end(), ' '),row.end());
                line.push_back(row);
                }   /* End of read lines loop */

//
// Loop through the array of strings to manage the state transitions, read
//   the tokens, and process the tokens into the file structure
//

            state=NO_STATE;
            for (auto & element : line)
                {
                if ((element.compare("DEFAULTS:")) == 0)
                    {
                    state=DEFAULT;
                    if (DEBUG)
                        {
                        std::cout << " -- Switch to DEFAULT STATE\n";
                        }
                    continue;
                    }

                if ((element.compare("MODELS:")) == 0)
                    {
                    state=CREATE;
                    if (DEBUG)
                        {
                        std::cout << " -- Switch to CREATE STATE\n";
                        }
                    }

//
// Should have state set. If not there are tokens prior to any
//   use of DEFAULTS: or MODELS: directives, so ignore them and
//   print a warning.
//

                if (state==NO_STATE)
                    {
                    std::cerr << "WARNING: Keywords found before MODELS: or DEFAULTS: directive...Skipping\n";
                    continue;
                    }

//
// Split the string into commands and values.  These should always occur
//   in pairs. First, split on ',' because there could be multiple commands
//   on a single line and then split on the 's'. The use extraction to
//   read all the pairs on this line.
//

                std::string parts=element;
                std::replace(parts.begin(), parts.end(), ',',' ');
                std::replace(parts.begin(), parts.end(), '=',' ');
                std::stringstream pairs(parts);
                std::string keyword;
                std::string value;

                while(pairs >> keyword >> value)
                    {
                    if (DEBUG)
                        {
                        std::cout << "DEBUG: Keyword=" << keyword << " Value=" << value << "\n";
                        }

//
// Lookup keyword to determine the properties and check limits
//

                    result=lookup(keyword,value);

                    if ((state == CREATE) && (result != K_NAME))
                        {
                        std::cerr << "WARNING name: Keyword without a file name...Skipping\n";
                        continue;
                        }
                    switch (result)
                        {
                        case K_BAD:
                            {
                            std::cout  << "ERROR[" << files[num_files].name << "]: Unknown keyword " << keyword << "...Skipping\n";
                            break;
                            }
                        case K_LO:
                            {
                            std::cout << "ERROR[" << files[num_files].name << "]: keyword " << keyword << ": Value " << value << " below lower limit...Skipping\n";
                            break;
                            }
                        case K_HI:
                            {
                            std::cout << "ERROR[" << files[num_files].name << "]: keyword " << keyword << ": Value " << value << " above upper limit...Skipping\n";
                            break;
                            }
                        case K_NAME:
                            {
                            state=MODEL;
                            num_files++;

//
// If we have reached the maximum file number, we need to flag an error.
//

                            if (num_files == MAX_FILES)
                                {
                                std::cerr << "ERROR: Too many input files: " << num_files << "!\n";
                                exit(EXIT_FAILURE);
                                }
                            copy_defaults(num_files);
                            files[num_files].name = value;
                            break;
                            }
                        case K_PA:
                            {
                            if (state==DEFAULT)
                                {
                                def_pa=stof(value);
                                def_pa2=0.0;
                                def_pa3=0.0;
                                def_pa4=0.0;
                                }
                            if (state==MODEL) for (int ix=0; ix < 6; ix++) files[num_files].pa[ix]=stof(value);
                            if (DEBUG)
                                {
                                if (state==MODEL) std::cout << "MODELER\n";
                                std::cout << "DEBUG: state is " << state << " value is " << value << "\n";
                                }
                            break;
                            }
                        case K_PA2:
                            {
                            if (state==DEFAULT)
                                {
                                def_pa2=stof(value);
                                }
                            if (state==MODEL)
                                {
                                files[num_files].pa[1]=stof(value);
                                }
                            break;
                            }
                        case K_PA3:
                            {
                            if (state==DEFAULT)
                                {
                                def_pa3=stof(value);
                                }
                            if (state==MODEL)
                                {
                                files[num_files].pa[2]=stof(value);
                                }
                            break;
                            }
                        case K_PA4:
                            {
                            if (state==DEFAULT)
                                {
                                def_pa4=stof(value);
                                }
                            if (state==MODEL)
                                {
                                files[num_files].pa[3]=stof(value);
                                }
                            break;
                            }
                        case K_ARMS:
                            {
                            if (state==DEFAULT) def_arms=stoi(value);
                            if (state==MODEL) files[num_files].arms=stoi(value);
                            break;
                            }
                        case K_VSIZE:
                            {
                            if (state==DEFAULT) def_vsize=stoi(value);
                            if (state==MODEL) files[num_files].vsize=stoi(value);
                            break;
                            }
                        case K_HSIZE:
                            {
                            if (state==DEFAULT) def_hsize=stoi(value);
                            if (state==MODEL) files[num_files].hsize=stoi(value);
                            break;
                            }
                        case K_FEATH:
                            {
                            if (state==DEFAULT)
                                {
                                def_feath=stoi(value);
                                def_feath2=0;
                                def_feath3=0;
                                def_feath4=0;
                                }
                            if (state==MODEL) for (int d=0; d < 6; d++) files[num_files].feath[d]=stoi(value);
                            break;
                            }
                        case K_FEATH2:
                            {
                            if (state==DEFAULT) def_feath2=stof(value);
                            if (state==MODEL)
                                files[num_files].feath[1]=stof(value);
                            break;
                            }
                        case K_FEATH3:
                            {
                            if (state==DEFAULT) def_feath3=stof(value);
                            if (state==MODEL)
                                files[num_files].feath[2]=stof(value);
                            break;
                            }
                        case K_FEATH4:
                            {
                            if (state==DEFAULT) def_feath4=stof(value);
                            if (state==MODEL)
                                files[num_files].feath[3]=stof(value);
                            break;
                            }
                        case K_SWEEP:
                            {
                            if (state==DEFAULT) def_sweep=stof(value);
                            if (state==MODEL) files[num_files].sweep=stof(value);
                            break;
                            }
                        case K_GALRAD:
                            {
                            if (state==DEFAULT) def_galrad=stof(value);
                            if (state==MODEL) files[num_files].galrad=stof(value);
                            break;
                            }
                        case K_LEN:
                            {
                            if (state==DEFAULT)
                                {
                                def_len=stoi(value);
                                def_len2=0;
                                def_len3=0;
                                def_len4=0;
                                }
                            if (state==MODEL) for (int d=0; d < 6; d++)
                            files[num_files].len[d]=stoi(value);
                            break;
                            }
                        case K_LEN2:
                            {
                            if (state==DEFAULT) def_len2=stof(value);
                            if (state==MODEL)
                            files[num_files].len[1]=stof(value);
                            break;
                            }
                        case K_LEN3:
                            {
                            if (state==DEFAULT) def_len3=stof(value);
                            if (state==MODEL)
                            files[num_files].len[2]=stof(value);
                            break;
                            }
                        case K_LEN4:
                            {
                            if (state==DEFAULT) def_feath4=stof(value);
                            if (state==MODEL)
                            files[num_files].len[3]=stof(value);
                            break;
                            }
                        case K_ROT:
                            {
                            if (state==DEFAULT) def_rot=stof(value);
                            if (state==MODEL) files[num_files].rot=stof(value);
                            break;
                            }
                        case K_R0:
                            {
                            if (state==DEFAULT) def_r0=stof(value);
                            if (state==MODEL) files[num_files].r0=stof(value);
                            break;
                            }
                        case K_CORE:
                            {
                            if (state==DEFAULT) def_core=stoi(value);
                            if (state==MODEL) files[num_files].core=stoi(value);
                            break;
                            }
                        case K_BARA:
                            {
                            if (state==DEFAULT)
                                {
                                def_bara=stof(value);
                                if (def_bara == 0.0) def_barb=0.0;
                                }
                            if (state==MODEL) files[num_files].bara=stof(value);
                            break;
                            }
                        case K_BARB:
                            {
                            if (state==DEFAULT) def_barb=stof(value);
                            if (state==MODEL) files[num_files].barb=stof(value);
                            break;
                            }
                        case K_FG:
                            {
                            if (state==DEFAULT)
                                {
                                def_fg=stof(value);
                                def_fg2=def_fg;
                                def_fg3=def_fg;
                                def_fg4=def_fg;
                                }
                            if (state==MODEL) for (int d=0; d < 6; d++)  files[num_files].fg[d]=stof(value);
                            break;
                            }
                        case K_FG2:
                            {
                            if (state==DEFAULT) def_fg2=stof(value);
                            if (state==MODEL)
                                files[num_files].fg[1]=stof(value);
                            break;
                            }
                        case K_FG3:
                            {
                            if (state==DEFAULT) def_fg3=stof(value);
                            if (state==MODEL)
                                files[num_files].fg[2]=stof(value);
                            break;
                            }
                        case K_FG4:
                            {
                            if (state==DEFAULT) def_fg4=stof(value);
                            if (state==MODEL)
                                files[num_files].fg[3]=stof(value);
                            break;
                            }
                        case K_BG:
                            {
                            if (state==DEFAULT) def_bg=stof(value);
                            if (state==MODEL) files[num_files].bg=stof(value);
                            break;
                            }
                        case K_MAR:
                            {
                            if (state==DEFAULT) def_mar=stoi(value);
                            if (state==MODEL) files[num_files].mar=stoi(value);
                            break;
                            }
                        case K_DELTA:
                            {
                            if (state==DEFAULT)
                                {
                                def_delta=stof(value);
                                def_delta2=0.0;
                                def_delta3=0.0;
                                def_delta4=0.0;
                                }
                            if (state==MODEL) for (int ix=0; ix < 6; ix++) files[num_files].delta[ix]=stof(value);
                            break;
                            }
                        case K_DELTA2:
                            {
                            if (state==DEFAULT) def_delta2=stof(value);
                            if (state==MODEL) files[num_files].delta[1]=stof(value);
                            break;
                            }
                        case K_DELTA3:
                            {
                            if (state==DEFAULT) def_delta3=stof(value);
                            if (state==MODEL) files[num_files].delta[2]=stof(value);
                            break;
                            }
                        case K_DELTA4:
                            {
                            if (state==DEFAULT) def_delta4=stof(value);
                            if (state==MODEL) files[num_files].delta[3]=stof(value);
                            break;
                            }
                        case K_LUM:
                            {
                            if (state==DEFAULT)
                                {
                                def_lum=stof(value);
                                def_lum2=0.0;
                                def_lum3=0.0;
                                def_lum4=0.0;
                                }
                            if (state==MODEL)
                                {
                                for (int ix=0; ix < 6; ix++)
                                    {
                                    files[num_files].lum[ix]=stof(value);
                                    }
                                }
                            break;
                            }
                        case K_LUM2:
                            {
                            if (state==DEFAULT) def_lum2=stof(value);
                            if (state==MODEL) files[num_files].lum[1]=stof(value);
                            break;
                            }
                        case K_LUM3:
                            {
                            if (state==DEFAULT) def_lum3=stof(value);
                            if (state==MODEL) files[num_files].lum[2]=stof(value);
                            break;
                            }
                        case K_LUM4:
                            {
                            if (state==DEFAULT) def_lum4=stof(value);
                            if (state==MODEL)  files[num_files].lum[3]=stof(value);
                            break;
                            }
                        case K_LOG:
                            {
                            if (state==DEFAULT) def_log=stoi(value);
                            if (state==MODEL) files[num_files].log=stoi(value);
                            break;
                            }
                        case K_ARM_LUM:
                            {
                            if (state==DEFAULT) def_arm_lum=stoi(value);
                            if (state==MODEL) files[num_files].arm_lum=stoi(value);
                            break;
                            }
                        case K_NOISE:
                            {
                            if (state==DEFAULT) def_noise=stof(value);
                            if (state==MODEL) files[num_files].noise=stof(value);
                            break;
                            }
                        case K_RESET:
                            {
                            if (state==DEFAULT)
                                {
// reset all defaults - NOT IMPLEMENTED YET
                                }
                            break;
                            }
                        default:
                            {
                            std::cerr << "ERROR: Internal Error...Exiting\n";
                            exit(EXIT_FAILURE);
                            }
                        }
                    }
                }
            }
        }
    else

//
// No input file specified, so read the parameters interactively from stdin
//

        {
        num_files=0;

//
// Forever loop, will break out when user is done and enters <CTRL>-D
//   No default for the base name.
//

        while (true)
            {
            std::cout << "\nBase File Name: ";

//
// Here's where we bail on the loop if <CTRL>-D
//

            std::string entry;

            if ( !getline(std::cin, entry) ) break;
            if (entry.empty())
                {
                std::cerr << "WARNING: Invalid Name\n";
                continue;
                }
            files[num_files].name = entry;

//
// For the rest of the values, use the subroutine
//

            if ((files[num_files].pa[0]=get_input("Pitch Angle (General) [", MIN_PA, MAX_PA, def_pa)) < -2000.0) break;

            for ( int ix=1; ix < 6; ix++) files[num_files].pa[ix]=files[num_files].pa[0];

            if ((files[num_files].pa[1]=(int)get_input("Pitch Angle (Second Arm) [", MIN_PA, MAX_PA, def_pa2)) < -2000.0) break;

            if ((files[num_files].pa[2]=(int)get_input("Pitch Angle (Third Arm) [", MIN_PA, MAX_PA, def_pa3)) < -2000.0) break;

            if ((files[num_files].pa[3]=(int)get_input("Pitch Angle (Fourth Arm) [", MIN_PA, MAX_PA, def_pa4)) < -2000.0) break;

            if ((files[num_files].arms=(int)get_input("Arms [", MIN_ARM, MAX_ARM, def_arms)) < -2000.0) break;

            if ((files[num_files].hsize=(int)get_input("Horizontal Size [", MIN_SIZE, MAX_SIZE, def_hsize)) < -2000.0) break;

            if ((files[num_files].vsize=(int)get_input("Vertical Size [", MIN_SIZE, MAX_SIZE, def_vsize)) < -2000.0) break;

            if ((files[num_files].feath[0]=(int)get_input("Feather (General) [", MIN_FEATH, MAX_FEATH, def_feath)) < -2000.0) break;

            for ( int ix=1; ix < 6; ix++) files[num_files].feath[ix]=files[num_files].feath[0];

            if ((files[num_files].feath[1]=(int)get_input("Feather (Second Arm) [", MIN_FEATH, MAX_FEATH, def_feath2)) < -2000.0) break;

            if ((files[num_files].feath[2]=(int)get_input("Feather (Third Arm) [", MIN_FEATH, MAX_FEATH, def_feath3)) < -2000.0) break;

            if ((files[num_files].feath[3]=(int)get_input("Feather (Fourth Arm) [", MIN_FEATH, MAX_FEATH, def_feath4)) < -2000.0) break;

            if ((files[num_files].sweep=get_input("Sweep (Azimuthal Extent) [", MIN_SWEEP, MAX_SWEEP, def_sweep)) < -2000.0) break;

            if ((files[num_files].galrad=get_input("Galactic Radius [", MIN_GALRAD, MAX_GALRAD, def_galrad)) < -2000.0) break;

            if ((files[num_files].len[0]=(int)get_input("Arm Length (General) [", MIN_LEN, MAX_LEN, def_len)) < -2000.0) break;

            for ( int ix=1; ix < 6; ix++)
            files[num_files].len[ix]=files[num_files].len[0];

            if ((files[num_files].len[1]=(int)get_input("Arm Length (Second Arm) [", MIN_LEN, MAX_LEN, def_len2)) < -2000.0) break;

            if ((files[num_files].len[2]=(int)get_input("Arm Length (Third Arm) [", MIN_LEN, MAX_LEN, def_len3)) < -2000.0) break;

            if ((files[num_files].len[3]=(int)get_input("Arm Length (Fourth Arm) [", MIN_LEN, MAX_LEN, def_len3)) < -2000.0) break;

            if ((files[num_files].rot=get_input("Rotation Angle [", MIN_ROT, MAX_ROT, def_rot)) < -2000.0) break;

            if ((files[num_files].r0=get_input("Initial Radius [", MIN_R0, MAX_R0, def_r0)) < -2000.0) break;

            if ((files[num_files].core=(int)get_input("Core Setting [", MIN_CORE, MAX_CORE, def_core)) < -2000.0) break;

            if ((files[num_files].bara=get_input("Bar Semi-Major Axis [", MIN_BARA, MAX_BARA, def_bara)) < -2000.0) break;

            if (files[num_files].bara != 0)
                {
                if ((files[num_files].barb=get_input("Bar Semi-Minor Axis [", MIN_BARB, MAX_BARB, def_barb)) < -2000.0) break;
                }

            if ((files[num_files].mar=(int)get_input("Outer Margin [", MIN_MAR, MAX_MAR, def_mar)) < -2000.0) break;

            if ((files[num_files].fg[0]=get_input("Foreground (General) [", MIN_PIXEL, MAX_PIXEL, def_fg)) < -2000.0) break;

            for ( int ix=1; ix < 6; ix++) files[num_files].fg[ix]=files[num_files].fg[0];

            if ((files[num_files].fg[1]=get_input("Foreground (Second Arm) [", MIN_PIXEL, MAX_PIXEL, def_fg2)) < -2000.0) break;

            if ((files[num_files].fg[2]=get_input("Foreground (Third Arm) [", MIN_PIXEL, MAX_PIXEL, def_fg3)) < -2000.0) break;

            if ((files[num_files].fg[3]=get_input("Foreground (Fourth Arm) [", MIN_PIXEL, MAX_PIXEL, def_fg4)) < -2000.0) break;

            if ((files[num_files].bg=get_input("Background (Bias) [", MIN_PIXEL, MAX_PIXEL, def_bg)) < -2000.0) break;

            if ((files[num_files].delta[0]=get_input("Pitch Angle Change (First Arm) [", MIN_DELTA, MAX_DELTA, def_delta)) < -2000.0) break;

            for ( int ix=1; ix < 6; ix++) files[num_files].delta[ix]=files[num_files].delta[0];

            if ((files[num_files].delta[1]=get_input("Pitch Angle Change (Second Arm) [", MIN_DELTA, MAX_DELTA, def_delta2)) < -2000.0) break;

            if ((files[num_files].delta[2]=get_input("Pitch Angle Change (Third Arm) [", MIN_DELTA, MAX_DELTA, def_delta3)) < -2000.0) break;

            if ((files[num_files].delta[3]=get_input("Pitch Angle Change (Fourth Arm) [", MIN_DELTA, MAX_DELTA, def_delta4)) < -2000.0) break;

            if ((files[num_files].lum[0]=get_input("Luminosity Change (First Arm) [", MIN_LUM, MAX_LUM, def_lum)) < -2000.0) break;

            for ( int ix=1; ix < 6; ix++) files[num_files].lum[ix]=files[num_files].lum[0];

            if ((files[num_files].lum[1]=get_input("Luminosity Change (Second Arm) [", MIN_LUM, MAX_LUM, def_lum2)) < -2000.0) break;

            if ((files[num_files].lum[2]=get_input("Luminosity Change (Third Arm) [", MIN_LUM, MAX_LUM, def_lum3)) < -2000.0) break;

            if ((files[num_files].lum[3]=get_input("Luminosity Change (Fourth Arm) [", MIN_LUM, MAX_LUM, def_lum4)) < -2000.0) break;

            if ((files[num_files].log=(int)get_input("Brightness Change Algorithm [", MIN_LOG, MAX_LOG, def_log)) < -2000.0) break;

            if ((files[num_files].arm_lum=(int)get_input("Arm Width Luminosity Change Setting [", MIN_ARM_LUM, MAX_ARM_LUM, def_arm_lum)) < -2000.0) break;

            if ((files[num_files].noise=get_input("Noise (Shot) [", MIN_NOISE, MAX_NOISE, def_noise)) < -2000.0) break;

            num_files++;
            }
        num_files -= 1;
        }

//
//  Need at least one entry or there is no valid input
//

    if (num_files < 0)
        {
        std::cerr << "ERROR:  No files to generate (" << num_files << ")\n";
        exit(EXIT_FAILURE);
        }

//
// Now create the requested FITS files
//

    for ( counter=0; counter <= num_files; counter++ )
        {

        max_r = 0.0;
//
// If the verbose flag is set, print out all input information/assumptions
//

        if (verbose)
            {
            std::cout << "Processing File " << counter+1 << ": Name=" << files[counter].name << ", Pitch Angles=" << files[counter].pa[0] << "," << files[counter].pa[1] << "," << files[counter].pa[2] << "," << files[counter].pa[3] << "," << files[counter].pa[4] << "," << files[counter].pa[5] << "\n";

            std::cout << "    Arms=" << files[counter].arms << ", Hor. Size=" << files[counter].hsize << ", Ver. Size=" << files[counter].vsize << ", Feather=" << files[counter].feath[0] << "\n";

            std::cout << "    Sweep=" << files[counter].sweep << ", Rotation=" << files[counter].rot << ", r0=" << files[counter].r0 << ", Core=" << files[counter].core << ", Bar Semi-Major=" << files[counter].bara << ", Bar Semi-Minor=" << files[counter].barb << "\n";

            std::cout << "    Margin=" << files[counter].mar << ", Fg=" << files[counter].fg[0] << "," << files[counter].fg[1] << "," << files[counter].fg[2] << "," << files[counter].fg[3] << ", Bg=" << files[counter].bg << "\n";

            std::cout << ", Delta=" << files[counter].delta[0] << "," << files[counter].delta[1] << "," << files[counter].delta[2] << "," << files[counter].delta[3] << "," << files[counter].delta[4] << "," << files[counter].delta[5] << "\n";

            std::cout << "    Lum=" << files[counter].lum[0] << "," << files[counter].lum[1] << "," << files[counter].lum[2] << "," << files[counter].lum[3] << "," << files[counter].lum[4] << "," << files[counter].lum[5] << ", Log=" << files[counter].log << ", Arm_lum=" << files[counter].arm_lum << ", Noise=" << files[counter].noise << "\n";
            }

//
// Initialize array values and populate it with random noise values, if needed.
//   PLEASE NOTE: The FITS array ordering is different than C so columns are
//   major and rows are minor (fastest varying).   The astro_class libraries
//   expect this as well.
//

        if (verbose) std::cout << "  --- Generating Arrays\n";

        mat=ast.ArrayAlloc(files[counter].vsize, files[counter].hsize);

        if (arm_files)
            {
            for (i=0; i < files[counter].arms; i++)
                mat_files[i]=ast.ArrayAlloc(files[counter].vsize, files[counter].hsize);
            }

        for (x=0; x < files[counter].hsize; x++)
            {
            for (y=0; y < files[counter].vsize; y++)
                {
                if (files[counter].noise != 0.0)
                    {
                    rn=(((float)rand())/((float) RAND_MAX + 1.0))*files[counter].noise;
                    mat[y][x]=files[counter].bg+rn;
                    }
                else
                    {
                    mat[y][x]=files[counter].bg;
                    if (arm_files)
                        {
                        for (i=0; i < files[counter].arms; i++)
                            mat_files[i][y][x]=files[counter].bg;
                        }
                    }
                }
            }

//
// Set the chirality (direction) value for the equation based on neg/pos p.a.
//

        if (verbose) std::cout << "  --- Set Chirality\n";

        for (int aind = 0; aind < 6; aind ++)
            {
            if ( files[counter].pa[aind] > 0 )
                {
                mod[aind]=-1.0;
                mod2[aind]=1.0;
                }
            else
                {
                mod[aind]=1.0;
                mod2[aind]=-1.0;
                }
            }

//
// Determine the arm separation.  If arm > 1 set to the angle of separation
//   between the arms.  If arm=1, then set to zero, which will cause the
//   separation term in the formula to go to 0.
//

        if (verbose) std::cout << "  --- Set Arm Separation\n";

        if (files[counter].arms > 1)
            {
            separation=360.0/(float)files[counter].arms;
            }
        else
            {
            separation=0.0;
            }

//
// Determine the radius where the arms will start based on core size and bar
//   parameters
//

        if (files[counter].bara > files[counter].r0)
            {
            startf=files[counter].bara;
            starti=(int) files[counter].bara;
            }
        else
            {
            startf=files[counter].r0;
            starti=(int) files[counter].r0;
            }

//
// Find the length of the arms.  This is used to calculate the luminosity and
//   pitch angle change rates (if any).
//

        for (int ix=0; ix < 6; ix++) arm_len[ix]=0.0;

        for (int arm_num=0; arm_num < files[counter].arms; arm_num++)
            {
            if (files[counter].delta[arm_num] == 0.0)
                pitch=files[counter].pa[arm_num];
            else
                pitch=(files[counter].pa[arm_num]*(1+files[counter].delta[arm_num]))/2.0;


            arm_len[arm_num] =
            ((startf*sqrt(1+pow(tan(fabs(pitch)*(M_PI/180.0))*(M_PI/180.0),2.0))*expf(tan(fabs(pitch)*(M_PI/180.0))*180.0*M_PI/180.0))/tan(fabs(pitch)*(M_PI/180.0)))-
            ((startf*
            sqrt(1+pow(tan(fabs(pitch)*(M_PI/180.0))*(M_PI/180.0),2.0))
            * expf(tan(fabs(pitch)*(M_PI/180.0))*0.0*M_PI/180.0))/tan(fabs(pitch)*(M_PI/180.0)));

//
// If spiral graph (-s) mode us being used, reset the feathering values based
// on the arm lengths
//

            if (sg)
                {
                files[counter].feath[arm_num] = ((int)(0.03 * arm_len[arm_num])-1)/2;
                if (files[counter].feath[arm_num] > 7) files[counter].feath[arm_num]=7;
                }
            }

//
// Check for sanity of parameters
//

        auto fmax = std::max_element(std::begin(files[counter].feath),std::end(files[counter].feath));
        if (files[counter].hsize < files[counter].vsize)
            {
            outer=files[counter].hsize/2-files[counter].mar-starti-(*fmax)-1;
            }
        else
            {
            outer=files[counter].vsize/2-files[counter].mar-starti-(*fmax)-1;
            }
        if (verbose) std::cout << "Outer Arm=" << outer << "\n";
        if ((outer < 2)||(outer>(files[counter].hsize/2))||(outer>(files[counter].vsize/2)))
            {
            std::cerr << "ERROR: Input parameters inconsistent for file: " << files[counter].name << " - arm length is " << outer << "\n";
            continue;
            }

//
// Warning for values that may not produce useful images
//

        if ((files[counter].sweep > 0.0) && (files[counter].sweep < 45.0))
        std::cerr << "WARNING: Swwep value for: " << files[counter].name << " - may return inconsistent results because it is too low: " << files[counter].sweep << "\n";

//<FIX - Warn on inconsistent params>
//< FEATH for wrong arm count
//<rad for wrong arm count>
//<glad & len & sweep - pick one>
//<Low sweep>
//<END FIX>

//
// Calculate the pitch angle change for each arm
//

        for (int ix=0; ix < 6; ix++)
            {
            change[ix]=files[counter].delta[ix]/files[counter].sweep;
            if (verbose) std::cout << "Pitch Angle Incremental Change=" << change[ix] << "\n";

//
// Calculate the brightness change for the arms
//

            if (files[counter].lum[ix] == 0.0)
                {
                lum_rate[ix]=0.0;
                }
            else
                {

//
// Linear change of luminosity
//

                if (files[counter].log==0)
                    {
                    lum_rate[ix]=(files[counter].fg[ix]*files[counter].lum[ix])/
                    (files[counter].sweep);
                    }
                else
                    {
                    if (files[counter].lum[ix] > 0.0)
                        {
                        lum_rate[ix]=logf(files[counter].fg[ix]/
                        (files[counter].fg[ix]*files[counter].lum[ix]))/(files[counter].sweep);
                        }
                    else
                        {
                        lum_rate[ix]=-1.0*logf(files[counter].fg[ix]*files[counter].lum[ix]*-1.0)
                        /files[counter].sweep;
                        }
                    }
                if (DEBUG)
                    {
                    std::cout << "Brightness Incremental Change=" << lum_rate[ix] << "\n";
                    }
                }
            }

//
// Start mapping the polar coordinates.  Loop through theta from 1 to sweep.
//

        if (verbose) std::cout << "  --- Map Coordinates\n";


        for(mode=0; mode < files[counter].arms; mode++)
            {
            cur_len = 0.0;
            pitch=files[counter].pa[mode];
            if (DEBUG)
                {
                std::cout << "DEBUG pa[" << mode << "]=" << pitch << "\n";
                std::cout << "DEBUG lum[" << mode << "]=" << files[counter].lum[mode] << "," << lum_rate[mode] << "\n";
                std::cout << "DEBUG delta[" << mode << "]=" << files[counter].delta[mode] << "\n";
                }
            min_pitch=pitch;
            max_pitch=pitch;
            avg_pitch=0;
            num_pitch=0;
            last_x=-1;
            last_y=-1;
            cur_rad = startf;

//
// The key to drawing the arms correctly is when to stop.  The algorithm to
//   map the arms uses the angle (theta).  If we are drawing the arms based on
//   sweep, that gives us a stop value.  If we are drawing based on galactic
//   radius or arm length, set the sweep value high and stop the iteration
//   when we cross the radius or length limit.
//

            if ((files[counter].galrad > 0.0) || (files[counter].len[mode] > 0.0))
                {
                sweeper=720.0;
                }
            else
                {
                sweeper=files[counter].sweep;
                }

            for (theta = 0.0; theta <= sweeper; theta += 1.0)
                {

//
// Calculate the true r value.  This is where using consecutively larger
//   values of theta makes the calculation easier.  Please note tan(3) on
//   Linux expects values in radians and not degrees.
//

                if (theta == 0.0) r=startf;
                else r = cur_rad*expf(tan(fabs(pitch)*(M_PI/180.0))*1.0*M_PI/180.0);
//
// Now map r and theta to the Cartesian values.  Note that we map
//   from the center of the image outward.  Also note, that we vary the actual
//   theta angle for each arm by the separation, which tries to even space the
//   arms (by multiplying an offset to the theta values)
//

                x=(files[counter].hsize/2)+(int)(r*cos(mod[mode]*(theta+(mod2[mode]*files[counter].rot)+((float)mode*separation))*(M_PI/180.0)));
                y=(files[counter].vsize/2)+(int)(r*sin(mod[mode]*(theta+(mod2[mode]*files[counter].rot)+((float)mode*separation))*(M_PI/180.0)));

//
// Determine the incremental length of the current arm and update the total
//   length for this arm
//

                if ((last_x != -1) && (last_y !=-1))
                    cur_len += pow(pow(x-last_x, 2.0) + pow(y-last_y, 2.0), 0.5);

//
// Depending on the pitch angle value, X and/or Y plus the feathering can go
//   outside of the array bounds (minus the margin) or if the mapping exceeds
//   the galaxy radius/arm length, then stop the mapping for this arm
//

                if ((x <= (files[counter].mar+files[counter].feath[mode]))
                   || (x >= (files[counter].hsize-files[counter].mar-files[counter].feath[mode]))
                   || (y <= (files[counter].mar+files[counter].feath[mode]))
                   || (y >= (files[counter].vsize-files[counter].mar-files[counter].feath[mode])))
                   break;

                if ((files[counter].len[mode] > 0.0) &&
                    (cur_len >= files[counter].len[mode]))
                    {
                    break;
                    }

                if ((files[counter].galrad > 0.0) &&
                    (r >= files[counter].galrad))
                    {
                    break;
                    }

                if (r > max_r)
                    {
                    max_r=r;
                    }

//
// OK to map
//

                if (theta == 0.0)
                    {
                    brt=files[counter].fg[mode];
                    }
                else
                    {
                    if (files[counter].log==0)
                        {
                        brt=files[counter].fg[mode]+(lum_rate[mode]*theta);
                        }
                    else
                        {
                        if (lum_rate[mode] > 0.0)
                            brt=files[counter].fg[mode]+expf(fabs(lum_rate[mode])*theta);
                        else
                            brt=files[counter].fg[mode]-expf(fabs(lum_rate[mode])*theta);
                        }
                    }

                mat[y][x]=brt;
                if (arm_files)
                    {
                    mat_files[mode][y][x]=brt;
                    }
                avg_pitch+=pitch;
                num_pitch+=1.0;
                if (list) std::cout << "File: " << files[counter].name << " - Arm " << mode+1 <<": Radius: " << r << "\tPitch: " << pitch << "\tLuminosity: " << brt << "\n";
                newpitch = pitch + change[mode];
                cur_rad = r;

//
// The pitch angle formula in unstable in the outer regions for variable
//   pitch angles.  This logic attempts to maintain the growth of the curve.
//

                if (files[counter].pa[mode] > 0.0)
                    {
                    if (files[counter].delta[mode] > 0.0)
                        {
                        if (newpitch > pitch)
                            {
                            pitch=newpitch;
                            if (pitch > max_pitch) max_pitch=pitch;
                            if (pitch < min_pitch) min_pitch=pitch;
                            }
                        }
                    if (files[counter].delta[mode] < 0.0)
                        {
                        if (newpitch < pitch)
                            {
                            pitch=newpitch;
                            if (pitch > max_pitch) max_pitch=pitch;
                            if (pitch < min_pitch) min_pitch=pitch;
                            }
                        }
                    }

                if (files[counter].pa[mode] < 0.0)
                    {
                    if (files[counter].delta[mode] > 0.0)
                        {
                        if (newpitch > pitch)
                            {
                            pitch=newpitch;
                            if (pitch > max_pitch) max_pitch=pitch;
                            if (pitch < min_pitch) min_pitch=pitch;
                            }
                        }
                    if (files[counter].delta[mode] < 0.0)
                        {
                        if (newpitch < pitch)
                            {
                            pitch=newpitch;
                            if (pitch > max_pitch) max_pitch=pitch;
                            if (pitch < min_pitch) min_pitch=pitch;
                            }
                        }
                    }

//
// Make the lines thicker with a 2D feathering
//

                if (files[counter].feath[mode] > 0)
                    {
                    for ( t=1; t <= files[counter].feath[mode]; t++)
                        {
                        for ( s=1; s <= files[counter].feath[mode]; s++)
                            {

//
// Check the X & Y values again
//

                            if ((x > files[counter].mar) && (x < (files[counter].hsize-files[counter].mar)) && (y > files[counter].mar) && (y < (files[counter].vsize-files[counter].mar)))
                                {
                                mat[y-t][x]=brt;
                                mat[y][x-s]=brt;
                                mat[y+t][x-s]=brt;
                                mat[y-t][x-s]=brt;
                                mat[y+t][x]=brt;
                                mat[y][x+s]=brt;
                                mat[y+t][x+s]=brt;
                                mat[y-t][x+s]=brt;
                                if (arm_files)
                                    {
                                    mat_files[mode][y-t][x]=brt;
                                    mat_files[mode][y][x-s]=brt;
                                    mat_files[mode][y+t][x-s]=brt;
                                    mat_files[mode][y-t][x-s]=brt;
                                    mat_files[mode][y+t][x]=brt;
                                    mat_files[mode][y][x+s]=brt;
                                    mat_files[mode][y+t][x+s]=brt;
                                    mat_files[mode][y-t][x+s]=brt;
                                    }
                                }
                            }
                        }
                    }

//
// In order to get a good image for analysis, connect the point to the previous
//   one (unless it's the first)
//

                if ((last_x < 0) || (last_y < -1))
                    {
                    last_x=x;
                    last_y=y;
                    }

//
// Determine the x and Y slope values for the line based on the current
//   point and the previous one
//

                if ((last_x-x) != 0.0)
                    {
                    slopex=((float)(y-last_y))/(abs((float)(last_x-x)));
                    }
                else
                    {
                    slopex=0.0;
                    }

                if ((last_y-y) != 0.0)
                    {
                    slopey=((float)(x-last_x))/(abs((float)(last_y-y)));
                    }
                else
                    {
                    slopey=0.0;
                    }

//
// Now that we know the X & Y slopes, see which dimension changes the most
//   between the two points.  Reset the other slope value to be 1/-1 and
//   determine the number of points to be drawn (pts).
//

                if (abs(last_x-x) > abs(last_y-y))
                    {
                    pts=abs(last_x-x);
                    if ((x-last_x) < 0) slopey=-1.0;
                    else slopey=1.0;
                    }
                else
                    {
                    pts=abs(last_y-y);
                    if ((y-last_y) < 0) slopex=-1.0;
                    else slopex=1.0;
                    }

//
// Draw the intermediate points into the working image to connect the last
//   traced point with the previous.
//

                for (int tt=1; tt < pts; tt++)
                    {
                    ax=last_x+(int)(slopey*(float)tt);
                    by=last_y+(int)(slopex*(float)tt);
                    mat[by][ax]=brt;
                    if (files[counter].feath[mode] > 0)
                        {
                        feath=files[counter].feath[mode];

                        if ((ax < files[counter].hsize-feath-2) && (ax > feath+1) && (by < files[counter].vsize-feath-2) && (by > feath+1))
                            {
                            for (int t=0; t <= feath; t++)
                                {
                                for (int s=0; s <=feath; s++)
                                    {
                                    mat[by-t][ax]=brt;
                                    mat[by-t][ax-s]=brt;
                                    mat[by][ax-s]=brt;
                                    mat[by+t][ax]=brt;
                                    mat[by][ax+s]=brt;
                                    mat[by+t][ax+s]=brt;
                                    mat[by-t][ax+s]=brt;
                                    mat[by+t][ax-s]=brt;
                                    if (arm_files)
                                        {
                                        mat_files[mode][by-t][ax]=brt;
                                        mat_files[mode][by-t][ax-s]=brt;
                                        mat_files[mode][by][ax-s]=brt;
                                        mat_files[mode][by+t][ax]=brt;
                                        mat_files[mode][by][ax+s]=brt;
                                        mat_files[mode][by+t][ax+s]=brt;
                                        mat_files[mode][by-t][ax+s]=brt;
                                        mat_files[mode][by+t][ax-s]=brt;
                                        }
                                    }
                                }
                            }
                        }
                    }
                last_x=x;
                last_y=y;
                }
            }

//
// Calculate average pitch angle and other constants to complete drawing
//

        avg_pitch=avg_pitch/num_pitch;
        centerx=files[counter].hsize/2;
        centery=files[counter].vsize/2;
        r2=(int) files[counter].r0*files[counter].r0;
        si=sin(-files[counter].rot*(M_PI/180.0));
        co=cos(-files[counter].rot*(M_PI/180.0));

//
// Fill in bar ellipse
//

        if ((files[counter].bara) && (files[counter].core))
            {
            brt=files[counter].fg[0]*files[counter].core;
            for (x=centerx-starti; x <= centerx+starti; x++)
                {
                for (y=centery-starti; y <= centery+starti; y++)
                    {
                    ma=(float)(x-centerx)*co+(float)(y-centery)*si;
                    mb=(float)(y-centery)*co-(float)(x-centerx)*si;
                    if ((pow(ma/files[counter].bara,2.0)+pow(mb/files[counter].barb,2.0)) <= 1.0)
                        {
                        mat[y][x]=brt;
                        if (arm_files)
                            {
                            for (i = 0; i < files[counter].arms; i++)
                                mat_files[i][y][x]=brt;
                            }
                        }
                    }
                }
            }

//
// Fill in the core.  Cannot use the same polar to cartesian mapping as in
//   p2dfft because larger cores will have gaps and patterns develop that
//   can be interpreted as structure.
//

        if (files[counter].core)
            {
            brt=files[counter].fg[0]*(float)files[counter].core;
            for (x=centerx-files[counter].r0; x <= centerx+files[counter].r0; x++)
                {
                for (y=centery-files[counter].r0; y <= centery+files[counter].r0; y++)
                    {
                    if ((x-centerx)*(x-centerx)+(y-centery)*(y-centery) < r2)
                        {
                        mat[y][x]=brt;
                        if (arm_files)
                            {
                            for (i = 0; i < files[counter].arms; i++)
                                mat_files[i][y][x]=brt;
                            }
                        }
                    }
                }
            }

        if (DEBUG_MAT)
            {
            for (i=0;i<files[counter].vsize;i++)
                {
                for (j=0;j<files[counter].hsize;j++)
                    {
                    std::cout << "DEBUG: mat[" << i << "][" << j << "]=" << mat[i][j] << "\n";
                    }
                }   
            }

//
// Now create the FITS file(s) using the astro_class libraries.  Please note
//   that when the new flag is set to 1 it will overwrite any existing file with
//   with the same name.
//

        if (verbose) std::cout << "  --- Write " << files[counter].name << ".fits File" << "\n";

        std::ostringstream fname2;
        fname2 << "!" << files[counter].name << ".fits";

        if (!(ast.fits_write(fname2.str(), mat[0], files[counter].hsize, files[counter].vsize, 1, "p2spiral/", VERSION)))
            {
            std::cout << "ERROR: fits_write() Failed\n";
            free(mat);
            continue;
            }

//
// Add some extra key values to the FITS header. Most of these keys are for
//   convenience for testing and analysis.
//

        num_keys=0;
        std::string keys[] =
          {
          "ARMS",           // Index 0
          "BAR",            // Index 1
          "AVGPITCH",       // Index 2
          "MINPITCH",       // Index 3
          "MAXPITCH",       // Index 4
          "MAXR",           // Index 5
// Last written if ext true
          "LONGR",          // Index 6
          "ARMWID",         // Index 7
          "ROTAT"           // Index 8
          };

        std::string items[] =
          {
          "Grayscale",                                   // Index 0
          std::to_string(files[counter].arms),           // Index 1
          (files[counter].bara > 0) ? std::to_string(files[counter].bara) : std::to_string(files[counter].r0),             // Index 2
          std::to_string(avg_pitch),                     // Index 3
          std::to_string(min_pitch),                     // Index 4
          std::to_string(max_pitch),                     // Index 5
          std::to_string(max_r),
// These are written if ext is true
          std::to_string(longr[0]),                      // Index 6
          std::to_string(files[counter].feath[0]*2+1),   // Index 7
          std::to_string(files[counter].rot)             // Index 8
          };

        if (ext) num_keys=9;
        else num_keys=6;

        std::ostringstream fname3;
        fname3 << files[counter].name << ".fits";
        if (!(ast.fits_header_write(fname3.str(), keys, items, num_keys)))
            {
            std::cerr << "WARNING: fits_header_write() Failed\n";
            }

//
// Deallocate the array for this file
//

        free(mat);

        if(arm_files)
            {

            for (i=0; i < files[counter].arms; i++)
                {
                if (verbose) std::cout << "  --- Write " << files[counter].name << " Arm " << i+1 << ".fits File" << "\n";

                std::string fname2 = files[counter].name;
                fname2 = "!" + fname2 + ".fits";
                if (!(ast.fits_write(fname2, mat_files[i][0], files[counter].hsize, files[counter].vsize, 1, "p2spiral/", VERSION)))
                    {
                    std::cout << "ERROR: fits_write() Failed\n";
                    free(mat);
                    continue;
                    }

//
// Add some extra key values to the FITS header. Most of these keys are for
//   convenience for testing and analysis.
//

                num_keys=0;
                std::string keys[] =
                {
                "ARM_NO",         // Index 0
                };

                std::string items[] =
                {
                "Grayscale",                                   // Index 0
                std::to_string(i)                              // Index 1
                };

                num_keys=1;

                std::string fname3 = files[counter].name + ".fits";

                if (!(ast.fits_header_write(fname3, keys, items, num_keys)))
                    {
                    std::cerr << "WARNING: fits_header_write() Failed\n";
                    }

//
// Deallocate the array for this file
//

                free(mat_files[i]);
                }
            }
        }

    std::cout << "Total Files Processed: " << num_files+1 << "\n";
    }
